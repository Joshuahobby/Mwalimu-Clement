import { pgTable, text, serial, integer, boolean, uniqueIndex, doublePrecision, timestamp, foreignKey } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  firebaseUid: text("firebase_uid").notNull().unique(),
  fullName: text("full_name"),
  phoneNumber: text("phone_number"),
  role: text("role").default("user"),
  createdAt: text("created_at").default("now()"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  email: true,
  firebaseUid: true,
  fullName: true,
  phoneNumber: true,
  role: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Package types
export const packages = pgTable("packages", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(),
  price: doublePrecision("price").notNull(),
  duration: integer("duration").notNull(),
  description: text("description").notNull(),
  isActive: boolean("is_active").default(true),
  createdAt: text("created_at").default("now()"),
});

// Relations will be defined after all models are declared

export const insertPackageSchema = createInsertSchema(packages).pick({
  name: true,
  type: true,
  price: true,
  duration: true,
  description: true,
  isActive: true,
});

export type InsertPackage = z.infer<typeof insertPackageSchema>;
export type Package = typeof packages.$inferSelect;

// Subscription types
export const subscriptions = pgTable("subscriptions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  packageId: integer("package_id").notNull().references(() => packages.id),
  startDate: text("start_date").notNull(),
  endDate: text("end_date").notNull(),
  isActive: boolean("is_active").default(true),
  transactionId: text("transaction_id"),
  createdAt: text("created_at").default("now()"),
});

export const subscriptionsRelations = relations(subscriptions, ({ one }) => ({
  user: one(users, {
    fields: [subscriptions.userId],
    references: [users.id],
  }),
  package: one(packages, {
    fields: [subscriptions.packageId],
    references: [packages.id],
  }),
}));

export const insertSubscriptionSchema = createInsertSchema(subscriptions).pick({
  userId: true,
  packageId: true,
  startDate: true,
  endDate: true,
  isActive: true,
  transactionId: true,
});

export type InsertSubscription = z.infer<typeof insertSubscriptionSchema>;
export type Subscription = typeof subscriptions.$inferSelect;

// Question types
export const questions = pgTable("questions", {
  id: serial("id").primaryKey(),
  text: text("text").notNull(),
  category: text("category").notNull(),
  imageUrl: text("image_url"),
  isActive: boolean("is_active").default(true),
  createdAt: text("created_at").default("now()"),
});

export const questionsRelations = relations(questions, ({ many }) => ({
  answers: many(answers),
  examQuestions: many(examQuestions),
}));

export const insertQuestionSchema = createInsertSchema(questions).pick({
  text: true,
  category: true,
  imageUrl: true,
  isActive: true,
});

export type InsertQuestion = z.infer<typeof insertQuestionSchema>;
export type Question = typeof questions.$inferSelect;

// Answer types
export const answers = pgTable("answers", {
  id: serial("id").primaryKey(),
  questionId: integer("question_id").notNull().references(() => questions.id),
  text: text("text").notNull(),
  isCorrect: boolean("is_correct").default(false),
  createdAt: text("created_at").default("now()"),
});

export const answersRelations = relations(answers, ({ one }) => ({
  question: one(questions, {
    fields: [answers.questionId],
    references: [questions.id],
  }),
}));

export const insertAnswerSchema = createInsertSchema(answers).pick({
  questionId: true,
  text: true,
  isCorrect: true,
});

export type InsertAnswer = z.infer<typeof insertAnswerSchema>;
export type Answer = typeof answers.$inferSelect;

// Exam types
export const exams = pgTable("exams", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  startTime: text("start_time").notNull(),
  endTime: text("end_time"),
  isCompleted: boolean("is_completed").default(false),
  score: integer("score"),
  totalQuestions: integer("total_questions").notNull(),
  createdAt: text("created_at").default("now()"),
});

export const examsRelations = relations(exams, ({ one, many }) => ({
  user: one(users, {
    fields: [exams.userId],
    references: [users.id],
  }),
  examQuestions: many(examQuestions),
}));

export const insertExamSchema = createInsertSchema(exams).pick({
  userId: true,
  startTime: true,
  endTime: true,
  isCompleted: true,
  score: true,
  totalQuestions: true,
});

export type InsertExam = z.infer<typeof insertExamSchema>;
export type Exam = typeof exams.$inferSelect;

// Exam Question types
export const examQuestions = pgTable("exam_questions", {
  id: serial("id").primaryKey(),
  examId: integer("exam_id").notNull().references(() => exams.id),
  questionId: integer("question_id").notNull().references(() => questions.id),
  selectedAnswerId: integer("selected_answer_id"),
  isCorrect: boolean("is_correct"),
  createdAt: text("created_at").default("now()"),
});

export const examQuestionsRelations = relations(examQuestions, ({ one }) => ({
  exam: one(exams, {
    fields: [examQuestions.examId],
    references: [exams.id],
  }),
  question: one(questions, {
    fields: [examQuestions.questionId],
    references: [questions.id],
  }),
}));

export const insertExamQuestionSchema = createInsertSchema(examQuestions).pick({
  examId: true,
  questionId: true,
  selectedAnswerId: true,
  isCorrect: true,
});

export type InsertExamQuestion = z.infer<typeof insertExamQuestionSchema>;
export type ExamQuestion = typeof examQuestions.$inferSelect;

// Payment types
export const payments = pgTable("payments", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  packageId: integer("package_id").notNull().references(() => packages.id),
  amount: doublePrecision("amount").notNull(),
  currency: text("currency").notNull(),
  paymentMethod: text("payment_method").notNull(),
  transactionId: text("transaction_id").notNull().unique(),
  transactionRef: text("transaction_ref"),
  status: text("status").notNull(),
  metadata: text("metadata"),
  createdAt: text("created_at").default("now()"),
});

export const paymentsRelations = relations(payments, ({ one }) => ({
  user: one(users, {
    fields: [payments.userId],
    references: [users.id],
  }),
  package: one(packages, {
    fields: [payments.packageId],
    references: [packages.id],
  }),
}));

export const insertPaymentSchema = createInsertSchema(payments).pick({
  userId: true,
  packageId: true,
  amount: true,
  currency: true,
  paymentMethod: true,
  transactionId: true,
  transactionRef: true,
  status: true,
  metadata: true,
  createdAt: true,
});

export type InsertPayment = z.infer<typeof insertPaymentSchema>;
export type Payment = typeof payments.$inferSelect;
