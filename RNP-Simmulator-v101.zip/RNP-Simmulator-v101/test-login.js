// Test script to create a session for the test user
const express = require('express');
const { db } = require('./server/db');
const { eq } = require('drizzle-orm');
const { users } = require('./shared/schema');

const app = express();

app.get('/test-login', async (req, res) => {
  try {
    // Find the test user
    const [user] = await db.select().from(users).where(eq(users.id, 1));
    
    if (!user) {
      return res.status(404).send('Test user not found');
    }
    
    // Create session
    req.session.userId = user.id;
    req.session.email = user.email;
    
    res.send(`
      <h1>Test Login Successful</h1>
      <p>User ID: ${user.id}</p>
      <p>Email: ${user.email}</p>
      <p><a href="/dashboard">Go to Dashboard</a></p>
    `);
  } catch (error) {
    console.error('Test login error:', error);
    res.status(500).send('Error during test login');
  }
});

module.exports = app;