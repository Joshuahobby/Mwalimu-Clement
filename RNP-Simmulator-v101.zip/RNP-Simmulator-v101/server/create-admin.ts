// Script to create admin user in Firebase
import { initializeApp } from "firebase/app";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword } from "firebase/auth";
import { Pool } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-serverless';
import * as schema from '../shared/schema';
import { eq } from 'drizzle-orm';

// Firebase configuration - using environment variables directly
const firebaseConfig = {
  apiKey: process.env.VITE_FIREBASE_API_KEY,
  authDomain: `${process.env.VITE_FIREBASE_PROJECT_ID}.firebaseapp.com`,
  projectId: process.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: `${process.env.VITE_FIREBASE_PROJECT_ID}.firebasestorage.app`,
  appId: process.env.VITE_FIREBASE_APP_ID,
};

// Database connection
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const db = drizzle({ client: pool, schema });

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth();

// Admin email and password
const adminEmail = "admin@mwalimu.rw";
const adminPassword = "Admin123!"; // Stronger password

// Create admin user in Firebase and update the database
async function setupAdminUser() {
  try {
    console.log("Firebase config:", process.env.VITE_FIREBASE_API_KEY ? "API key present" : "API key missing");
    console.log("Setting up admin user...");
    
    let userCredential;
    let firebaseUid;
    
    try {
      // Try to create a new user
      userCredential = await createUserWithEmailAndPassword(auth, adminEmail, adminPassword);
      firebaseUid = userCredential.user.uid;
      console.log("Admin user created in Firebase with UID:", firebaseUid);
    } catch (error: any) {
      // If user already exists, try to sign in to get the UID
      if (error.code === "auth/email-already-in-use") {
        console.log("Admin user already exists in Firebase, signing in to get UID...");
        userCredential = await signInWithEmailAndPassword(auth, adminEmail, adminPassword);
        firebaseUid = userCredential.user.uid;
        console.log("Got existing admin UID:", firebaseUid);
      } else {
        throw error;
      }
    }
    
    // Now update the admin user in the database with the Firebase UID
    const result = await db.update(schema.users)
      .set({ firebaseUid: firebaseUid })
      .where(eq(schema.users.email, adminEmail))
      .returning();
    
    console.log("Updated admin user in database:", result);
    console.log("\nAdmin user setup complete!");
    console.log(`Email: ${adminEmail}`);
    console.log(`Password: ${adminPassword}`);
    console.log("You can now login with these credentials in the application.");
    
  } catch (error) {
    console.error("Error setting up admin user:", error);
  } finally {
    await pool.end();
  }
}

// Run the function
setupAdminUser();