import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { registerSchema, loginSchema } from "@/lib/validators/auth";
import { initializeApp } from "firebase/app";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword } from "firebase/auth";

// Firebase configuration
const firebaseConfig = {
  apiKey: process.env.VITE_FIREBASE_API_KEY || "",
  authDomain: `${process.env.VITE_FIREBASE_PROJECT_ID || ""}.firebaseapp.com`,
  projectId: process.env.VITE_FIREBASE_PROJECT_ID || "",
  storageBucket: `${process.env.VITE_FIREBASE_PROJECT_ID || ""}.appspot.com`,
  appId: process.env.VITE_FIREBASE_APP_ID || "",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

export async function registerRoutes(app: Express): Promise<Server> {
  // Authentication routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      // Create a modified schema without confirmPassword validation for the server
      const serverRegisterSchema = z.object({
        email: z.string().email("Please enter a valid email address"),
        password: z.string().min(6, "Password must be at least 6 characters"),
        confirmPassword: z.string().optional(),
        fullName: z.string().optional(),
        phoneNumber: z.string().min(10, "Phone number must be at least 10 digits")
      });
      
      // Validate request body
      const validatedData = serverRegisterSchema.parse(req.body);
      
      // Create user with Firebase
      const { email, password, fullName, phoneNumber } = validatedData;
      
      // Check if user already exists in our database
      const dbUser = await storage.getUserByEmail(email);
      if (dbUser) {
        return res.status(400).json({ message: "User with this email already exists" });
      }
      
      // Get Firebase user (either newly created or existing)
      let firebaseUser;
      
      try {
        // Attempt to create new Firebase user
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        firebaseUser = userCredential.user;
      } catch (firebaseError: any) {
        console.error("Firebase registration error:", firebaseError);
        throw firebaseError;
      }
      
      // Create new user in database
      const user = await storage.createUser({
        email: email,
        firebaseUid: firebaseUser.uid,
        fullName,
        phoneNumber,
        role: "user"
      });
      
      // Create session after successful registration
      req.session.userId = user.id;
      req.session.email = email;
      
      // Add user role to response headers for client-side redirection
      res.setHeader('X-User-Role', user.role || 'user');
      res.status(201).json({ message: "User registered successfully" });
    } catch (error: any) {
      console.error("Registration error:", error);
      
      // Handle Firebase specific errors
      if (error.code) {
        switch (error.code) {
          case "auth/email-already-in-use":
            return res.status(400).json({ message: "Email is already in use" });
          case "auth/invalid-email":
            return res.status(400).json({ message: "Invalid email format" });
          case "auth/weak-password":
            return res.status(400).json({ message: "Password is too weak" });
          default:
            return res.status(500).json({ message: `Firebase error: ${error.message}` });
        }
      }
      
      // Handle validation errors
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: error.errors.map(e => ({ field: e.path.join('.'), message: e.message }))
        });
      }
      
      res.status(500).json({ message: "An error occurred during registration" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      // Validate request body
      const validatedData = loginSchema.parse(req.body);
      
      // Login with Firebase
      const { email, password } = validatedData;
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      const firebaseUser = userCredential.user;
      
      // Get user from database
      const user = await storage.getUserByFirebaseUid(firebaseUser.uid);
      if (!user) {
        // Create user if not exists (this can happen if firebase user was created but db insert failed)
        await storage.createUser({
          email: email,
          firebaseUid: firebaseUser.uid,
        });
      }
      
      // Create session
      req.session.userId = user?.id;
      req.session.email = email;
      
      // Add user role to response headers for client-side redirection
      res.setHeader('X-User-Role', user?.role || 'user');
      res.status(200).json({ message: "Login successful" });
    } catch (error: any) {
      console.error("Login error:", error);
      
      // Handle Firebase specific errors
      if (error.code) {
        switch (error.code) {
          case "auth/user-not-found":
          case "auth/wrong-password":
            return res.status(401).json({ message: "Invalid email or password" });
          case "auth/too-many-requests":
            return res.status(429).json({ message: "Too many attempts, please try again later" });
          default:
            return res.status(500).json({ message: `Firebase error: ${error.message}` });
        }
      }
      
      // Handle validation errors
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: error.errors.map(e => ({ field: e.path.join('.'), message: e.message }))
        });
      }
      
      res.status(500).json({ message: "An error occurred during login" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy(err => {
      if (err) {
        return res.status(500).json({ message: "Failed to logout" });
      }
      res.status(200).json({ message: "Logged out successfully" });
    });
  });

  app.get("/api/auth/me", async (req, res) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    const user = await storage.getUser(req.session.userId);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    
    // Don't return sensitive info
    const { firebaseUid, ...safeUserData } = user;
    res.status(200).json(safeUserData);
  });
  
  // API endpoint to provide flutterwave config
  app.get('/api/config/flutterwave', (req, res) => {
    const publicKey = process.env.FLUTTERWAVE_PUBLIC_KEY;
    if (!publicKey) {
      return res.status(500).json({ message: "Flutterwave public key not configured" });
    }
    
    res.json({ 
      publicKey,
      testMode: true,
      testOtpCode: "123456"
    });
  });
  
  // Social login route (Google, etc.)
  app.post("/api/auth/social-login", async (req, res) => {
    try {
      const { email, fullName, phoneNumber, token, providerId, uid } = req.body;
      
      if (!email) {
        return res.status(400).json({ message: "Email is required" });
      }
      
      if (!phoneNumber || phoneNumber.length < 10) {
        return res.status(400).json({ message: "Valid phone number is required" });
      }
      
      // Check if user already exists either by email or firebase UID
      let user = await storage.getUserByEmail(email);
      
      if (!user && uid) {
        // If not found by email, try by Firebase UID
        user = await storage.getUserByFirebaseUid(uid);
      }
      
      if (user) {
        // User exists, update session
        req.session.userId = user.id;
        req.session.email = email;
        // Add user role to response headers for client-side redirection
        res.setHeader('X-User-Role', user.role || 'user');
        return res.status(200).json({ message: "Login successful" });
      }
      
      // Create new user
      user = await storage.createUser({
        email,
        fullName: fullName || "Google User",
        phoneNumber: phoneNumber || "",
        firebaseUid: uid || `${providerId}:${email}`, // Create a unique ID if Firebase UID not provided
        role: "user"
      });
      
      // Set session
      req.session.userId = user.id;
      req.session.email = email;
      
      // Add user role to response headers for client-side redirection
      res.setHeader('X-User-Role', user.role || 'user');
      res.status(201).json({ message: "User registered and logged in successfully" });
    } catch (error: any) {
      console.error("Social login error:", error);
      res.status(500).json({ message: "An error occurred during social login" });
    }
  });
  
  // Handle phone number based login/registration
  app.post("/api/auth/phone-login", async (req, res) => {
    try {
      const { phoneNumber, password } = req.body;
      
      if (!phoneNumber) {
        return res.status(400).json({ message: "Phone number is required" });
      }
      
      // Generate email from phone number
      const email = `${phoneNumber.replace(/[^0-9]/g, '')}@user.mwalimu.rw`;
      
      // Try to login with Firebase
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      const firebaseUser = userCredential.user;
      
      // Get user from database
      let user = await storage.getUserByFirebaseUid(firebaseUser.uid);
      
      if (!user) {
        // If Firebase login succeeded but user not in DB, create the user
        user = await storage.createUser({
          email,
          firebaseUid: firebaseUser.uid,
          phoneNumber,
          role: "user"
        });
      }
      
      // Create session
      req.session.userId = user.id;
      req.session.email = email;
      
      // Add user role to response headers for client-side redirection
      res.setHeader('X-User-Role', user.role || 'user');
      res.status(200).json({ message: "Login successful" });
    } catch (error: any) {
      console.error("Phone login error:", error);
      
      // Handle Firebase specific errors
      if (error.code) {
        switch (error.code) {
          case "auth/user-not-found":
          case "auth/wrong-password":
            return res.status(401).json({ message: "Invalid phone number or password" });
          case "auth/too-many-requests":
            return res.status(429).json({ message: "Too many attempts, please try again later" });
          default:
            return res.status(500).json({ message: `Firebase error: ${error.message}` });
        }
      }
      
      res.status(500).json({ message: "An error occurred during login" });
    }
  });

  // Package routes
  app.get("/api/packages", async (req, res) => {
    try {
      const packages = await storage.getAllPackages();
      res.status(200).json({ packages });
    } catch (error) {
      console.error("Error fetching packages:", error);
      res.status(500).json({ message: "Failed to fetch packages" });
    }
  });

  app.get("/api/packages/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid package ID" });
      }

      const packageItem = await storage.getPackage(id);
      if (!packageItem) {
        return res.status(404).json({ message: "Package not found" });
      }

      res.status(200).json({ package: packageItem });
    } catch (error) {
      console.error("Error fetching package:", error);
      res.status(500).json({ message: "Failed to fetch package" });
    }
  });
  
  // Test login route for development - regular user
  app.get("/test-login", async (req, res) => {
    try {
      // Find the test user
      const user = await storage.getUser(1);
      
      if (!user) {
        return res.status(404).send('Test user not found');
      }
      
      // Create session
      req.session.userId = user.id;
      req.session.email = user.email;
      
      // Instead of showing a page, just redirect to the dashboard
      res.redirect('/dashboard');
    } catch (error) {
      console.error('Test login error:', error);
      res.status(500).send('Error during test login');
    }
  });
  
  // Test login route for development - admin user
  app.get("/test-admin-login", async (req, res) => {
    try {
      // Find the admin user
      const adminUser = await storage.getUserByEmail('admin@mwalimu.rw');
      
      if (!adminUser) {
        return res.status(404).send('Admin user not found');
      }
      
      // Create session
      req.session.userId = adminUser.id;
      req.session.email = adminUser.email;
      
      // Redirect to admin dashboard
      res.redirect('/admin');
    } catch (error) {
      console.error('Admin login error:', error);
      res.status(500).send('Error during admin login');
    }
  });
  
  // Admin routes
  app.get("/api/admin/stats", async (req, res) => {
    try {
      if (!req.session.userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      // Check if user is admin
      const user = await storage.getUser(req.session.userId);
      if (!user || user.role !== 'admin') {
        return res.status(403).json({ message: "Not authorized" });
      }
      
      // Get stats from storage
      const stats = await storage.getStats();
      
      res.status(200).json({ stats });
    } catch (error) {
      console.error("Error fetching admin stats:", error);
      res.status(500).json({ message: "Failed to fetch admin stats" });
    }
  });
  
  app.get("/api/admin/users", async (req, res) => {
    try {
      if (!req.session.userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      // Check if user is admin
      const user = await storage.getUser(req.session.userId);
      if (!user || user.role !== 'admin') {
        return res.status(403).json({ message: "Not authorized" });
      }
      
      // Get all users
      const users = await storage.getAllUsers();
      
      res.status(200).json({ users });
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });
  
  app.get("/api/admin/questions", async (req, res) => {
    try {
      if (!req.session.userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      // Check if user is admin
      const user = await storage.getUser(req.session.userId);
      if (!user || user.role !== 'admin') {
        return res.status(403).json({ message: "Not authorized" });
      }
      
      // Get all questions with answers
      const questions = await storage.getAllQuestions();
      
      // Get answers for each question
      const questionsWithAnswers = await Promise.all(
        questions.map(async (question) => {
          const answers = await storage.getAnswersForQuestion(question.id);
          return {
            ...question,
            answers,
          };
        })
      );
      
      res.status(200).json({ questions: questionsWithAnswers });
    } catch (error) {
      console.error("Error fetching questions:", error);
      res.status(500).json({ message: "Failed to fetch questions" });
    }
  });
  
  // Payment verification route
  // Payment verification from client side
  app.post("/api/payments/verify", async (req, res) => {
    try {
      if (!req.session.userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      // Validate the request payload
      const { transaction_id, tx_ref, amount, currency, package_id } = req.body;
      
      if (!transaction_id || !tx_ref) {
        return res.status(400).json({ message: "Missing required transaction information" });
      }
      
      let packageId = package_id;
      
      // If package_id is not provided, try to extract it from tx_ref metadata
      // Format of tx_ref: tx-timestamp-random-packageId
      if (!packageId && tx_ref.includes('-')) {
        const parts = tx_ref.split('-');
        // Check if we can extract package ID from the tx_ref (format may vary)
        // This is just a fallback mechanism
        if (parts.length >= 3) {
          // Try to extract metadata that might have been embedded in tx_ref
          try {
            // For redirects from Flutterwave, try to extract from the last part
            packageId = parseInt(parts[parts.length - 1]);
          } catch (e) {
            console.log("Could not parse package ID from tx_ref:", tx_ref);
          }
        }
      }
      
      // Fetch the package to verify the amount
      const packageData = await storage.getPackage(packageId);
      if (!packageData) {
        return res.status(404).json({ message: "Package not found" });
      }
      
      // Verify with Flutterwave using their API
      const secretKey = process.env.FLUTTERWAVE_SECRET_KEY;
      if (!secretKey) {
        throw new Error("Flutterwave secret key not configured");
      }
      
      try {
        // Make a verification request to Flutterwave
        const verifyResponse = await fetch(`https://api.flutterwave.com/v3/transactions/${transaction_id}/verify`, {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${secretKey}`,
            'Content-Type': 'application/json'
          }
        });
        
        // Parse the response
        const verifyData = await verifyResponse.json();
        
        // Log the response for debugging
        console.log("Flutterwave verification response:", JSON.stringify(verifyData, null, 2));
        
        // Check if verification was successful
        if (verifyData.status !== "success") {
          // For development: Log failure but don't block
          console.error("Payment verification failed with Flutterwave:", verifyData);
          
          if (process.env.NODE_ENV === 'production') {
            return res.status(400).json({ message: "Payment verification failed with provider" });
          } else {
            console.log("Using test verification in development mode");
            // Continue with a mock verification for testing
          }
        } else {
          // Verify the amount matches only if we got a success response
          if (verifyData.data && verifyData.data.amount < packageData.price) {
            console.warn(`Amount mismatch: paid ${verifyData.data.amount}, expected ${packageData.price}`);
            
            if (process.env.NODE_ENV === 'production') {
              return res.status(400).json({ message: "Payment amount does not match package price" });
            } else {
              console.log("Ignoring amount mismatch in development mode");
            }
          }
        }
        
        // Check if this transaction has already been processed
        const existingPayment = await storage.getPaymentByTransactionId(transaction_id);
        if (existingPayment) {
          return res.status(200).json({ 
            success: true, 
            message: "Payment already processed",
            payment: existingPayment
          });
        }
        
        // Proceed with creating payment record
        const payment = await storage.createPayment({
          userId: req.session.userId,
          packageId: packageId,
          // Use the amount from Flutterwave API if available, otherwise use the client-provided amount
          amount: verifyData.data && verifyData.data.amount ? parseFloat(verifyData.data.amount) : parseFloat(amount),
          currency: verifyData.data && verifyData.data.currency ? verifyData.data.currency : (currency || "RWF"),
          transactionId: transaction_id,
          transactionRef: tx_ref,
          status: "completed",
          paymentMethod: "flutterwave",
          metadata: JSON.stringify(verifyData),
          createdAt: new Date().toISOString()
        });
        
        // Create a subscription based on the package
        const startDate = new Date();
        const endDate = new Date(startDate.getTime() + (packageData.duration * 60 * 60 * 1000));
        
        const subscription = await storage.createSubscription({
          userId: req.session.userId,
          packageId: packageId,
          startDate: startDate.toISOString(),
          endDate: endDate.toISOString(),
          isActive: true,
          transactionId: transaction_id
        });
        
        res.status(200).json({ 
          success: true,
          message: "Payment verified and subscription activated",
          payment,
          subscription
        });
      } catch (verifyError) {
        console.error("Error connecting to Flutterwave API:", verifyError);
        
        // For development environment, we'll proceed with a mock verification
        // Remove this in production or make it conditional based on environment
        console.log("Using mock verification for development");
        
        const verifyData = {
          status: "success",
          data: {
            id: transaction_id,
            tx_ref,
            amount: parseFloat(amount),
            currency: currency || "RWF",
            customer: {
              email: req.session.email
            }
          }
        };
        
        // Create payment record with mock data
        const payment = await storage.createPayment({
          userId: req.session.userId,
          packageId: packageId,
          amount: parseFloat(amount),
          currency: currency || "RWF",
          transactionId: transaction_id,
          transactionRef: tx_ref,
          status: "completed", 
          paymentMethod: "flutterwave",
          metadata: JSON.stringify(verifyData),
          createdAt: new Date().toISOString()
        });
        
        // Create subscription
        const startDate = new Date();
        const endDate = new Date(startDate.getTime() + (packageData.duration * 60 * 60 * 1000));
        
        const subscription = await storage.createSubscription({
          userId: req.session.userId,
          packageId: packageId,
          startDate: startDate.toISOString(),
          endDate: endDate.toISOString(),
          isActive: true,
          transactionId: transaction_id
        });
        
        res.status(200).json({ 
          success: true,
          message: "Payment verified (mock) and subscription activated",
          payment,
          subscription
        });
      }
    } catch (error) {
      console.error("Payment verification error:", error);
      res.status(500).json({ message: "Failed to verify payment" });
    }
  });
  
  // Webhook handler for Flutterwave callbacks
  app.post("/api/payments/webhook", async (req, res) => {
    try {
      // Verify webhook signature using the secret hash
      const secretHash = process.env.FLUTTERWAVE_SECRET_HASH;
      const signature = req.headers['verif-hash'];
      
      if (!secretHash || !signature || signature !== secretHash) {
        console.error("Invalid webhook signature");
        return res.status(401).send("Unauthorized");
      }
      
      const eventData = req.body;
      console.log("Received Flutterwave webhook:", JSON.stringify(eventData));
      
      // Handle different event types
      if (eventData.event === 'charge.completed' && eventData.data.status === 'successful') {
        const { id, tx_ref, amount, currency, meta } = eventData.data;
        
        // Check if this transaction has already been processed
        const existingPayment = await storage.getPaymentByTransactionId(id.toString());
        if (existingPayment) {
          console.log(`Payment ${id} already processed`);
          return res.status(200).send("Webhook received - payment already processed");
        }
        
        // Get user and package from meta data
        const { user_id, package_id } = meta || {};
        if (!user_id || !package_id) {
          console.error("Missing user_id or package_id in webhook meta data");
          return res.status(400).send("Missing required meta data");
        }
        
        // Fetch necessary data
        const [user, packageData] = await Promise.all([
          storage.getUser(parseInt(user_id)),
          storage.getPackage(parseInt(package_id))
        ]);
        
        if (!user || !packageData) {
          console.error(`User ${user_id} or package ${package_id} not found`);
          return res.status(404).send("User or package not found");
        }
        
        // Create payment record
        const payment = await storage.createPayment({
          userId: parseInt(user_id),
          packageId: parseInt(package_id),
          amount: parseFloat(amount),
          currency: currency,
          transactionId: id.toString(),
          transactionRef: tx_ref,
          status: "completed",
          paymentMethod: "flutterwave",
          metadata: JSON.stringify(eventData.data),
          createdAt: new Date().toISOString()
        });
        
        // Create subscription
        const startDate = new Date();
        const endDate = new Date(startDate.getTime() + (packageData.duration * 60 * 60 * 1000));
        
        await storage.createSubscription({
          userId: parseInt(user_id),
          packageId: parseInt(package_id),
          startDate: startDate.toISOString(),
          endDate: endDate.toISOString(),
          isActive: true,
          transactionId: id.toString()
        });
        
        console.log(`Successfully processed webhook payment ${id} for user ${user_id}`);
      }
      
      // Always return 200 to acknowledge receipt of the webhook
      res.status(200).send("Webhook received");
    } catch (error) {
      console.error("Error processing webhook:", error);
      // Still send a 200 response to prevent Flutterwave from retrying
      res.status(200).send("Webhook received with processing error");
    }
  });

  app.get("/api/admin/payments", async (req, res) => {
    try {
      if (!req.session.userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      // Check if user is admin
      const user = await storage.getUser(req.session.userId);
      if (!user || user.role !== 'admin') {
        return res.status(403).json({ message: "Not authorized" });
      }
      
      // Get all payments
      const payments = await storage.getAllPayments();
      
      res.status(200).json({ payments });
    } catch (error) {
      console.error("Error fetching payments:", error);
      res.status(500).json({ message: "Failed to fetch payments" });
    }
  });

  // User payment history
  app.get("/api/payments/user", async (req, res) => {
    try {
      if (!req.session.userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      // Get user payments
      const payments = await storage.getUserPayments(req.session.userId);
      
      // We need to fetch package details for each payment
      const enrichedPayments = await Promise.all(
        payments.map(async (payment) => {
          const packageData = await storage.getPackage(payment.packageId);
          return {
            ...payment,
            package: packageData ? { name: packageData.name } : undefined
          };
        })
      );
      
      res.status(200).json({ payments: enrichedPayments });
    } catch (error) {
      console.error("Error fetching user payments:", error);
      res.status(500).json({ message: "Failed to fetch payment history" });
    }
  });

  // Subscription routes
  app.get("/api/subscriptions/active", async (req, res) => {
    try {
      if (!req.session.userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }

      const subscription = await storage.getUserActiveSubscription(req.session.userId);
      if (!subscription) {
        return res.status(404).json({ message: "No active subscription found" });
      }

      res.status(200).json(subscription);
    } catch (error) {
      console.error("Error fetching active subscription:", error);
      res.status(500).json({ message: "Failed to fetch active subscription" });
    }
  });

  // Exam routes
  app.post("/api/exams/start", async (req, res) => {
    try {
      if (!req.session.userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }

      // Check if user has an active subscription
      const subscription = await storage.getUserActiveSubscription(req.session.userId);
      if (!subscription || !subscription.isActive) {
        return res.status(403).json({ message: "No active subscription" });
      }
      
      // Fixed number of questions as per requirements - always 20 questions
      const FIXED_QUESTION_COUNT = 20;

      // Create a new exam
      const exam = await storage.createExam({
        userId: req.session.userId,
        startTime: new Date().toISOString(),
        isCompleted: false,
        totalQuestions: FIXED_QUESTION_COUNT
      });

      // Get all available questions
      const availableQuestions = await storage.getAllQuestions();
      
      if (availableQuestions.length === 0) {
        return res.status(500).json({ message: "No questions available in the database" });
      }
      
      // If we have fewer than 20 questions, we'll use them multiple times to make up the 20
      const questionPool = [];
      
      // Keep adding questions until we have 20
      while (questionPool.length < FIXED_QUESTION_COUNT) {
        // Shuffle the available questions for variety when reusing
        const shuffled = [...availableQuestions].sort(() => 0.5 - Math.random());
        
        // Add only as many as needed to reach 20
        const needed = Math.min(FIXED_QUESTION_COUNT - questionPool.length, shuffled.length);
        questionPool.push(...shuffled.slice(0, needed));
      }
      
      // Create exam questions - exactly 20 as required
      for (const question of questionPool) {
        await storage.createExamQuestion({
          examId: exam.id,
          questionId: question.id
        });
      }

      res.status(201).json({ 
        message: "Exam started successfully", 
        examId: exam.id,
        totalQuestions: FIXED_QUESTION_COUNT
      });
    } catch (error) {
      console.error("Error starting exam:", error);
      res.status(500).json({ message: "Failed to start exam" });
    }
  });

  // Get exam history for authenticated user
  app.get("/api/exams/history", async (req, res) => {
    try {
      if (!req.session.userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }

      const exams = await storage.getUserExams(req.session.userId);
      
      res.status(200).json({ exams });
    } catch (error) {
      console.error("Error fetching exam history:", error);
      res.status(500).json({ message: "Failed to fetch exam history" });
    }
  });

  // Get specific exam by ID
  app.get("/api/exams/:id", async (req, res) => {
    try {
      if (!req.session.userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }

      const examId = parseInt(req.params.id);
      if (isNaN(examId)) {
        return res.status(400).json({ message: "Invalid exam ID" });
      }

      // Get exam with questions
      const examData = await storage.getExamWithQuestions(examId);
      if (!examData || examData.exam.userId !== req.session.userId) {
        return res.status(404).json({ message: "Exam not found" });
      }

      // Calculate time remaining if exam is not completed
      let timeRemaining = 0;
      if (!examData.exam.isCompleted) {
        const startTime = new Date(examData.exam.startTime);
        const now = new Date();
        const examDuration = 20 * 60; // 20 minutes in seconds (per requirements)
        const elapsedSeconds = Math.floor((now.getTime() - startTime.getTime()) / 1000);
        timeRemaining = Math.max(0, examDuration - elapsedSeconds);
      }

      res.status(200).json({
        exam: examData.exam,
        questions: examData.questions,
        timeRemaining
      });
    } catch (error) {
      console.error("Error fetching exam:", error);
      res.status(500).json({ message: "Failed to fetch exam" });
    }
  });

  app.post("/api/exams/:id/answer", async (req, res) => {
    try {
      if (!req.session.userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }

      const examId = parseInt(req.params.id);
      if (isNaN(examId)) {
        return res.status(400).json({ message: "Invalid exam ID" });
      }

      const { questionId, answerId } = req.body;
      if (!questionId || !answerId) {
        return res.status(400).json({ message: "Question ID and answer ID are required" });
      }

      // Get exam
      const exam = await storage.getExam(examId);
      if (!exam || exam.userId !== req.session.userId) {
        return res.status(404).json({ message: "Exam not found" });
      }

      if (exam.isCompleted) {
        return res.status(400).json({ message: "Exam is already completed" });
      }

      // Get exam question
      const examQuestions = await storage.getExamQuestionsForExam(examId);
      const examQuestion = examQuestions.find(eq => eq.questionId === questionId);
      if (!examQuestion) {
        return res.status(404).json({ message: "Question not found in this exam" });
      }

      // Get question with answers
      const question = await storage.getQuestion(questionId);
      if (!question) {
        return res.status(404).json({ message: "Question not found" });
      }

      const answers = await storage.getAnswersForQuestion(questionId);
      const selectedAnswer = answers.find(a => a.id === answerId);
      if (!selectedAnswer) {
        return res.status(404).json({ message: "Answer not found" });
      }

      // Update exam question
      await storage.updateExamQuestion(examQuestion.id, {
        selectedAnswerId: answerId,
        isCorrect: selectedAnswer.isCorrect
      });

      res.status(200).json({ message: "Answer recorded successfully" });
    } catch (error) {
      console.error("Error recording answer:", error);
      res.status(500).json({ message: "Failed to record answer" });
    }
  });

  app.post("/api/exams/:id/complete", async (req, res) => {
    try {
      if (!req.session.userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }

      const examId = parseInt(req.params.id);
      if (isNaN(examId)) {
        return res.status(400).json({ message: "Invalid exam ID" });
      }

      // Get exam
      const exam = await storage.getExam(examId);
      if (!exam || exam.userId !== req.session.userId) {
        return res.status(404).json({ message: "Exam not found" });
      }

      if (exam.isCompleted) {
        return res.status(400).json({ message: "Exam is already completed" });
      }

      // Get all exam questions
      const examQuestions = await storage.getExamQuestionsForExam(examId);
      
      // Calculate score
      const answeredQuestions = examQuestions.filter(eq => eq.selectedAnswerId !== null && eq.selectedAnswerId !== undefined);
      const correctAnswers = answeredQuestions.filter(eq => eq.isCorrect).length;
      const score = Math.round((correctAnswers / exam.totalQuestions) * 100);

      // Update exam
      await storage.updateExam(examId, {
        endTime: new Date().toISOString(),
        isCompleted: true,
        score
      });

      res.status(200).json({ 
        message: "Exam completed successfully",
        score,
        totalQuestions: exam.totalQuestions,
        correctAnswers
      });
    } catch (error) {
      console.error("Error completing exam:", error);
      res.status(500).json({ message: "Failed to complete exam" });
    }
  });

  const httpServer = createServer(app);
  
  return httpServer;
}
