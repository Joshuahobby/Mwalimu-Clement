import { 
  User, InsertUser,
  Package, InsertPackage,
  Subscription, InsertSubscription,
  Question, InsertQuestion,
  Answer, InsertAnswer,
  Exam, InsertExam,
  ExamQuestion, InsertExamQuestion,
  Payment, InsertPayment,
  users, packages, subscriptions, 
  questions, answers, exams, examQuestions, payments
} from '@shared/schema';
import { db } from './db';
import { IStorage } from './storage';
import { eq, desc, and, sql, count } from 'drizzle-orm';
import * as schema from '@shared/schema';
import connectPg from 'connect-pg-simple';
import session from 'express-session';

const PostgresSessionStore = connectPg(session);

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    this.sessionStore = new PostgresSessionStore({ 
      conObject: {
        connectionString: process.env.DATABASE_URL!,
        ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false
      },
      createTableIfMissing: true
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }
  
  async getUserByFirebaseUid(firebaseUid: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.firebaseUid, firebaseUid));
    return user;
  }

  async createUser(user: InsertUser): Promise<User> {
    const [newUser] = await db.insert(users).values(user).returning();
    return newUser;
  }

  async getUserActiveSubscription(userId: number): Promise<Subscription | undefined> {
    const now = new Date();
    const [subscription] = await db
      .select()
      .from(subscriptions)
      .where(
        and(
          eq(subscriptions.userId, userId),
          eq(subscriptions.isActive, true),
          sql`${subscriptions.endDate} > ${now}`
        )
      )
      .orderBy(desc(subscriptions.createdAt))
      .limit(1);
    
    return subscription;
  }

  // Package operations
  async getAllPackages(): Promise<Package[]> {
    return await db.select().from(packages);
  }

  async getPackage(id: number): Promise<Package | undefined> {
    const [pkg] = await db.select().from(packages).where(eq(packages.id, id));
    return pkg;
  }

  async getPackageByType(type: string): Promise<Package | undefined> {
    const [pkg] = await db.select().from(packages).where(eq(packages.type, type));
    return pkg;
  }

  async createPackage(packageData: InsertPackage): Promise<Package> {
    const [newPackage] = await db.insert(packages).values(packageData).returning();
    return newPackage;
  }

  // Subscription operations
  async createSubscription(subscription: InsertSubscription): Promise<Subscription> {
    const [newSubscription] = await db.insert(subscriptions).values(subscription).returning();
    return newSubscription;
  }

  async updateSubscription(id: number, data: Partial<Subscription>): Promise<Subscription> {
    const [updatedSubscription] = await db
      .update(subscriptions)
      .set(data)
      .where(eq(subscriptions.id, id))
      .returning();
    
    return updatedSubscription;
  }

  async getSubscription(id: number): Promise<Subscription | undefined> {
    const [subscription] = await db.select().from(subscriptions).where(eq(subscriptions.id, id));
    return subscription;
  }

  // Question operations
  async getAllQuestions(): Promise<Question[]> {
    return await db.select().from(questions);
  }

  async getQuestion(id: number): Promise<Question | undefined> {
    const [question] = await db.select().from(questions).where(eq(questions.id, id));
    return question;
  }

  async getRandomQuestions(count: number): Promise<Question[]> {
    // PostgreSQL-specific random selection
    return await db
      .select()
      .from(questions)
      .where(eq(questions.isActive, true))
      .orderBy(sql`RANDOM()`)
      .limit(count);
  }

  async createQuestion(question: InsertQuestion): Promise<Question> {
    const [newQuestion] = await db.insert(questions).values(question).returning();
    return newQuestion;
  }

  async updateQuestion(id: number, data: Partial<Question>): Promise<Question> {
    const [updatedQuestion] = await db
      .update(questions)
      .set(data)
      .where(eq(questions.id, id))
      .returning();
    
    return updatedQuestion;
  }

  async deleteQuestion(id: number): Promise<boolean> {
    const result = await db.delete(questions).where(eq(questions.id, id));
    return true; // In PostgreSQL, if no error occurred, the delete was successful
  }

  // Answer operations
  async getAnswersForQuestion(questionId: number): Promise<Answer[]> {
    return await db.select().from(answers).where(eq(answers.questionId, questionId));
  }

  async createAnswer(answer: InsertAnswer): Promise<Answer> {
    const [newAnswer] = await db.insert(answers).values(answer).returning();
    return newAnswer;
  }

  async updateAnswer(id: number, data: Partial<Answer>): Promise<Answer> {
    const [updatedAnswer] = await db
      .update(answers)
      .set(data)
      .where(eq(answers.id, id))
      .returning();
    
    return updatedAnswer;
  }

  async deleteAnswer(id: number): Promise<boolean> {
    const result = await db.delete(answers).where(eq(answers.id, id));
    return true;
  }

  // Exam operations
  async createExam(exam: InsertExam): Promise<Exam> {
    const [newExam] = await db.insert(exams).values(exam).returning();
    return newExam;
  }

  async getExam(id: number): Promise<Exam | undefined> {
    const [exam] = await db.select().from(exams).where(eq(exams.id, id));
    return exam;
  }

  async getUserExams(userId: number): Promise<Exam[]> {
    return await db
      .select()
      .from(exams)
      .where(eq(exams.userId, userId))
      .orderBy(desc(exams.createdAt));
  }

  async updateExam(id: number, data: Partial<Exam>): Promise<Exam> {
    const [updatedExam] = await db
      .update(exams)
      .set(data)
      .where(eq(exams.id, id))
      .returning();
    
    return updatedExam;
  }

  async getExamWithQuestions(examId: number): Promise<{
    exam: Exam;
    questions: (ExamQuestion & { question: Question; answers: Answer[] })[];
  }> {
    const [exam] = await db.select().from(exams).where(eq(exams.id, examId));
    
    if (!exam) {
      throw new Error('Exam not found');
    }
    
    const examQuestionsResult = await db
      .select()
      .from(examQuestions)
      .where(eq(examQuestions.examId, examId));
    
    const questionsWithAnswers = await Promise.all(
      examQuestionsResult.map(async (examQuestion) => {
        const [question] = await db
          .select()
          .from(questions)
          .where(eq(questions.id, examQuestion.questionId));
        
        const answersResult = await db
          .select()
          .from(answers)
          .where(eq(answers.questionId, examQuestion.questionId));
        
        return {
          ...examQuestion,
          question,
          answers: answersResult,
        };
      })
    );
    
    return {
      exam,
      questions: questionsWithAnswers,
    };
  }

  // ExamQuestion operations
  async createExamQuestion(examQuestion: InsertExamQuestion): Promise<ExamQuestion> {
    const [newExamQuestion] = await db.insert(examQuestions).values(examQuestion).returning();
    return newExamQuestion;
  }

  async updateExamQuestion(id: number, data: Partial<ExamQuestion>): Promise<ExamQuestion> {
    const [updatedExamQuestion] = await db
      .update(examQuestions)
      .set(data)
      .where(eq(examQuestions.id, id))
      .returning();
    
    return updatedExamQuestion;
  }

  async getExamQuestionsForExam(examId: number): Promise<ExamQuestion[]> {
    return await db.select().from(examQuestions).where(eq(examQuestions.examId, examId));
  }

  // Payment operations
  async createPayment(payment: InsertPayment): Promise<Payment> {
    const [newPayment] = await db.insert(payments).values(payment).returning();
    return newPayment;
  }

  async getUserPayments(userId: number): Promise<Payment[]> {
    return await db
      .select()
      .from(payments)
      .where(eq(payments.userId, userId))
      .orderBy(desc(payments.createdAt));
  }

  async getAllPayments(): Promise<Payment[]> {
    return await db.select().from(payments).orderBy(desc(payments.createdAt));
  }

  async getPayment(id: number): Promise<Payment | undefined> {
    const [payment] = await db.select().from(payments).where(eq(payments.id, id));
    return payment;
  }

  async getPaymentByTransactionId(transactionId: string): Promise<Payment | undefined> {
    const [payment] = await db
      .select()
      .from(payments)
      .where(eq(payments.transactionId, transactionId));
    
    return payment;
  }

  // Admin operations
  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  async getStats(): Promise<{
    totalUsers: number;
    totalExams: number;
    totalRevenue: number;
    activeSubscriptions: number;
  }> {
    const now = new Date();

    // Count total users
    const [{ count: totalUsers }] = await db
      .select({ count: count() })
      .from(users);

    // Count total exams
    const [{ count: totalExams }] = await db
      .select({ count: count() })
      .from(exams);

    // Calculate total revenue
    const paymentsResult = await db
      .select({ amount: payments.amount })
      .from(payments)
      .where(eq(payments.status, 'completed'));

    const totalRevenue = paymentsResult.reduce((sum, payment) => sum + payment.amount, 0);

    // Count active subscriptions
    const [{ count: activeSubscriptions }] = await db
      .select({ count: count() })
      .from(subscriptions)
      .where(
        and(
          eq(subscriptions.isActive, true),
          sql`${subscriptions.endDate} > ${now}`
        )
      );

    return {
      totalUsers: Number(totalUsers),
      totalExams: Number(totalExams),
      totalRevenue,
      activeSubscriptions: Number(activeSubscriptions),
    };
  }
}