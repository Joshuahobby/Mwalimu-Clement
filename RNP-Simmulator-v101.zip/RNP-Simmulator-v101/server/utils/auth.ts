import { Request, Response, NextFunction } from 'express';
import { storage } from '../storage';
import { User } from '@shared/schema';

declare global {
  namespace Express {
    interface Request {
      user?: User;
    }
  }
}

// Middleware to check if user is authenticated
export const requireAuth = async (req: Request, res: Response, next: NextFunction) => {
  const userId = req.session?.userId;
  
  if (!userId) {
    return res.status(401).json({ message: 'Unauthorized. Please log in.' });
  }
  
  try {
    const user = await storage.getUser(userId);
    
    if (!user) {
      return res.status(401).json({ message: 'User not found. Please log in again.' });
    }
    
    // Add user to request object
    req.user = user;
    next();
  } catch (error) {
    console.error('Auth middleware error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

// Middleware to check if user is an admin
export const requireAdmin = async (req: Request, res: Response, next: NextFunction) => {
  const userId = req.session?.userId;
  
  if (!userId) {
    return res.status(401).json({ message: 'Unauthorized. Please log in.' });
  }
  
  try {
    const user = await storage.getUser(userId);
    
    if (!user) {
      return res.status(401).json({ message: 'User not found. Please log in again.' });
    }
    
    if (user.role !== 'admin') {
      return res.status(403).json({ message: 'Forbidden. Admin access required.' });
    }
    
    // Add user to request object
    req.user = user;
    next();
  } catch (error) {
    console.error('Admin auth middleware error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

// Middleware to check if the user has an active subscription
export const requireActiveSubscription = async (req: Request, res: Response, next: NextFunction) => {
  const userId = req.session?.userId;
  
  if (!userId) {
    return res.status(401).json({ message: 'Unauthorized. Please log in.' });
  }
  
  try {
    const user = await storage.getUser(userId);
    
    if (!user) {
      return res.status(401).json({ message: 'User not found. Please log in again.' });
    }
    
    const activeSubscription = await storage.getUserActiveSubscription(userId);
    
    if (!activeSubscription) {
      return res.status(403).json({ message: 'No active subscription found. Please purchase a package.' });
    }
    
    if (activeSubscription.isActive === false) {
      return res.status(403).json({ message: 'Your subscription is inactive. Please purchase a new package.' });
    }
    
    if (new Date(activeSubscription.endDate) < new Date()) {
      // Update subscription to inactive if expired
      await storage.updateSubscription(activeSubscription.id, { isActive: false });
      return res.status(403).json({ message: 'Your subscription has expired. Please purchase a new package.' });
    }
    
    // Add user to request object
    req.user = user;
    next();
  } catch (error) {
    console.error('Subscription middleware error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};
