import { 
  Exam, ExamQuestion, Question, Answer, InsertExamQuestion
} from '@shared/schema';
import { storage } from '../storage';

// Function to create a new exam with random questions
export const createExamWithQuestions = async (userId: number): Promise<Exam> => {
  try {
    // Create the exam
    const exam: Exam = await storage.createExam({
      userId,
      startTime: new Date(),
      isCompleted: false,
      totalQuestions: 20
    });
    
    // Get 20 random questions
    const randomQuestions: Question[] = await storage.getRandomQuestions(20);
    
    // Add questions to the exam
    for (const question of randomQuestions) {
      const examQuestion: InsertExamQuestion = {
        examId: exam.id,
        questionId: question.id,
      };
      await storage.createExamQuestion(examQuestion);
    }
    
    return exam;
  } catch (error) {
    console.error('Error creating exam with questions:', error);
    throw error;
  }
};

// Function to score an exam when completed
export const scoreExam = async (examId: number): Promise<{ score: number, totalQuestions: number, correctAnswers: number }> => {
  try {
    const examData = await storage.getExamWithQuestions(examId);
    const { exam, questions } = examData;
    
    if (exam.isCompleted) {
      throw new Error('Exam already completed');
    }
    
    // Count correct answers
    let correctAnswers = 0;
    
    for (const examQuestion of questions) {
      if (examQuestion.selectedAnswerId) {
        // Find if the selected answer is correct
        const answers = examQuestion.answers;
        const selectedAnswer = answers.find(a => a.id === examQuestion.selectedAnswerId);
        
        if (selectedAnswer && selectedAnswer.isCorrect) {
          correctAnswers++;
          // Update exam question to mark it as correct
          await storage.updateExamQuestion(examQuestion.id, { isCorrect: true });
        } else {
          // Update exam question to mark it as incorrect
          await storage.updateExamQuestion(examQuestion.id, { isCorrect: false });
        }
      }
    }
    
    // Calculate score percentage
    const score = Math.round((correctAnswers / exam.totalQuestions) * 100);
    
    // Update exam with score and mark as completed
    await storage.updateExam(examId, {
      score,
      isCompleted: true,
      endTime: new Date()
    });
    
    return {
      score,
      totalQuestions: exam.totalQuestions,
      correctAnswers
    };
  } catch (error) {
    console.error('Error scoring exam:', error);
    throw error;
  }
};

// Calculate if an exam is passed (usually 70% or more)
export const isExamPassed = (score: number): boolean => {
  return score >= 70;
};

// Calculate time remaining for an exam in seconds
export const calculateTimeRemaining = (exam: Exam): number => {
  if (exam.isCompleted || exam.endTime) {
    return 0;
  }
  
  const startTime = new Date(exam.startTime);
  const currentTime = new Date();
  const examDurationMs = 20 * 60 * 1000; // 20 minutes in milliseconds
  
  const elapsedMs = currentTime.getTime() - startTime.getTime();
  const remainingMs = Math.max(0, examDurationMs - elapsedMs);
  
  return Math.floor(remainingMs / 1000);
};
