import { 
  users, packages, subscriptions, questions, answers, exams, examQuestions, payments,
  type User, type InsertUser, 
  type Package, type InsertPackage, 
  type Subscription, type InsertSubscription,
  type Question, type InsertQuestion,
  type Answer, type InsertAnswer,
  type Exam, type InsertExam,
  type ExamQuestion, type InsertExamQuestion,
  type Payment, type InsertPayment
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, lt, gte, sql } from "drizzle-orm";

// Storage interface for data management
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByFirebaseUid(firebaseUid: string): Promise<User | undefined>;
  createUser(insertUser: InsertUser): Promise<User>;
  getAllUsers(): Promise<User[]>;
  
  // Package methods
  getAllPackages(): Promise<Package[]>;
  getPackage(id: number): Promise<Package | undefined>;
  getPackageByType(type: string): Promise<Package | undefined>;
  createPackage(insertPackage: InsertPackage): Promise<Package>;
  
  // Subscription methods
  getUserActiveSubscription(userId: number): Promise<Subscription | undefined>;
  createSubscription(subscription: InsertSubscription): Promise<Subscription>;
  updateSubscription(id: number, data: Partial<Subscription>): Promise<Subscription>;
  getSubscription(id: number): Promise<Subscription | undefined>;
  
  // Question methods
  getAllQuestions(): Promise<Question[]>;
  getQuestion(id: number): Promise<Question | undefined>;
  getRandomQuestions(count: number): Promise<Question[]>;
  createQuestion(question: InsertQuestion): Promise<Question>;
  updateQuestion(id: number, data: Partial<Question>): Promise<Question>;
  deleteQuestion(id: number): Promise<boolean>;
  
  // Answer methods
  getAnswersForQuestion(questionId: number): Promise<Answer[]>;
  createAnswer(answer: InsertAnswer): Promise<Answer>;
  updateAnswer(id: number, data: Partial<Answer>): Promise<Answer>;
  deleteAnswer(id: number): Promise<boolean>;
  
  // Exam methods
  createExam(exam: InsertExam): Promise<Exam>;
  getExam(id: number): Promise<Exam | undefined>;
  getUserExams(userId: number): Promise<Exam[]>;
  updateExam(id: number, data: Partial<Exam>): Promise<Exam>;
  getExamWithQuestions(examId: number): Promise<{
    exam: Exam;
    questions: (ExamQuestion & { question: Question; answers: Answer[] })[];
  }>;
  
  // Exam Question methods
  createExamQuestion(examQuestion: InsertExamQuestion): Promise<ExamQuestion>;
  updateExamQuestion(id: number, data: Partial<ExamQuestion>): Promise<ExamQuestion>;
  getExamQuestionsForExam(examId: number): Promise<ExamQuestion[]>;
  
  // Payment methods
  createPayment(payment: InsertPayment): Promise<Payment>;
  getUserPayments(userId: number): Promise<Payment[]>;
  getAllPayments(): Promise<Payment[]>;
  getPayment(id: number): Promise<Payment | undefined>;
  getPaymentByTransactionId(transactionId: string): Promise<Payment | undefined>;
  
  // Stats methods
  getStats(): Promise<{
    totalUsers: number;
    totalExams: number;
    totalRevenue: number;
    activeSubscriptions: number;
  }>;
}

import { DatabaseStorage } from './DatabaseStorage';

export const storage = new DatabaseStorage();