// Script to create admin user in Firebase
import { initializeApp } from "firebase/app";
import { getAuth, createUserWithEmailAndPassword } from "firebase/auth";
import * as dotenv from 'dotenv';

// Load environment variables
dotenv.config();

// Firebase configuration
const firebaseConfig = {
  apiKey: process.env.VITE_FIREBASE_API_KEY,
  authDomain: `${process.env.VITE_FIREBASE_PROJECT_ID}.firebaseapp.com`,
  projectId: process.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: `${process.env.VITE_FIREBASE_PROJECT_ID}.firebasestorage.app`,
  appId: process.env.VITE_FIREBASE_APP_ID,
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth();

// Admin email and password
const adminEmail = "admin@mwalimu.rw";
const adminPassword = "admin123"; // This is a temporary password, change it after first login

// Create admin user in Firebase
async function createAdminUser() {
  try {
    // Create user in Firebase
    console.log("Creating admin user in Firebase...");
    const userCredential = await createUserWithEmailAndPassword(auth, adminEmail, adminPassword);
    console.log("Admin user created successfully!");
    console.log("Admin UID:", userCredential.user.uid);
    console.log("Please update the firebase_uid in the users table with this UID");
  } catch (error) {
    console.error("Error creating admin user:", error);
    // If user already exists, you can sign in to get the UID
    if (error.code === "auth/email-already-in-use") {
      console.log("Admin user already exists. Please use the existing account or delete it first.");
    }
  }
}

// Run the function
createAdminUser();