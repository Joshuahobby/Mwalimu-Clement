import { initializeApp } from "firebase/app";
import { 
  getAuth, 
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  signInWithPopup,
  GoogleAuthProvider,
  type User,
  type UserCredential
} from "firebase/auth";

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || "",
  authDomain: `${import.meta.env.VITE_FIREBASE_PROJECT_ID || ""}.firebaseapp.com`,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || "",
  storageBucket: `${import.meta.env.VITE_FIREBASE_PROJECT_ID || ""}.appspot.com`,
  appId: import.meta.env.VITE_FIREBASE_APP_ID || "",
};

// Initialize Firebase app
let app;
try {
  app = initializeApp(firebaseConfig);
} catch (error) {
  console.error("Firebase initialization error:", error);
}

// Initialize Firebase Auth
export const auth = getAuth(app);

export const checkFirebaseConfig = (): boolean => {
  return !!(
    firebaseConfig.apiKey && 
    firebaseConfig.projectId &&
    firebaseConfig.appId
  );
};

// Register a new user
export const registerUser = async (email: string, password: string): Promise<User> => {
  try {
    // Try to create a new user
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    return userCredential.user;
  } catch (error: any) {
    console.error("Firebase registration error:", error);
    
    // Handle specific error cases
    if (error.code === 'auth/email-already-in-use') {
      throw new Error("This email is already registered. Please use a different email or try logging in instead.");
    } else if (error.code === 'auth/invalid-email') {
      throw new Error("The email address is not valid. Please enter a valid email.");
    } else if (error.code === 'auth/weak-password') {
      throw new Error("The password is too weak. Please use a stronger password.");
    }
    
    // For all other errors, throw with a more user-friendly message
    throw new Error("Registration failed: " + (error.message || "Unknown error"));
  }
};

// Login a user
export const loginUser = async (email: string, password: string): Promise<User> => {
  const userCredential = await signInWithEmailAndPassword(auth, email, password);
  return userCredential.user;
};

// Logout the current user
export const logoutUser = async (): Promise<void> => {
  await signOut(auth);
};

// Get the current user
export const getCurrentUser = (): User | null => {
  return auth.currentUser;
};

// Listen to auth state changes
export const onAuthStateChange = (callback: (user: User | null) => void) => {
  return onAuthStateChanged(auth, callback);
};

// Google sign in
export const signInWithGoogle = async (): Promise<{ user: User, token: string }> => {
  try {
    const provider = new GoogleAuthProvider();
    const result = await signInWithPopup(auth, provider);
    // This gives you a Google Access Token
    const credential = GoogleAuthProvider.credentialFromResult(result);
    const token = credential?.accessToken || '';
    return { user: result.user, token };
  } catch (error) {
    console.error("Google sign in error:", error);
    throw error;
  }
};
