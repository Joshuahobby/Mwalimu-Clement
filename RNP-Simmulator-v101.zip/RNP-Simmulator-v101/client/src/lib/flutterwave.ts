interface FlutterwaveConfig {
  public_key: string;
  tx_ref: string;
  amount: number;
  currency: string;
  payment_options: string;
  redirect_url: string;
  customer: {
    email: string;
    phone_number: string;
    name: string;
  };
  customizations: {
    title: string;
    description: string;
    logo: string;
  };
  meta: {
    package_id: number;
    user_id: number;
  };
}

interface FlutterwavePaymentOptions {
  packageId: number;
  userId: number;
  email: string;
  phoneNumber: string;  // This can be empty string
  fullName: string;     // This can be empty string
  amount: number;
  onSuccess: (data: any) => void;
  onClose: () => void;
}

declare global {
  interface Window {
    FlutterwaveCheckout: (config: FlutterwaveConfig) => void;
  }
}

export const initFlutterwavePayment = async (options: FlutterwavePaymentOptions) => {
  const {
    packageId,
    userId,
    email,
    phoneNumber,
    fullName,
    amount,
    onSuccess,
    onClose,
  } = options;

  // Generate a unique transaction reference
  const tx_ref = `tx-${Date.now()}-${Math.floor(Math.random() * 1000000)}-${packageId}`;

  // Fetch Flutterwave config from our API
  let public_key = '';
  try {
    const response = await fetch('/api/config/flutterwave');
    if (!response.ok) {
      throw new Error(`Failed to get Flutterwave config: ${response.status}`);
    }
    const config = await response.json();
    public_key = config.publicKey;
    
    if (config.testMode) {
      console.info("NOTICE: Test mode active. For mobile money payments, use OTP:", config.testOtpCode);
    }
  } catch (error) {
    console.error("Error fetching Flutterwave config:", error);
    throw new Error("Could not load Flutterwave configuration. Please try again later.");
  }

  // Use the current origin for the redirect URL
  const baseUrl = window.location.origin;
  const redirect_url = `${baseUrl}/payment/callback`;
  console.log("Using redirect URL:", redirect_url);
  
  // Store package info in sessionStorage for the callback page
  sessionStorage.setItem('fw_payment_package_id', packageId.toString());

  const config: FlutterwaveConfig = {
    public_key,
    tx_ref,
    amount,
    currency: "RWF",
    payment_options: "card,mobilemoney,ussd",
    redirect_url,
    customer: {
      email,
      phone_number: phoneNumber,
      name: fullName,
    },
    customizations: {
      title: "MWALIMU Clement",
      description: "Rwanda Traffic Police Theory Exam Simulator",
      logo: "https://cdn-icons-png.flaticon.com/512/5332/5332787.png",
    },
    meta: {
      package_id: packageId,
      user_id: userId,
    },
  };
  
  // Special handling for mobile money payments
  // Add additional info about the test OTP
  console.info("NOTICE: For mobile money payments in test mode, use OTP 123456")

  // Make sure the Flutterwave script is loaded
  const flutterwaveScript = document.querySelector('script[src*="flutterwave"]');
  if (!flutterwaveScript) {
    // Load Flutterwave script if not already loaded
    const script = document.createElement("script");
    script.src = "https://checkout.flutterwave.com/v3.js";
    script.async = true;
    script.onload = () => {
      if (window.FlutterwaveCheckout) {
        window.FlutterwaveCheckout(config);
      }
    };
    document.body.appendChild(script);
  } else {
    // Use existing Flutterwave script
    if (window.FlutterwaveCheckout) {
      window.FlutterwaveCheckout(config);
    }
  }

  // Add event listeners for Flutterwave payment events
  window.addEventListener("flutterwave_callback", function (e: any) {
    if (e.detail.status === "successful") {
      onSuccess(e.detail);
    }
  });

  window.addEventListener("flutterwave_close", onClose);
};
