import { useState } from "react";
import { useAuth } from "@/context/AuthContext";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import LoginModal from "../auth/LoginModal";
import RegistrationModal from "../auth/RegistrationModal";

const Navbar = () => {
  const { isAuthenticated, user, logout } = useAuth();
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [showRegisterModal, setShowRegisterModal] = useState(false);

  return (
    <nav className="bg-white shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link href="/">
              <div className="flex-shrink-0 flex items-center cursor-pointer">
                <div className="flex items-center gap-2">
                  <div className="w-10 h-10 rounded-full flex items-center justify-center bg-[#0078D7] text-white font-bold">
                    MC
                  </div>
                  <div>
                    <h1 className="font-roboto font-bold text-[#0078D7]">MWALIMU Clement</h1>
                    <p className="text-xs text-gray-500">Traffic Theory Exam Simulator</p>
                  </div>
                </div>
              </div>
            </Link>
          </div>
          
          <div className="flex items-center">
            {!isAuthenticated ? (
              <div className="flex space-x-4">
                <Button 
                  variant="outline" 
                  onClick={() => setShowLoginModal(true)}
                  className="border-[#0078D7] text-[#0078D7] hover:bg-[#0078D7] hover:bg-opacity-10 font-medium"
                >
                  Login
                </Button>
                <Button 
                  onClick={() => setShowRegisterModal(true)}
                  className="bg-[#0078D7] text-white hover:bg-opacity-90 font-medium"
                >
                  Register
                </Button>
              </div>
            ) : (
              <div className="flex space-x-4">
                <Link href="/dashboard">
                  <Button variant="outline" className="border-[#0078D7] text-[#0078D7] hover:bg-[#0078D7] hover:bg-opacity-10 font-medium">
                    My Dashboard
                  </Button>
                </Link>
                {user?.role === "admin" && (
                  <Link href="/admin">
                    <Button variant="outline" className="border-[#00843D] text-[#00843D] hover:bg-[#00843D] hover:bg-opacity-10 font-medium">
                      Admin Panel
                    </Button>
                  </Link>
                )}
                <Button 
                  onClick={() => logout()}
                  className="bg-[#0078D7] text-white hover:bg-opacity-90 font-medium"
                >
                  Logout
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Login Modal */}
      {showLoginModal && (
        <LoginModal 
          isOpen={showLoginModal} 
          onClose={() => setShowLoginModal(false)} 
          onRegisterClick={() => {
            setShowLoginModal(false);
            setShowRegisterModal(true);
          }}
        />
      )}

      {/* Registration Modal */}
      {showRegisterModal && (
        <RegistrationModal 
          isOpen={showRegisterModal} 
          onClose={() => setShowRegisterModal(false)} 
        />
      )}
    </nav>
  );
};

export default Navbar;
