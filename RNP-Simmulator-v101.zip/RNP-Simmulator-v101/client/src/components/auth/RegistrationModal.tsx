import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useAuth } from "@/context/AuthContext";
import { useState } from "react";
import SocialLoginButton from "./SocialLoginButton";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { UserPlus, Mail, Phone, LockKeyhole, Check, AlertCircle, User } from "lucide-react";
import PhoneInput from 'react-phone-input-2';
import 'react-phone-input-2/lib/style.css';

interface RegistrationModalProps {
  isOpen: boolean;
  onClose: () => void;
}

// Extend the register schema to include additional fields
const registerSchema = z.object({
  email: z.string()
    .email("Please enter a valid email address")
    .min(1, "Email is required"),
  password: z.string()
    .min(8, "Password must be at least 8 characters long")
    .regex(/[A-Z]/, "Password must contain at least one uppercase letter")
    .regex(/[a-z]/, "Password must contain at least one lowercase letter")
    .regex(/[0-9]/, "Password must contain at least one number")
    .regex(/[!@#$%^&*(),.?":{}|<>]/, "Password must contain at least one special character"),
  confirmPassword: z.string()
    .min(1, "Please confirm your password"),
  fullName: z.string()
    .min(3, "Full name must be at least 3 characters")
    .optional(),
  phoneNumber: z.string()
    .min(10, "Phone number must be at least 10 digits")
    .regex(/^[0-9+\s()-]+$/, "Please enter a valid phone number")
}).refine(data => data.password === data.confirmPassword, {
  message: "Passwords do not match",
  path: ["confirmPassword"]
});

// Phone-based registration schema
const phoneRegisterSchema = z.object({
  phoneNumber: z.string()
    .min(10, "Phone number must be at least 10 digits")
    .regex(/^[0-9+\s()-]+$/, "Please enter a valid phone number"),
  password: z.string()
    .min(8, "Password must be at least 8 characters long")
    .regex(/[A-Z]/, "Password must contain at least one uppercase letter")
    .regex(/[a-z]/, "Password must contain at least one lowercase letter")
    .regex(/[0-9]/, "Password must contain at least one number")
    .regex(/[!@#$%^&*(),.?":{}|<>]/, "Password must contain at least one special character"),
  confirmPassword: z.string()
    .min(1, "Please confirm your password"),
  fullName: z.string()
    .min(3, "Full name must be at least 3 characters")
    .optional()
}).refine(data => data.password === data.confirmPassword, {
  message: "Passwords do not match",
  path: ["confirmPassword"]
});

type RegisterData = z.infer<typeof registerSchema>;
type PhoneRegisterData = z.infer<typeof phoneRegisterSchema>;

const RegistrationModal = ({ isOpen, onClose }: RegistrationModalProps) => {
  const { register: registerUser, isSubmitting, isSocialSubmitting, socialLogin } = useAuth();
  const [registrationType, setRegistrationType] = useState<"email" | "phone">("email");
  const { toast } = useToast();
  
  // Use the global isSubmitting state from AuthContext for regular form submission
  const isLoading = isSubmitting;
  
  // Email-based registration form
  const emailForm = useForm<RegisterData>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      email: "",
      password: "",
      confirmPassword: "",
      fullName: "",
      phoneNumber: "",
    }
  });

  // Phone-based registration form
  const phoneForm = useForm<PhoneRegisterData>({
    resolver: zodResolver(phoneRegisterSchema),
    defaultValues: {
      phoneNumber: "",
      password: "",
      confirmPassword: "",
      fullName: "",
    }
  });
  
  const handleEmailRegistration = async (data: RegisterData) => {
    // If already in a loading state, prevent submission
    if (isLoading) return;
    
    try {
      await registerUser({
        email: data.email,
        password: data.password,
        confirmPassword: data.confirmPassword,
        fullName: data.fullName,
        phoneNumber: data.phoneNumber
      });
      
      onClose();
      toast({
        title: "Registration successful",
        description: "Your account has been created successfully",
      });
      
      // Redirect to dashboard after successful registration
      setTimeout(() => {
        window.location.href = '/dashboard';
      }, 1000);
    } catch (error: any) {
      toast({
        title: "Registration failed",
        description: error.message || "An error occurred during registration",
        variant: "destructive",
      });
    }
  };
  
  const handlePhoneRegistration = async (data: PhoneRegisterData) => {
    // If already in a loading state, prevent submission
    if (isLoading) return;
    
    try {
      // For phone registration, we need to create a temporary email
      const tempEmail = `${data.phoneNumber.replace(/[^0-9]/g, '')}@user.mwalimu.rw`;
      
      await registerUser({
        email: tempEmail, // Using phone as part of email
        password: data.password,
        confirmPassword: data.confirmPassword,
        fullName: data.fullName,
        phoneNumber: data.phoneNumber
      });
      
      onClose();
      toast({
        title: "Registration successful",
        description: "Your account has been created successfully",
      });
      
      // Redirect to dashboard after successful registration
      setTimeout(() => {
        window.location.href = '/dashboard';
      }, 1000);
    } catch (error: any) {
      toast({
        title: "Registration failed",
        description: error.message || "An error occurred during registration",
        variant: "destructive",
      });
    }
  };

  const renderPasswordStrengthChecks = (password: string) => {
    const checks = [
      { test: /.{8,}/, label: "8+ chars" },
      { test: /[A-Z]/, label: "A-Z" },
      { test: /[a-z]/, label: "a-z" },
      { test: /[0-9]/, label: "0-9" },
      { test: /[!@#$%^&*(),.?":{}|<>]/, label: "Symbol" },
    ];

    return (
      <div className="flex flex-wrap gap-2 mt-1 mb-0">
        {checks.map((check, index) => (
          <div key={index} className="flex items-center gap-1 bg-gray-50 rounded px-1 py-0.5">
            {check.test.test(password) ? (
              <Check className="h-2.5 w-2.5 text-green-500" />
            ) : (
              <AlertCircle className="h-2.5 w-2.5 text-gray-300" />
            )}
            <span className={`text-[10px] ${check.test.test(password) ? "text-green-500 font-medium" : "text-gray-500"}`}>
              {check.label}
            </span>
          </div>
        ))}
      </div>
    );
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md p-0 overflow-hidden border-0 shadow-xl max-h-[90vh] overflow-y-auto">
        <div className="bg-gradient-to-b from-[#0078D7] to-[#005EA3] p-4 text-white">
          <div className="flex items-center text-center">
            <div className="h-10 w-10 rounded-full bg-white/20 flex items-center justify-center backdrop-blur-sm mr-3">
              <UserPlus className="h-5 w-5 text-white" />
            </div>
            <div>
              <DialogTitle className="text-xl font-bold text-left">
                Create Your Account
              </DialogTitle>
              <DialogDescription className="text-white/80 text-left text-sm">
                Register to access our simulator
              </DialogDescription>
            </div>
          </div>
        </div>

        <div className="p-4">
          <Tabs defaultValue="email" className="w-full" onValueChange={(value) => setRegistrationType(value as "email" | "phone")}>
            <TabsList className="grid w-full grid-cols-2 mb-3 bg-gray-100 p-1 rounded-lg">
              <TabsTrigger value="email" className="rounded-md data-[state=active]:bg-white data-[state=active]:shadow-sm text-sm py-1">Email</TabsTrigger>
              <TabsTrigger value="phone" className="rounded-md data-[state=active]:bg-white data-[state=active]:shadow-sm text-sm py-1">Phone</TabsTrigger>
            </TabsList>
            
            {/* Email Registration Form */}
            <TabsContent value="email">
              <form onSubmit={emailForm.handleSubmit(handleEmailRegistration)} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-sm font-medium">Email Address*</Label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                      <Mail className="h-5 w-5 text-gray-400" />
                    </div>
                    <Input
                      id="email"
                      type="email"
                      placeholder="Enter your email"
                      className="pl-10"
                      {...emailForm.register('email')}
                    />
                  </div>
                  {emailForm.formState.errors.email && (
                    <div className="flex items-center gap-1 text-xs text-red-500">
                      <AlertCircle className="h-3 w-3" />
                      <p>{emailForm.formState.errors.email.message}</p>
                    </div>
                  )}
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="fullName" className="text-sm font-medium">Full Name</Label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                      <User className="h-5 w-5 text-gray-400" />
                    </div>
                    <Input
                      id="fullName"
                      type="text"
                      placeholder="Enter your full name"
                      className="pl-10"
                      {...emailForm.register('fullName')}
                    />
                  </div>
                  {emailForm.formState.errors.fullName && (
                    <div className="flex items-center gap-1 text-xs text-red-500">
                      <AlertCircle className="h-3 w-3" />
                      <p>{emailForm.formState.errors.fullName.message}</p>
                    </div>
                  )}
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="phoneNumber" className="text-sm font-medium">Phone Number*</Label>
                  <div>
                    <PhoneInput
                      country={'rw'}
                      preferredCountries={['rw', 'ke', 'ug', 'tz', 'bi', 'cd']}
                      enableSearch={true}
                      inputClass="!w-full !py-2 !px-3 !text-base"
                      containerClass="!w-full"
                      inputProps={{
                        id: 'phoneNumber',
                        name: 'phoneNumber',
                      }}
                      onChange={(value) => {
                        emailForm.setValue('phoneNumber', '+' + value, { shouldValidate: true });
                      }}
                    />
                  </div>
                  {emailForm.formState.errors.phoneNumber && (
                    <div className="flex items-center gap-1 text-xs text-red-500">
                      <AlertCircle className="h-3 w-3" />
                      <p>{emailForm.formState.errors.phoneNumber.message}</p>
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password" className="text-sm font-medium">Password*</Label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                      <LockKeyhole className="h-5 w-5 text-gray-400" />
                    </div>
                    <Input
                      id="password"
                      type="password"
                      placeholder="Create a strong password"
                      className="pl-10"
                      {...emailForm.register('password')}
                    />
                  </div>
                  {emailForm.formState.errors.password && (
                    <div className="flex items-center gap-1 text-xs text-red-500">
                      <AlertCircle className="h-3 w-3" />
                      <p>{emailForm.formState.errors.password.message}</p>
                    </div>
                  )}
                  
                  {/* Password strength indicator */}
                  {emailForm.watch('password') && renderPasswordStrengthChecks(emailForm.watch('password'))}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="confirmPassword" className="text-sm font-medium">Confirm Password*</Label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                      <LockKeyhole className="h-5 w-5 text-gray-400" />
                    </div>
                    <Input
                      id="confirmPassword"
                      type="password"
                      placeholder="Confirm your password"
                      className="pl-10"
                      {...emailForm.register('confirmPassword')}
                    />
                  </div>
                  {emailForm.formState.errors.confirmPassword && (
                    <div className="flex items-center gap-1 text-xs text-red-500">
                      <AlertCircle className="h-3 w-3" />
                      <p>{emailForm.formState.errors.confirmPassword.message}</p>
                    </div>
                  )}
                </div>

                <Button 
                  type="submit" 
                  className="w-full bg-gradient-to-r from-[#0078D7] to-[#005EA3] hover:from-[#005EA3] hover:to-[#0078D7] transition-all duration-300 mt-2"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <div className="flex items-center justify-center">
                      <div className="animate-spin h-4 w-4 border-2 border-current border-t-transparent rounded-full mr-2"></div>
                      <span>Creating Account...</span>
                    </div>
                  ) : "Create Account"}
                </Button>
              </form>
            </TabsContent>
            
            {/* Phone Registration Form */}
            <TabsContent value="phone">
              <form onSubmit={phoneForm.handleSubmit(handlePhoneRegistration)} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="phoneNumber" className="text-sm font-medium">Phone Number*</Label>
                  <div>
                    <PhoneInput
                      country={'rw'}
                      preferredCountries={['rw', 'ke', 'ug', 'tz', 'bi', 'cd']}
                      enableSearch={true}
                      inputClass="!w-full !py-2 !px-3 !text-base"
                      containerClass="!w-full"
                      inputProps={{
                        id: 'phoneNumber',
                        name: 'phoneNumber',
                      }}
                      onChange={(value) => {
                        phoneForm.setValue('phoneNumber', '+' + value, { shouldValidate: true });
                      }}
                    />
                  </div>
                  {phoneForm.formState.errors.phoneNumber && (
                    <div className="flex items-center gap-1 text-xs text-red-500">
                      <AlertCircle className="h-3 w-3" />
                      <p>{phoneForm.formState.errors.phoneNumber.message}</p>
                    </div>
                  )}
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="fullName" className="text-sm font-medium">Full Name</Label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                      <User className="h-5 w-5 text-gray-400" />
                    </div>
                    <Input
                      id="fullName"
                      type="text"
                      placeholder="Enter your full name"
                      className="pl-10"
                      {...phoneForm.register('fullName')}
                    />
                  </div>
                  {phoneForm.formState.errors.fullName && (
                    <div className="flex items-center gap-1 text-xs text-red-500">
                      <AlertCircle className="h-3 w-3" />
                      <p>{phoneForm.formState.errors.fullName.message}</p>
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password" className="text-sm font-medium">Password*</Label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                      <LockKeyhole className="h-5 w-5 text-gray-400" />
                    </div>
                    <Input
                      id="password"
                      type="password"
                      placeholder="Create a strong password"
                      className="pl-10"
                      {...phoneForm.register('password')}
                    />
                  </div>
                  {phoneForm.formState.errors.password && (
                    <div className="flex items-center gap-1 text-xs text-red-500">
                      <AlertCircle className="h-3 w-3" />
                      <p>{phoneForm.formState.errors.password.message}</p>
                    </div>
                  )}
                  
                  {/* Password strength indicator */}
                  {phoneForm.watch('password') && renderPasswordStrengthChecks(phoneForm.watch('password'))}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="confirmPassword" className="text-sm font-medium">Confirm Password*</Label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                      <LockKeyhole className="h-5 w-5 text-gray-400" />
                    </div>
                    <Input
                      id="confirmPassword"
                      type="password"
                      placeholder="Confirm your password"
                      className="pl-10"
                      {...phoneForm.register('confirmPassword')}
                    />
                  </div>
                  {phoneForm.formState.errors.confirmPassword && (
                    <div className="flex items-center gap-1 text-xs text-red-500">
                      <AlertCircle className="h-3 w-3" />
                      <p>{phoneForm.formState.errors.confirmPassword.message}</p>
                    </div>
                  )}
                </div>

                <Button 
                  type="submit" 
                  className="w-full bg-gradient-to-r from-[#0078D7] to-[#005EA3] hover:from-[#005EA3] hover:to-[#0078D7] transition-all duration-300 mt-2"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <div className="flex items-center justify-center">
                      <div className="animate-spin h-4 w-4 border-2 border-current border-t-transparent rounded-full mr-2"></div>
                      <span>Creating Account...</span>
                    </div>
                  ) : "Create Account"}
                </Button>
              </form>
            </TabsContent>
          </Tabs>
          
          <div className="flex items-center gap-2 my-3">
            <Separator className="flex-1" />
            <span className="text-xs text-gray-400 font-medium px-2">OR</span>
            <Separator className="flex-1" />
          </div>
          
          <SocialLoginButton 
            onSuccess={() => onClose()}
            label="Sign up with Google"
            variant="outline"
            className="border-gray-300 hover:bg-gray-50"
            // Pass isSocialSubmitting to disable the social login button only when a social login is in progress
            disabled={emailForm.formState.isSubmitting || phoneForm.formState.isSubmitting}
          />
          
          <div className="text-center text-xs text-gray-600 mt-3">
            Already have an account?{" "}
            <button
              type="button"
              className="text-[#0078D7] hover:text-[#005EA3] font-medium transition-colors"
              onClick={onClose}
            >
              Sign In
            </button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default RegistrationModal;