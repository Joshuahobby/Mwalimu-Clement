import { useEffect, useState } from "react";
import { getGoogleRedirectResult } from "@/lib/firebase";
import { useAuth } from "@/context/AuthContext";
import { useToast } from "@/hooks/use-toast";

interface RedirectHandlerProps {
  children: React.ReactNode;
}

/**
 * Component to handle Firebase authentication redirects
 * Place this high in your component tree to catch redirects from social login
 */
const RedirectHandler = ({ children }: RedirectHandlerProps) => {
  const [isProcessing, setIsProcessing] = useState(true);
  const { toast } = useToast();
  const { socialLogin } = useAuth();

  useEffect(() => {
    const handleRedirect = async () => {
      console.log("RedirectHandler: Checking for auth redirects...");
      try {
        console.log("RedirectHandler: Calling getGoogleRedirectResult");
        const { user, token } = await getGoogleRedirectResult();
        console.log("RedirectHandler: Got result from redirect", { hasUser: !!user, hasToken: !!token });
        
        // If we have a user from redirect, handle the social login
        if (user && token) {
          console.log("RedirectHandler: User found from redirect, handling login");
          try {
            // We need to send this data to the backend instead of just calling socialLogin
            // as socialLogin attempts to start a new popup flow
            const response = await fetch("/api/auth/social-login", {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
              },
              body: JSON.stringify({
                fullName: user.displayName || "Google User",
                email: user.email || "",
                phoneNumber: user.phoneNumber || "",
                token,
                providerId: "google.com",
              }),
              credentials: "include",
            });
            
            if (response.ok) {
              const data = await response.json();
              console.log("RedirectHandler: Backend social login successful", data);
              toast({
                title: "Login Successful",
                description: "You've been logged in successfully with Google.",
              });
              if (data.user.role === "admin") {
                window.location.href = "/admin";
              } else {
                window.location.href = "/dashboard";
              }
            } else {
              throw new Error("Failed to authenticate with backend");
            }
          } catch (error) {
            console.error("Error during social login after redirect:", error);
            toast({
              title: "Login Failed",
              description: "There was an error logging in with Google. Please try again.",
              variant: "destructive",
            });
          }
        } else {
          console.log("RedirectHandler: No user from redirect, continuing");
        }
      } catch (error) {
        console.error("Error handling redirect:", error);
      } finally {
        setIsProcessing(false);
      }
    };

    handleRedirect();
  }, [toast]);

  // If still processing, you could show a loading indicator
  // For now, we just render children since the auth context will handle loading states
  return <>{children}</>;
};

export default RedirectHandler;