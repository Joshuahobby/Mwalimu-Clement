import { Link } from "wouter";
import { Card } from "@/components/ui/card";

interface AuthLinkProps {
  text: string;
  linkText: string;
  href: string;
}

interface AuthContainerProps {
  title: string;
  subtitle: string;
  children: React.ReactNode;
  altLink: AuthLinkProps;
}

export default function AuthContainer({
  title,
  subtitle,
  children,
  altLink
}: AuthContainerProps) {
  return (
    <Card className="max-w-md w-full bg-white rounded-xl shadow-lg overflow-hidden">
      <div className="bg-primary-600 text-white py-6 px-8">
        <h1 className="text-2xl font-bold">{title}</h1>
        <p className="text-primary-100 mt-1">{subtitle}</p>
      </div>
      
      <div className="p-8">
        {children}
        
        <div className="mt-6 text-center">
          <p className="text-sm text-gray-600">
            {altLink.text}{" "}
            <Link href={altLink.href} className="text-primary-600 hover:text-primary-800 font-medium">
              {altLink.linkText}
            </Link>
          </p>
        </div>
      </div>
    </Card>
  );
}
