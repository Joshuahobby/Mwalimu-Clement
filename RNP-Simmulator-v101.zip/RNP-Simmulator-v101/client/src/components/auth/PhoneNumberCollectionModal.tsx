import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { AlertCircle } from "lucide-react";
import PhoneInput from 'react-phone-input-2';
import 'react-phone-input-2/lib/style.css';

interface PhoneNumberCollectionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (phoneNumber: string) => Promise<void>;
  socialAuthData: {
    email: string;
    fullName?: string;
    uid: string;
  };
}

// Phone number validation schema
const phoneNumberSchema = z.object({
  phoneNumber: z.string()
    .min(10, "Phone number must be at least 10 digits")
    .regex(/^[0-9+\s()-]+$/, "Please enter a valid phone number"),
});

type PhoneNumberFormData = z.infer<typeof phoneNumberSchema>;

const PhoneNumberCollectionModal = ({ 
  isOpen, 
  onClose, 
  onSubmit,
  socialAuthData 
}: PhoneNumberCollectionModalProps) => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const form = useForm<PhoneNumberFormData>({
    resolver: zodResolver(phoneNumberSchema),
    defaultValues: {
      phoneNumber: "",
    }
  });

  const handleSubmit = async (data: PhoneNumberFormData) => {
    if (isSubmitting) return;
    
    try {
      setIsSubmitting(true);
      await onSubmit(data.phoneNumber);
      onClose();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to complete your registration. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md p-0 overflow-hidden border-0 shadow-xl">
        <div className="bg-gradient-to-b from-[#0078D7] to-[#005EA3] p-4 text-white">
          <DialogTitle className="text-xl font-bold">
            Almost Done!
          </DialogTitle>
          <DialogDescription className="text-white/80">
            Please provide your phone number to complete your registration
          </DialogDescription>
        </div>

        <div className="p-4">
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            <div>
              <Label htmlFor="phoneNumber" className="text-sm font-medium">Phone Number*</Label>
              <div className="mt-1">
                <PhoneInput
                  country={'rw'}
                  preferredCountries={['rw', 'ke', 'ug', 'tz', 'bi', 'cd']}
                  enableSearch={true}
                  inputClass="!w-full !py-2 !px-3 !text-base"
                  containerClass="!w-full"
                  inputProps={{
                    id: 'phoneNumber',
                    name: 'phoneNumber',
                  }}
                  onChange={(value) => {
                    form.setValue('phoneNumber', '+' + value, { shouldValidate: true });
                  }}
                />
              </div>
              {form.formState.errors.phoneNumber && (
                <div className="flex items-center gap-1 text-xs text-red-500 mt-1">
                  <AlertCircle className="h-3 w-3" />
                  <p>{form.formState.errors.phoneNumber.message}</p>
                </div>
              )}
            </div>

            <div className="space-y-2">
              <p className="text-sm text-gray-600">
                Signed in as: <span className="font-medium">{socialAuthData.email}</span>
              </p>
              {socialAuthData.fullName && (
                <p className="text-sm text-gray-600">
                  Name: <span className="font-medium">{socialAuthData.fullName}</span>
                </p>
              )}
            </div>

            <Button 
              type="submit" 
              className="w-full bg-gradient-to-r from-[#0078D7] to-[#005EA3] hover:from-[#005EA3] hover:to-[#0078D7] transition-all duration-300"
              disabled={isSubmitting}
            >
              {isSubmitting ? (
                <div className="flex items-center justify-center">
                  <div className="animate-spin h-4 w-4 border-2 border-current border-t-transparent rounded-full mr-2"></div>
                  <span>Completing Registration...</span>
                </div>
              ) : "Complete Registration"}
            </Button>
          </form>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default PhoneNumberCollectionModal;