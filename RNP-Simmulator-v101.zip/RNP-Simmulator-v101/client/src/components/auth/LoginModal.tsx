import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useAuth } from "@/context/AuthContext";
import SocialLoginButton from "./SocialLoginButton";
import { Separator } from "@/components/ui/separator";
import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { LockKeyhole, Mail, Phone, AlertCircle } from "lucide-react";
import PhoneInput from 'react-phone-input-2';
import 'react-phone-input-2/lib/style.css';

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRegisterClick: () => void;
}

// Email login schema
const emailLoginSchema = z.object({
  email: z.string().email("Valid email is required"),
  password: z.string().min(1, "Password is required"),
});

// Phone login schema
const phoneLoginSchema = z.object({
  phoneNumber: z.string()
    .min(10, "Phone number must be at least 10 digits")
    .regex(/^[0-9+\s()-]+$/, "Please enter a valid phone number"),
  password: z.string().min(1, "Password is required"),
});

type EmailLoginData = z.infer<typeof emailLoginSchema>;
type PhoneLoginData = z.infer<typeof phoneLoginSchema>;

const LoginModal = ({ isOpen, onClose, onRegisterClick }: LoginModalProps) => {
  const { login, user } = useAuth();
  const [loginType, setLoginType] = useState<"email" | "phone">("email");
  const { toast } = useToast();

  // Email login form
  const emailForm = useForm<EmailLoginData>({
    resolver: zodResolver(emailLoginSchema),
    defaultValues: {
      email: "",
      password: "",
    }
  });

  // Phone login form
  const phoneForm = useForm<PhoneLoginData>({
    resolver: zodResolver(phoneLoginSchema),
    defaultValues: {
      phoneNumber: "",
      password: "",
    }
  });

  const handleEmailLogin = async (data: EmailLoginData) => {
    try {
      await login(data.email, data.password);
      onClose();
      
      // Redirect to dashboard or admin page based on user role after successful login
      setTimeout(() => {
        // Need to check auth state again after timeout
        const { pathname } = window.location;
        if (pathname.includes('/admin') || user?.role === 'admin') {
          window.location.href = '/admin';
        } else {
          window.location.href = '/dashboard';
        }
      }, 500);
    } catch (error: any) {
      toast({
        title: "Login failed",
        description: error.message || "Failed to log in. Please try again.",
        variant: "destructive",
      });
      console.error("Login submission error:", error);
    }
  };

  const handlePhoneLogin = async (data: PhoneLoginData) => {
    try {
      // Convert phone number to email format for authentication
      const tempEmail = `${data.phoneNumber.replace(/[^0-9]/g, '')}@user.mwalimu.rw`;
      
      await login(tempEmail, data.password);
      onClose();
      
      // Redirect to dashboard or admin page based on user role after successful login
      setTimeout(() => {
        // Need to check auth state again after timeout
        const { pathname } = window.location;
        if (pathname.includes('/admin') || user?.role === 'admin') {
          window.location.href = '/admin';
        } else {
          window.location.href = '/dashboard';
        }
      }, 500);
    } catch (error: any) {
      toast({
        title: "Login failed",
        description: error.message || "Failed to log in. Please try again.",
        variant: "destructive",
      });
      console.error("Login submission error:", error);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md p-0 overflow-hidden border-0 shadow-xl max-h-[90vh] overflow-y-auto">
        <div className="bg-gradient-to-b from-[#0078D7] to-[#005EA3] p-4 text-white">
          <div className="flex items-center text-center">
            <div className="h-10 w-10 rounded-full bg-white/20 flex items-center justify-center backdrop-blur-sm mr-3">
              <LockKeyhole className="h-5 w-5 text-white" />
            </div>
            <div>
              <DialogTitle className="text-xl font-bold text-left">
                Welcome Back
              </DialogTitle>
              <DialogDescription className="text-white/80 text-left text-sm">
                Sign in to continue
              </DialogDescription>
            </div>
          </div>
        </div>

        <div className="p-4">
          <Tabs defaultValue="email" className="w-full" onValueChange={(value) => setLoginType(value as "email" | "phone")}>
            <TabsList className="grid w-full grid-cols-2 mb-3 bg-gray-100 p-1 rounded-lg">
              <TabsTrigger value="email" className="rounded-md data-[state=active]:bg-white data-[state=active]:shadow-sm text-sm py-1">Email</TabsTrigger>
              <TabsTrigger value="phone" className="rounded-md data-[state=active]:bg-white data-[state=active]:shadow-sm text-sm py-1">Phone</TabsTrigger>
            </TabsList>
            
            {/* Email Login Form */}
            <TabsContent value="email">
              <form onSubmit={emailForm.handleSubmit(handleEmailLogin)} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-sm font-medium">Email Address</Label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                      <Mail className="h-5 w-5 text-gray-400" />
                    </div>
                    <Input
                      id="email"
                      type="email"
                      placeholder="Enter your email"
                      className="pl-10"
                      {...emailForm.register('email')}
                    />
                  </div>
                  {emailForm.formState.errors.email && (
                    <div className="flex items-center gap-1 text-xs text-red-500">
                      <AlertCircle className="h-3 w-3" />
                      <p>{emailForm.formState.errors.email.message}</p>
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <Label htmlFor="password" className="text-sm font-medium">Password</Label>
                    <button
                      type="button"
                      className="text-xs text-[#0078D7] hover:text-[#005EA3] font-medium transition-colors"
                      onClick={(e) => {
                        e.preventDefault();
                        // Password reset functionality would go here
                      }}
                    >
                      Forgot Password?
                    </button>
                  </div>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                      <LockKeyhole className="h-5 w-5 text-gray-400" />
                    </div>
                    <Input
                      id="password"
                      type="password"
                      placeholder="Enter your password"
                      className="pl-10"
                      {...emailForm.register('password')}
                    />
                  </div>
                  {emailForm.formState.errors.password && (
                    <div className="flex items-center gap-1 text-xs text-red-500">
                      <AlertCircle className="h-3 w-3" />
                      <p>{emailForm.formState.errors.password.message}</p>
                    </div>
                  )}
                </div>

                <Button 
                  type="submit" 
                  className="w-full bg-gradient-to-r from-[#0078D7] to-[#005EA3] hover:from-[#005EA3] hover:to-[#0078D7] transition-all duration-300"
                  disabled={emailForm.formState.isSubmitting}
                >
                  {emailForm.formState.isSubmitting ? (
                    <div className="flex items-center justify-center">
                      <div className="animate-spin h-4 w-4 border-2 border-current border-t-transparent rounded-full mr-2"></div>
                      <span>Signing In...</span>
                    </div>
                  ) : "Sign In"}
                </Button>
              </form>
            </TabsContent>
            
            {/* Phone Login Form */}
            <TabsContent value="phone">
              <form onSubmit={phoneForm.handleSubmit(handlePhoneLogin)} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="phoneNumber" className="text-sm font-medium">Phone Number</Label>
                  <div>
                    <PhoneInput
                      country={'rw'}
                      preferredCountries={['rw', 'ke', 'ug', 'tz', 'bi', 'cd']}
                      enableSearch={true}
                      inputClass="!w-full !py-2 !px-3 !text-base"
                      containerClass="!w-full"
                      inputProps={{
                        id: 'phoneNumber',
                        name: 'phoneNumber',
                      }}
                      onChange={(value) => {
                        phoneForm.setValue('phoneNumber', '+' + value, { shouldValidate: true });
                      }}
                    />
                  </div>
                  {phoneForm.formState.errors.phoneNumber && (
                    <div className="flex items-center gap-1 text-xs text-red-500">
                      <AlertCircle className="h-3 w-3" />
                      <p>{phoneForm.formState.errors.phoneNumber.message}</p>
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <Label htmlFor="phonePassword" className="text-sm font-medium">Password</Label>
                    <button
                      type="button"
                      className="text-xs text-[#0078D7] hover:text-[#005EA3] font-medium transition-colors"
                      onClick={(e) => {
                        e.preventDefault();
                        // Password reset functionality would go here
                      }}
                    >
                      Forgot Password?
                    </button>
                  </div>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                      <LockKeyhole className="h-5 w-5 text-gray-400" />
                    </div>
                    <Input
                      id="phonePassword"
                      type="password"
                      placeholder="Enter your password"
                      className="pl-10"
                      {...phoneForm.register('password')}
                    />
                  </div>
                  {phoneForm.formState.errors.password && (
                    <div className="flex items-center gap-1 text-xs text-red-500">
                      <AlertCircle className="h-3 w-3" />
                      <p>{phoneForm.formState.errors.password.message}</p>
                    </div>
                  )}
                </div>

                <Button 
                  type="submit" 
                  className="w-full bg-gradient-to-r from-[#0078D7] to-[#005EA3] hover:from-[#005EA3] hover:to-[#0078D7] transition-all duration-300"
                  disabled={phoneForm.formState.isSubmitting}
                >
                  {phoneForm.formState.isSubmitting ? (
                    <div className="flex items-center justify-center">
                      <div className="animate-spin h-4 w-4 border-2 border-current border-t-transparent rounded-full mr-2"></div>
                      <span>Signing In...</span>
                    </div>
                  ) : "Sign In"}
                </Button>
              </form>
            </TabsContent>
          </Tabs>
            
          <div className="flex items-center gap-2 my-3">
            <Separator className="flex-1" />
            <span className="text-xs text-gray-400 font-medium px-2">OR</span>
            <Separator className="flex-1" />
          </div>
          
          <SocialLoginButton 
            onSuccess={() => onClose()}
            label="Continue with Google"
            variant="outline"
            className="border-gray-300 hover:bg-gray-50"
            disabled={emailForm.formState.isSubmitting || phoneForm.formState.isSubmitting}
          />

          <div className="text-center text-xs text-gray-600 mt-3">
            Don't have an account?{" "}
            <button
              type="button"
              className="text-[#0078D7] hover:text-[#005EA3] font-medium transition-colors"
              onClick={(e) => {
                e.preventDefault();
                onClose();
                onRegisterClick();
              }}
            >
              Create Account
            </button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default LoginModal;
