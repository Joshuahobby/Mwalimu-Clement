import { useEffect, useState } from "react";

interface PasswordRequirementsProps {
  password: string;
  confirmPassword: string;
}

interface Requirement {
  id: string;
  label: string;
  valid: boolean;
}

export default function PasswordRequirements({
  password,
  confirmPassword
}: PasswordRequirementsProps) {
  const [requirements, setRequirements] = useState<Requirement[]>([
    { id: "length", label: "At least 8 characters long", valid: false },
    { id: "uppercase", label: "Contains uppercase letter", valid: false },
    { id: "lowercase", label: "Contains lowercase letter", valid: false },
    { id: "number", label: "Contains a number", valid: false },
    { id: "match", label: "Passwords match", valid: false }
  ]);
  
  useEffect(() => {
    setRequirements([
      { id: "length", label: "At least 8 characters long", valid: password.length >= 8 },
      { id: "uppercase", label: "Contains uppercase letter", valid: /[A-Z]/.test(password) },
      { id: "lowercase", label: "Contains lowercase letter", valid: /[a-z]/.test(password) },
      { id: "number", label: "Contains a number", valid: /[0-9]/.test(password) },
      { id: "match", label: "Passwords match", valid: password === confirmPassword && password !== "" }
    ]);
  }, [password, confirmPassword]);

  return (
    <div className="border border-gray-200 rounded-md p-3 bg-gray-50">
      <h3 className="text-sm font-medium text-gray-700 mb-2">Password Requirements:</h3>
      <ul className="space-y-1 text-xs text-gray-600">
        {requirements.map((req) => (
          <li key={req.id} className={`flex items-center ${req.valid ? "text-green-600" : "text-gray-600"}`}>
            <span className={`inline-block w-4 h-4 mr-2 rounded-full ${req.valid ? "bg-green-500 border-green-500" : "border border-gray-300"}`}></span>
            {req.label}
          </li>
        ))}
      </ul>
    </div>
  );
}
