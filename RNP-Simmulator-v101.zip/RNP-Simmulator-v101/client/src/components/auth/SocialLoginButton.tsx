import { Button } from "@/components/ui/button";
import { useAuth } from "@/context/AuthContext";
import { FcGoogle } from "react-icons/fc";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import { SocialAuthData } from "@/context/AuthContext";
import PhoneNumberCollectionModal from "./PhoneNumberCollectionModal";

interface SocialLoginButtonProps {
  className?: string;
  onSuccess?: () => void;
  onError?: (error: Error) => void;
  variant?: "outline" | "default" | "ghost" | "secondary";
  size?: "default" | "sm" | "lg";
  label?: string;
  disabled?: boolean;
}

const SocialLoginButton = ({ 
  className = "",
  onSuccess,
  onError,
  variant = "outline",
  size = "default",
  label = "Continue with Google",
  disabled = false
}: SocialLoginButtonProps) => {
  const { 
    socialLogin, 
    completeSocialLogin,
    resetPendingSocialAuth,
    isLoading: authLoading, 
    isSocialSubmitting 
  } = useAuth();
  const { toast } = useToast();
  const [showPhoneModal, setShowPhoneModal] = useState(false);
  const [pendingAuthData, setPendingAuthData] = useState<SocialAuthData | null>(null);
  
  // Combined loading state from auth context and passed disabled prop
  const isLoading = isSocialSubmitting || authLoading || disabled;
  
  const handleGoogleLogin = async () => {
    // If already loading or disabled, prevent double submission
    if (isLoading) return;
    
    try {
      // Step 1: Get Google credentials
      const socialAuthData = await socialLogin();
      
      // If we have an empty object, it means authentication was successful
      // and the user already had an account with a phone number
      if (!socialAuthData.email) {
        onSuccess?.();
        return;
      }
      
      // If we get here, we need to collect phone number
      setPendingAuthData(socialAuthData);
      setShowPhoneModal(true);
    } catch (error) {
      console.error("Google login error:", error);
      
      // Show error toast if not handled by parent
      if (!onError && error instanceof Error) {
        toast({
          title: "Google Login Failed",
          description: error.message || "Failed to login with Google. Please try again.",
          variant: "destructive",
        });
      }
      
      // Call onError if provided
      if (onError && error instanceof Error) {
        onError(error);
      }
    }
  };
  
  const handlePhoneNumberSubmit = async (phoneNumber: string) => {
    try {
      // Step 2: Complete social login with phone number
      await completeSocialLogin(phoneNumber);
      setShowPhoneModal(false);
      setPendingAuthData(null);
      onSuccess?.();
    } catch (error) {
      console.error("Phone validation error:", error);
      // Let the modal handle errors
      throw error;
    }
  };
  
  const handleClosePhoneModal = () => {
    setShowPhoneModal(false);
    setPendingAuthData(null);
    resetPendingSocialAuth();
  };
  
  return (
    <>
      <Button
        variant={variant}
        size={size}
        type="button"
        className={`flex items-center gap-2 w-full justify-center shadow-sm hover:shadow-md transition-all duration-300 ${className}`}
        onClick={handleGoogleLogin}
        disabled={isLoading}
      >
        {isLoading ? (
          <div className="animate-spin h-5 w-5 border-2 border-current border-t-transparent rounded-full"></div>
        ) : (
          <div className="relative flex items-center justify-center h-6 w-6 bg-white rounded-full overflow-hidden shadow-inner">
            <FcGoogle className="h-5 w-5" />
          </div>
        )}
        <span className="font-medium">{isLoading ? "Connecting to Google..." : label}</span>
      </Button>
      
      {/* Phone number collection modal for social login */}
      {showPhoneModal && pendingAuthData && (
        <PhoneNumberCollectionModal 
          isOpen={showPhoneModal}
          onClose={handleClosePhoneModal}
          onSubmit={handlePhoneNumberSubmit}
          socialAuthData={pendingAuthData}
        />
      )}
    </>
  );
};

export default SocialLoginButton;