import { useEffect, useState } from "react";
import { checkFirebaseConfig } from "@/lib/firebase";

export default function FirebaseStatus() {
  const [isConfigured, setIsConfigured] = useState<boolean | null>(null);
  
  useEffect(() => {
    const checkConfig = async () => {
      try {
        const configStatus = checkFirebaseConfig();
        setIsConfigured(configStatus);
      } catch (error) {
        console.error("Error checking Firebase config:", error);
        setIsConfigured(false);
      }
    };
    
    checkConfig();
  }, []);
  
  if (isConfigured === null) {
    return (
      <div className="fixed bottom-4 right-4 bg-yellow-50 border border-yellow-200 p-3 rounded-md shadow text-xs max-w-xs">
        <h4 className="font-bold text-yellow-800">Firebase Configuration Status</h4>
        <p className="text-yellow-700 mt-1">Checking configuration...</p>
      </div>
    );
  }
  
  return (
    <div className={`fixed bottom-4 right-4 p-3 rounded-md shadow text-xs max-w-xs
      ${isConfigured 
        ? "bg-green-50 border-green-200" 
        : "bg-red-50 border-red-200"}`}
    >
      <h4 className={`font-bold ${isConfigured ? "text-green-800" : "text-red-800"}`}>
        Firebase Configuration Status
      </h4>
      <p className={`mt-1 ${isConfigured ? "text-green-700" : "text-red-700"}`}>
        {isConfigured 
          ? "Firebase properly configured ✅" 
          : "Firebase configuration error: apiKey missing or invalid"}
      </p>
    </div>
  );
}
