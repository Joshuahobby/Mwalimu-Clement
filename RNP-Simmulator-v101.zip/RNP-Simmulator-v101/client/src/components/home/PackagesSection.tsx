import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { initFlutterwavePayment } from '@/lib/flutterwave';
import { apiRequest } from '@/lib/queryClient';
import { queryClient } from '@/lib/queryClient';
import RegistrationModal from '../auth/RegistrationModal';
import LoginModal from '../auth/LoginModal';
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { InfoIcon, Loader2 } from "lucide-react";

interface Package {
  id: number;
  name: string;
  type: string;
  price: number;
  duration: number;
  description: string;
}

const PackagesSection = () => {
  const [packages, setPackages] = useState<Package[]>([]);
  const [loading, setLoading] = useState(true);
  const [processingPayment, setProcessingPayment] = useState<number | null>(null);
  const { isAuthenticated, user } = useAuth();
  const { toast } = useToast();
  const [showRegisterModal, setShowRegisterModal] = useState(false);
  const [showLoginModal, setShowLoginModal] = useState(false);

  useEffect(() => {
    const fetchPackages = async () => {
      try {
        setLoading(true);
        const response = await fetch('/api/packages');
        const data = await response.json();
        setPackages(data.packages);
      } catch (error) {
        console.error('Error fetching packages:', error);
        toast({
          title: 'Error',
          description: 'Failed to load packages. Please refresh the page.',
          variant: 'destructive',
        });
      } finally {
        setLoading(false);
      }
    };

    fetchPackages();
  }, [toast]);

  const handlePackageSelect = async (packageData: Package) => {
    if (!isAuthenticated) {
      setShowRegisterModal(true);
      return;
    }

    if (!user) {
      setShowLoginModal(true);
      return;
    }
    
    // Set processing payment state to show loading indicator on the button
    setProcessingPayment(packageData.id);
    
    try {
      await initFlutterwavePayment({
        packageId: packageData.id,
        userId: user.id,
        email: user.email,
        phoneNumber: user.phoneNumber || "",
        fullName: user.fullName || "",
        amount: packageData.price,
        onSuccess: async (data) => {
          try {
            // Verify payment on backend
            await apiRequest('POST', '/api/payments/verify', {
              ...data,
              package_id: packageData.id,
            });

            toast({
              title: 'Payment Successful',
              description: `Your ${packageData.name} has been activated successfully.`,
            });

            // Invalidate queries to refresh user data
            queryClient.invalidateQueries({ queryKey: ['/api/auth/me'] });
          } catch (error) {
            console.error('Payment verification error:', error);
            toast({
              title: 'Payment Verification Failed',
              description: error instanceof Error ? error.message : 'Please contact support if your payment was processed.',
              variant: 'destructive',
            });
          } finally {
            // Clear processing state
            setProcessingPayment(null);
          }
        },
        onClose: () => {
          // Clear processing state
          setProcessingPayment(null);
          toast({
            title: 'Payment Cancelled',
            description: 'You cancelled the payment process.',
          });
        }
      });
    } catch (error) {
      // Clear processing state
      setProcessingPayment(null);
      console.error('Error initializing payment:', error);
      toast({
        title: 'Payment Error',
        description: error instanceof Error ? error.message : 'Could not initialize payment process. Please try again.',
        variant: 'destructive',
      });
    }
  };

  const formatDuration = (hours: number) => {
    if (hours === 1) return 'One-time';
    if (hours === 24) return '24-hour access';
    if (hours === 168) return '7-day access';
    if (hours === 720) return '30-day access';
    return `${hours} hours`;
  };

  return (
    <div className="py-12 bg-white" id="packages">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-roboto font-bold text-[#333333]">
            Choose Your Package
          </h2>
          <p className="mt-4 text-gray-600 max-w-2xl mx-auto">
            Select the package that best fits your needs and start practicing for your Rwanda Traffic Police Theory Exam.
          </p>
        </div>

        {/* Payment info alert */}
        <div className="mb-8 max-w-3xl mx-auto">
          <Alert className="bg-blue-50 border-blue-200">
            <InfoIcon className="h-4 w-4 text-blue-600" />
            <AlertTitle className="text-blue-800 font-medium">Important Payment Information</AlertTitle>
            <AlertDescription className="text-blue-700">
              For mobile money test payments, use OTP code <span className="font-bold">123456</span> when prompted during checkout.
            </AlertDescription>
          </Alert>
        </div>
        
        {loading ? (
          <div className="text-center py-8">Loading packages...</div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {packages.map((pkg) => (
              <div 
                key={pkg.id}
                className={`
                  bg-white rounded-lg shadow-md flex flex-col
                  ${pkg.type === 'weekly' 
                    ? 'border-2 border-[#FAD201] transform scale-105 shadow-lg relative z-10' 
                    : 'border-2 border-transparent hover:border-[#0078D7] transition-all duration-200'
                  }
                `}
              >
                {pkg.type === 'weekly' && (
                  <div className="absolute -top-4 right-0 left-0 flex justify-center">
                    <span className="bg-[#FAD201] text-[#333333] px-4 py-1 rounded-full font-bold text-sm">
                      Popular Choice
                    </span>
                  </div>
                )}
                <div className={`
                  rounded-t-lg p-4 text-center
                  ${pkg.type === 'weekly' ? 'bg-[#0078D7] text-white' : 'bg-[#F5F5F5]'}
                `}>
                  <h3 className="font-roboto font-bold text-xl">{pkg.name}</h3>
                </div>
                <div className="flex-grow p-6 flex flex-col">
                  <div className="text-center mb-4">
                    <span className="text-3xl font-bold">{pkg.price.toLocaleString()} RWF</span>
                    <span className="text-gray-500 block">{formatDuration(pkg.duration)}</span>
                  </div>
                  <ul className="space-y-3 mb-6 flex-grow">
                    {pkg.type === 'single' && (
                      <>
                        <li className="flex items-start">
                          <svg className="w-5 h-5 text-[#00843D] mr-2 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                          </svg>
                          <span>1 full practice exam</span>
                        </li>
                        <li className="flex items-start">
                          <svg className="w-5 h-5 text-[#00843D] mr-2 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                          </svg>
                          <span>20 randomized questions</span>
                        </li>
                        <li className="flex items-start">
                          <svg className="w-5 h-5 text-[#00843D] mr-2 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                          </svg>
                          <span>Detailed results review</span>
                        </li>
                      </>
                    )}
                    {pkg.type === 'daily' && (
                      <>
                        <li className="flex items-start">
                          <svg className="w-5 h-5 text-[#00843D] mr-2 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                          </svg>
                          <span>Unlimited practice exams for 24 hours</span>
                        </li>
                        <li className="flex items-start">
                          <svg className="w-5 h-5 text-[#00843D] mr-2 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                          </svg>
                          <span>Access to all question types</span>
                        </li>
                        <li className="flex items-start">
                          <svg className="w-5 h-5 text-[#00843D] mr-2 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                          </svg>
                          <span>Performance tracking</span>
                        </li>
                      </>
                    )}
                    {pkg.type === 'weekly' && (
                      <>
                        <li className="flex items-start">
                          <svg className="w-5 h-5 text-[#00843D] mr-2 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                          </svg>
                          <span>Unlimited practice exams for 7 days</span>
                        </li>
                        <li className="flex items-start">
                          <svg className="w-5 h-5 text-[#00843D] mr-2 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                          </svg>
                          <span>Comprehensive progress tracking</span>
                        </li>
                        <li className="flex items-start">
                          <svg className="w-5 h-5 text-[#00843D] mr-2 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                          </svg>
                          <span>Detailed performance analytics</span>
                        </li>
                        <li className="flex items-start">
                          <svg className="w-5 h-5 text-[#00843D] mr-2 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                          </svg>
                          <span>Focus on weak areas</span>
                        </li>
                      </>
                    )}
                    {pkg.type === 'monthly' && (
                      <>
                        <li className="flex items-start">
                          <svg className="w-5 h-5 text-[#00843D] mr-2 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                          </svg>
                          <span>Unlimited practice exams for 30 days</span>
                        </li>
                        <li className="flex items-start">
                          <svg className="w-5 h-5 text-[#00843D] mr-2 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                          </svg>
                          <span>Complete question bank access</span>
                        </li>
                        <li className="flex items-start">
                          <svg className="w-5 h-5 text-[#00843D] mr-2 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                          </svg>
                          <span>Advanced performance analytics</span>
                        </li>
                        <li className="flex items-start">
                          <svg className="w-5 h-5 text-[#00843D] mr-2 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                          </svg>
                          <span>Best value for serious preparation</span>
                        </li>
                      </>
                    )}
                  </ul>
                  <Button 
                    onClick={() => handlePackageSelect(pkg)}
                    disabled={processingPayment !== null}
                    className={`
                      w-full mt-auto py-2 px-6 rounded-lg font-medium
                      ${pkg.type === 'weekly' 
                        ? 'bg-[#FAD201] text-[#333333] hover:bg-opacity-90' 
                        : 'bg-[#0078D7] text-white hover:bg-opacity-90'
                      }
                      ${processingPayment !== null && 'opacity-70 cursor-not-allowed'}
                    `}
                  >
                    {processingPayment === pkg.id ? (
                      <div className="flex items-center justify-center">
                        <Loader2 className="animate-spin mr-2 h-4 w-4" />
                        Processing...
                      </div>
                    ) : 'Select Package'}
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Registration Modal */}
      {showRegisterModal && (
        <RegistrationModal 
          isOpen={showRegisterModal} 
          onClose={() => setShowRegisterModal(false)} 
        />
      )}

      {/* Login Modal */}
      {showLoginModal && (
        <LoginModal 
          isOpen={showLoginModal} 
          onClose={() => setShowLoginModal(false)}
          onRegisterClick={() => {
            setShowLoginModal(false);
            setShowRegisterModal(true);
          }}
        />
      )}
    </div>
  );
};

export default PackagesSection;
