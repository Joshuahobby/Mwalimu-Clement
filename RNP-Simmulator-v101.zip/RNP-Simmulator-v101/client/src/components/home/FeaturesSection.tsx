const FeaturesSection = () => {
  const features = [
    {
      icon: (
        <svg className="w-8 h-8 text-[#0078D7]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"></path>
        </svg>
      ),
      title: "Authentic Questions",
      description: "Practice with real questions from the Rwanda Traffic Police Theory Exam database.",
      bgColor: "bg-[#0078D7] bg-opacity-10",
      iconColor: "text-[#0078D7]"
    },
    {
      icon: (
        <svg className="w-8 h-8 text-[#00843D]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
        </svg>
      ),
      title: "Realistic Exam Environment",
      description: "Experience the same 20-minute time limit and 20-question format as the actual exam.",
      bgColor: "bg-[#00843D] bg-opacity-10",
      iconColor: "text-[#00843D]"
    },
    {
      icon: (
        <svg className="w-8 h-8 text-[#FAD201]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path>
        </svg>
      ),
      title: "Performance Tracking",
      description: "Monitor your progress and identify areas for improvement with detailed analytics.",
      bgColor: "bg-[#FAD201] bg-opacity-20",
      iconColor: "text-[#FAD201]"
    },
    {
      icon: (
        <svg className="w-8 h-8 text-[#0078D7]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path>
        </svg>
      ),
      title: "Text & Image Questions",
      description: "Practice with both text-based and image-based questions just like the real exam.",
      bgColor: "bg-[#0078D7] bg-opacity-10",
      iconColor: "text-[#0078D7]"
    },
    {
      icon: (
        <svg className="w-8 h-8 text-[#00843D]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"></path>
        </svg>
      ),
      title: "Secure Payments",
      description: "Safe and easy payment options through Flutterwave, Rwanda's trusted payment platform.",
      bgColor: "bg-[#00843D] bg-opacity-10",
      iconColor: "text-[#00843D]"
    },
    {
      icon: (
        <svg className="w-8 h-8 text-[#FAD201]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 8h2a2 2 0 012 2v6a2 2 0 01-2 2h-2v4l-4-4H9a1.994 1.994 0 01-1.414-.586m0 0L11 14h4a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2v4l.586-.586z"></path>
        </svg>
      ),
      title: "Detailed Explanations",
      description: "Learn from your mistakes with comprehensive explanations for every question.",
      bgColor: "bg-[#FAD201] bg-opacity-20",
      iconColor: "text-[#FAD201]"
    }
  ];

  return (
    <div className="py-12 bg-[#F5F5F5]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-roboto font-bold text-[#333333]">
            Why Choose MWALIMU Clement?
          </h2>
          <p className="mt-4 text-gray-600 max-w-2xl mx-auto">
            Our exam simulator is designed to help you pass your Rwanda Traffic Police Theory Exam on the first attempt.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="bg-white rounded-lg shadow-md p-6 flex flex-col items-center text-center">
              <div className={`w-16 h-16 ${feature.bgColor} rounded-full flex items-center justify-center mb-4`}>
                {feature.icon}
              </div>
              <h3 className="text-xl font-roboto font-bold mb-2">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default FeaturesSection;
