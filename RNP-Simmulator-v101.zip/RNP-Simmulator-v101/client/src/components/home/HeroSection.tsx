import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/context/AuthContext';
import { useLocation } from 'wouter';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import RegistrationModal from '../auth/RegistrationModal';

const HeroSection = () => {
  const { isAuthenticated, subscription } = useAuth();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [showRegisterModal, setShowRegisterModal] = useState(false);

  const handleStartExam = async () => {
    if (!isAuthenticated) {
      setShowRegisterModal(true);
      return;
    }

    if (!subscription) {
      toast({
        title: 'No Active Subscription',
        description: 'Please purchase a package to start an exam.',
        variant: 'destructive',
      });
      navigate('/dashboard');
      return;
    }

    // Instead of starting an exam directly, navigate to the exam configuration page
    navigate('/exams/config');
  };

  return (
    <div className="bg-[#0078D7] text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row">
          <div className="md:w-1/2 flex flex-col justify-center">
            <h1 className="text-3xl md:text-4xl font-roboto font-bold mb-4">
              Prepare for your Rwanda Traffic Police Theory Exam
            </h1>
            <p className="text-lg mb-6">
              Practice with real exam questions and improve your chances of passing on your first attempt.
            </p>
            <div className="flex space-x-4">
              <Button 
                onClick={handleStartExam}
                className="bg-[#FAD201] text-[#333333] hover:bg-opacity-90 font-medium text-base"
              >
                Start Practice Exam
              </Button>
              <Button 
                variant="outline" 
                className="bg-white bg-opacity-20 text-white hover:bg-opacity-30 border-none font-medium text-base"
                onClick={() => {
                  const packagesSection = document.getElementById('packages');
                  if (packagesSection) {
                    packagesSection.scrollIntoView({ behavior: 'smooth' });
                  }
                }}
              >
                Learn More
              </Button>
            </div>
          </div>
          <div className="md:w-1/2 mt-8 md:mt-0 flex items-center justify-center">
            <img 
              src="https://images.unsplash.com/photo-1580820267485-db43c505c944?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80" 
              alt="Traffic police officer" 
              className="rounded-lg shadow-lg max-w-full h-auto" 
              width="500" 
              height="350"
            />
          </div>
        </div>
      </div>

      {/* Registration Modal */}
      {showRegisterModal && (
        <RegistrationModal 
          isOpen={showRegisterModal} 
          onClose={() => setShowRegisterModal(false)} 
        />
      )}
    </div>
  );
};

export default HeroSection;
