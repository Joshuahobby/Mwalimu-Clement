const StatisticsSection = () => {
  const stats = [
    { value: "5,000+", label: "Registered Users" },
    { value: "50,000+", label: "Exams Completed" },
    { value: "85%", label: "Pass Rate" },
    { value: "1,000+", label: "Questions in Database" }
  ];

  return (
    <div className="py-12 bg-[#0078D7] text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-10">
          <h2 className="text-3xl font-roboto font-bold">Our Impact</h2>
          <p className="mt-4 max-w-2xl mx-auto">
            Helping Rwandan drivers prepare for their traffic theory exams.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <div key={index} className="text-center">
              <div className="text-4xl font-bold mb-2">{stat.value}</div>
              <p className="text-lg">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default StatisticsSection;
