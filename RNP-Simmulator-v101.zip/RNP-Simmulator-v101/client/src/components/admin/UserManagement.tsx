import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Edit, Trash2, Eye, Search, Download, Filter, Plus, UserPlus, UserCheck, AtSign, Phone, X, Calendar, CheckCircle2, XCircle, MoreHorizontal, RefreshCw, Shield, ShieldAlert } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogClose,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { Checkbox } from "@/components/ui/checkbox";
import { Separator } from "@/components/ui/separator";

// User schema
const userSchema = z.object({
  email: z.string().email({ message: "Please enter a valid email address" }),
  fullName: z.string().min(1, { message: "Name is required" }),
  phoneNumber: z.string().optional(),
  role: z.enum(["user", "admin"]),
  password: z.string().min(6, { message: "Password must be at least 6 characters" }).optional(),
});

interface User {
  id: number;
  email: string;
  fullName?: string;
  phoneNumber?: string;
  createdAt: string;
  role?: string;
  status?: string;
  lastLogin?: string;
  subscription?: {
    type: string;
    expiresAt: string;
    isActive: boolean;
  };
  exams?: {
    total: number;
    passed: number;
    failed: number;
  };
}

interface SubscriptionData {
  id: number;
  userId: number;
  packageId: number;
  packageName: string;
  startDate: string;
  endDate: string;
  isActive: boolean;
}

interface ExamData {
  id: number;
  date: string;
  score: number;
  isPassed: boolean;
}

const UserManagement = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [filteredUsers, setFilteredUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [userFilter, setUserFilter] = useState("all");
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [userSubscriptions, setUserSubscriptions] = useState<SubscriptionData[]>([]);
  const [userExams, setUserExams] = useState<ExamData[]>([]);
  const [activeUserTab, setActiveUserTab] = useState("details");
  const [isProcessing, setIsProcessing] = useState(false);
  const { toast } = useToast();

  const addUserForm = useForm<z.infer<typeof userSchema>>({
    resolver: zodResolver(userSchema),
    defaultValues: {
      email: "",
      fullName: "",
      phoneNumber: "",
      role: "user",
      password: "",
    },
  });

  const editUserForm = useForm<z.infer<typeof userSchema>>({
    resolver: zodResolver(userSchema),
    defaultValues: {
      email: "",
      fullName: "",
      phoneNumber: "",
      role: "user",
    },
  });

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        setLoading(true);
        const response = await fetch('/api/admin/users', {
          credentials: 'include',
        });
        
        if (!response.ok) {
          throw new Error('Failed to fetch users');
        }
        
        const data = await response.json();
        setUsers(data.users);
        setFilteredUsers(data.users);
      } catch (error) {
        console.error('Error fetching users:', error);
        toast({
          title: 'Error',
          description: 'Failed to load users.',
          variant: 'destructive',
        });
      } finally {
        setLoading(false);
      }
    };

    fetchUsers();
  }, [toast]);

  // Apply search and filters whenever users, searchQuery, or userFilter changes
  useEffect(() => {
    let filtered = [...users];
    
    // Apply search query
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(user => 
        user.email.toLowerCase().includes(query) || 
        (user.fullName && user.fullName.toLowerCase().includes(query)) ||
        (user.phoneNumber && user.phoneNumber.includes(query))
      );
    }
    
    // Apply role filter
    if (userFilter === "admin") {
      filtered = filtered.filter(user => user.role === "admin");
    } else if (userFilter === "user") {
      filtered = filtered.filter(user => user.role !== "admin");
    } else if (userFilter === "active") {
      filtered = filtered.filter(user => user.subscription?.isActive);
    } else if (userFilter === "inactive") {
      filtered = filtered.filter(user => !user.subscription?.isActive);
    }
    
    setFilteredUsers(filtered);
  }, [users, searchQuery, userFilter]);

  // Format date to a readable format
  const formatDate = (dateString: string) => {
    if (!dateString) return "N/A";
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  // Fetch user details (subscriptions, exams) for the detail view
  const fetchUserDetails = async (userId: number) => {
    try {
      // In a real implementation, these would be separate API calls
      // For now, we'll mock the data
      setUserSubscriptions([
        {
          id: 1,
          userId: userId,
          packageId: 2,
          packageName: "Monthly Standard",
          startDate: new Date().toISOString(),
          endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
          isActive: true
        }
      ]);
      
      setUserExams([
        {
          id: 1,
          date: new Date().toISOString(),
          score: 85,
          isPassed: true
        },
        {
          id: 2,
          date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
          score: 70,
          isPassed: true
        },
        {
          id: 3,
          date: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
          score: 60,
          isPassed: false
        }
      ]);
    } catch (error) {
      console.error("Error fetching user details:", error);
      toast({
        title: "Error",
        description: "Could not load user details. Please try again.",
        variant: "destructive"
      });
    }
  };

  const handleViewUser = (user: User) => {
    setSelectedUser(user);
    fetchUserDetails(user.id);
    setIsViewDialogOpen(true);
    setActiveUserTab("details");
  };
  
  const handleEditUser = (user: User) => {
    setSelectedUser(user);
    editUserForm.reset({
      email: user.email,
      fullName: user.fullName || "",
      phoneNumber: user.phoneNumber || "",
      role: (user.role as "user" | "admin") || "user",
    });
    setIsEditDialogOpen(true);
  };
  
  const handleDeleteClick = (user: User) => {
    setSelectedUser(user);
    setIsDeleteDialogOpen(true);
  };
  
  const handleDeleteUser = async () => {
    if (!selectedUser) return;
    
    try {
      setIsProcessing(true);
      // In a real implementation, this would be an API call
      // const response = await fetch(`/api/admin/users/${selectedUser.id}`, {
      //   method: 'DELETE',
      //   credentials: 'include',
      // });
      
      // if (!response.ok) {
      //   throw new Error('Failed to delete user');
      // }
      
      // Remove the user from the local state
      setUsers(users.filter(user => user.id !== selectedUser.id));
      
      toast({
        title: "Success",
        description: `User ${selectedUser.email} has been deleted.`,
        variant: "default",
      });
      
      setIsDeleteDialogOpen(false);
    } catch (error) {
      console.error('Error deleting user:', error);
      toast({
        title: 'Error',
        description: 'Failed to delete user. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const onAddUserSubmit = async (data: z.infer<typeof userSchema>) => {
    try {
      setIsProcessing(true);
      // In a real implementation, this would be an API call
      // const response = await fetch('/api/admin/users', {
      //   method: 'POST',
      //   headers: {
      //     'Content-Type': 'application/json',
      //   },
      //   credentials: 'include',
      //   body: JSON.stringify(data),
      // });
      
      // if (!response.ok) {
      //   throw new Error('Failed to create user');
      // }
      
      // const newUser = await response.json();
      
      // Add the new user to the local state
      const newUser: User = {
        id: users.length + 1,
        email: data.email,
        fullName: data.fullName,
        phoneNumber: data.phoneNumber,
        role: data.role,
        createdAt: new Date().toISOString(),
      };
      
      setUsers([...users, newUser]);
      
      toast({
        title: "Success",
        description: `User ${data.email} has been created.`,
        variant: "default",
      });
      
      addUserForm.reset();
      setIsAddDialogOpen(false);
    } catch (error) {
      console.error('Error creating user:', error);
      toast({
        title: 'Error',
        description: 'Failed to create user. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const onEditUserSubmit = async (data: z.infer<typeof userSchema>) => {
    if (!selectedUser) return;
    
    try {
      setIsProcessing(true);
      // In a real implementation, this would be an API call
      // const response = await fetch(`/api/admin/users/${selectedUser.id}`, {
      //   method: 'PATCH',
      //   headers: {
      //     'Content-Type': 'application/json',
      //   },
      //   credentials: 'include',
      //   body: JSON.stringify(data),
      // });
      
      // if (!response.ok) {
      //   throw new Error('Failed to update user');
      // }
      
      // Update the user in the local state
      const updatedUsers = users.map(user => {
        if (user.id === selectedUser.id) {
          return {
            ...user,
            email: data.email,
            fullName: data.fullName,
            phoneNumber: data.phoneNumber,
            role: data.role,
          };
        }
        return user;
      });
      
      setUsers(updatedUsers);
      
      toast({
        title: "Success",
        description: `User ${data.email} has been updated.`,
        variant: "default",
      });
      
      setIsEditDialogOpen(false);
    } catch (error) {
      console.error('Error updating user:', error);
      toast({
        title: 'Error',
        description: 'Failed to update user. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const handleExportUsers = () => {
    // In a real implementation, this would generate a CSV file for download
    toast({
      title: "Export Started",
      description: "User data is being exported. Please wait...",
    });
    
    setTimeout(() => {
      toast({
        title: "Export Complete",
        description: "User data has been exported successfully.",
      });
    }, 1500);
  };

  return (
    <div className="space-y-6">
      {/* User Management Controls */}
      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
            <div>
              <CardTitle className="text-xl font-bold">User Management</CardTitle>
              <CardDescription>Manage user accounts and permissions</CardDescription>
            </div>
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 h-4 w-4" />
                <Input 
                  type="text" 
                  placeholder="Search users..." 
                  className="pl-10 w-full md:w-[200px]"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <div className="flex items-center gap-2">
                <Select value={userFilter} onValueChange={setUserFilter}>
                  <SelectTrigger className="w-full md:w-[150px]">
                    <div className="flex items-center gap-2">
                      <Filter className="h-4 w-4 text-gray-500" />
                      <SelectValue placeholder="Filter" />
                    </div>
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Users</SelectItem>
                    <SelectItem value="admin">Admins</SelectItem>
                    <SelectItem value="user">Regular Users</SelectItem>
                    <SelectItem value="active">Active Subscriptions</SelectItem>
                    <SelectItem value="inactive">Inactive Subscriptions</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col-reverse sm:flex-row justify-between items-center mb-4 gap-4">
            <div className="flex items-center text-sm text-gray-500">
              <span className="font-medium mr-1">{filteredUsers.length}</span> 
              {filteredUsers.length === 1 ? "user" : "users"} found
            </div>
            <div className="flex items-center gap-2">
              <Button onClick={handleExportUsers} size="sm" variant="outline" className="gap-2">
                <Download className="h-4 w-4" />
                Export
              </Button>
              <Button onClick={() => setIsAddDialogOpen(true)} size="sm" className="gap-2 bg-[#0078D7]">
                <UserPlus className="h-4 w-4" />
                Add User
              </Button>
            </div>
          </div>

          {loading ? (
            <div className="space-y-4">
              {Array.from({ length: 5 }).map((_, i) => (
                <Skeleton key={i} className="h-12 w-full" />
              ))}
            </div>
          ) : (
            <div className="overflow-x-auto rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ID</TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Phone</TableHead>
                    <TableHead>Joined</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredUsers.length > 0 ? (
                    filteredUsers.map((user) => (
                      <TableRow key={user.id}>
                        <TableCell className="font-medium">{user.id}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <div className="w-7 h-7 rounded-full bg-gray-100 flex items-center justify-center text-xs font-medium text-gray-600">
                              {user.fullName ? user.fullName.charAt(0).toUpperCase() : user.email.charAt(0).toUpperCase()}
                            </div>
                            <span>{user.fullName || 'N/A'}</span>
                          </div>
                        </TableCell>
                        <TableCell>{user.email}</TableCell>
                        <TableCell>{user.phoneNumber || 'N/A'}</TableCell>
                        <TableCell>{formatDate(user.createdAt)}</TableCell>
                        <TableCell>
                          {user.role === 'admin' ? (
                            <Badge className="bg-[#0078D7]">Admin</Badge>
                          ) : (
                            <Badge variant="outline">User</Badge>
                          )}
                        </TableCell>
                        <TableCell>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel>Actions</DropdownMenuLabel>
                              <DropdownMenuItem onClick={() => handleViewUser(user)}>
                                <Eye className="h-4 w-4 mr-2" />
                                View Details
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => handleEditUser(user)}>
                                <Edit className="h-4 w-4 mr-2" />
                                Edit User
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem 
                                onClick={() => handleDeleteClick(user)}
                                className="text-red-600"
                              >
                                <Trash2 className="h-4 w-4 mr-2" />
                                Delete User
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={7} className="h-24 text-center">
                        No users found.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
        <CardFooter className="flex justify-between">
          <div className="text-xs text-gray-500">
            Last updated: {new Date().toLocaleString()}
          </div>
          <Button variant="ghost" size="sm" onClick={() => window.location.reload()}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
        </CardFooter>
      </Card>

      {/* View User Details Dialog */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>User Details</DialogTitle>
            <DialogDescription>View complete user information</DialogDescription>
          </DialogHeader>
          
          {selectedUser && (
            <div className="mt-4">
              <div className="flex flex-col sm:flex-row gap-6 mb-4">
                <div className="w-20 h-20 rounded-full bg-gray-100 flex items-center justify-center text-2xl font-medium text-gray-600">
                  {selectedUser.fullName ? selectedUser.fullName.charAt(0).toUpperCase() : selectedUser.email.charAt(0).toUpperCase()}
                </div>
                <div className="space-y-2">
                  <h3 className="text-xl font-bold">{selectedUser.fullName || 'No Name'}</h3>
                  <div className="flex items-center text-gray-500">
                    <AtSign className="h-4 w-4 mr-1" />
                    {selectedUser.email}
                  </div>
                  {selectedUser.phoneNumber && (
                    <div className="flex items-center text-gray-500">
                      <Phone className="h-4 w-4 mr-1" />
                      {selectedUser.phoneNumber}
                    </div>
                  )}
                  <div className="flex items-center text-gray-500">
                    <Calendar className="h-4 w-4 mr-1" />
                    Joined on {formatDate(selectedUser.createdAt)}
                  </div>
                  <div className="flex items-center gap-2">
                    {selectedUser.role === 'admin' ? (
                      <div className="flex items-center">
                        <Badge className="bg-[#0078D7] mr-2">Admin</Badge>
                        <ShieldAlert className="h-4 w-4 text-[#0078D7]" />
                      </div>
                    ) : (
                      <div className="flex items-center">
                        <Badge variant="outline" className="mr-2">User</Badge>
                        <Shield className="h-4 w-4 text-gray-500" />
                      </div>
                    )}
                  </div>
                </div>
              </div>
              
              <Tabs defaultValue="details" value={activeUserTab} onValueChange={setActiveUserTab}>
                <TabsList className="grid grid-cols-3 mb-4">
                  <TabsTrigger value="details">Details</TabsTrigger>
                  <TabsTrigger value="subscriptions">Subscriptions</TabsTrigger>
                  <TabsTrigger value="exams">Exam History</TabsTrigger>
                </TabsList>
                
                <TabsContent value="details" className="space-y-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Account Information</CardTitle>
                    </CardHeader>
                    <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm text-gray-500">ID</p>
                        <p className="font-medium">{selectedUser.id}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">Registration Date</p>
                        <p className="font-medium">{formatDate(selectedUser.createdAt)}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">Email</p>
                        <p className="font-medium">{selectedUser.email}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">Phone Number</p>
                        <p className="font-medium">{selectedUser.phoneNumber || 'Not provided'}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">Account Type</p>
                        <p className="font-medium">{selectedUser.role === 'admin' ? 'Administrator' : 'Regular User'}</p>
                      </div>
                      {selectedUser.lastLogin && (
                        <div>
                          <p className="text-sm text-gray-500">Last Login</p>
                          <p className="font-medium">{formatDate(selectedUser.lastLogin)}</p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Activity Summary</CardTitle>
                    </CardHeader>
                    <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="p-4 bg-gray-50 rounded-lg">
                        <p className="text-sm text-gray-500 mb-1">Total Exams</p>
                        <p className="text-xl font-bold">{selectedUser.exams?.total || 0}</p>
                      </div>
                      <div className="p-4 bg-green-50 rounded-lg">
                        <p className="text-sm text-gray-500 mb-1">Exams Passed</p>
                        <p className="text-xl font-bold text-green-700">{selectedUser.exams?.passed || 0}</p>
                      </div>
                      <div className="p-4 bg-red-50 rounded-lg">
                        <p className="text-sm text-gray-500 mb-1">Exams Failed</p>
                        <p className="text-xl font-bold text-red-700">{selectedUser.exams?.failed || 0}</p>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
                
                <TabsContent value="subscriptions">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Subscription History</CardTitle>
                    </CardHeader>
                    <CardContent>
                      {userSubscriptions.length > 0 ? (
                        <div className="space-y-4">
                          {userSubscriptions.map(sub => (
                            <div key={sub.id} className="p-4 border rounded-lg bg-gray-50">
                              <div className="flex justify-between mb-2">
                                <h4 className="font-medium">{sub.packageName}</h4>
                                {sub.isActive ? (
                                  <Badge className="bg-green-100 text-green-800">Active</Badge>
                                ) : (
                                  <Badge variant="outline" className="text-gray-500">Expired</Badge>
                                )}
                              </div>
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
                                <div>
                                  <span className="text-gray-500">Start date: </span>
                                  <span className="font-medium">{formatDate(sub.startDate)}</span>
                                </div>
                                <div>
                                  <span className="text-gray-500">End date: </span>
                                  <span className="font-medium">{formatDate(sub.endDate)}</span>
                                </div>
                                <div>
                                  <span className="text-gray-500">Package ID: </span>
                                  <span className="font-medium">{sub.packageId}</span>
                                </div>
                                <div>
                                  <span className="text-gray-500">Subscription ID: </span>
                                  <span className="font-medium">{sub.id}</span>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="text-center py-8 text-gray-500">
                          <p>No subscription history found.</p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </TabsContent>
                
                <TabsContent value="exams">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Exam History</CardTitle>
                    </CardHeader>
                    <CardContent>
                      {userExams.length > 0 ? (
                        <div className="overflow-x-auto">
                          <Table>
                            <TableHeader>
                              <TableRow>
                                <TableHead>Exam ID</TableHead>
                                <TableHead>Date</TableHead>
                                <TableHead>Score</TableHead>
                                <TableHead>Result</TableHead>
                              </TableRow>
                            </TableHeader>
                            <TableBody>
                              {userExams.map(exam => (
                                <TableRow key={exam.id}>
                                  <TableCell className="font-medium">#{exam.id}</TableCell>
                                  <TableCell>{formatDate(exam.date)}</TableCell>
                                  <TableCell>{exam.score}%</TableCell>
                                  <TableCell>
                                    {exam.isPassed ? (
                                      <div className="flex items-center">
                                        <CheckCircle2 className="h-4 w-4 text-green-500 mr-1" />
                                        <span className="text-green-600">Passed</span>
                                      </div>
                                    ) : (
                                      <div className="flex items-center">
                                        <XCircle className="h-4 w-4 text-red-500 mr-1" />
                                        <span className="text-red-600">Failed</span>
                                      </div>
                                    )}
                                  </TableCell>
                                </TableRow>
                              ))}
                            </TableBody>
                          </Table>
                        </div>
                      ) : (
                        <div className="text-center py-8 text-gray-500">
                          <p>No exam history found.</p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </div>
          )}
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsViewDialogOpen(false)}>Close</Button>
            <Button onClick={() => { 
              setIsViewDialogOpen(false);
              if (selectedUser) handleEditUser(selectedUser);
            }} className="bg-[#0078D7]">
              <Edit className="h-4 w-4 mr-2" />
              Edit User
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add User Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add New User</DialogTitle>
            <DialogDescription>Create a new user account</DialogDescription>
          </DialogHeader>
          
          <Form {...addUserForm}>
            <form onSubmit={addUserForm.handleSubmit(onAddUserSubmit)} className="space-y-4">
              <FormField
                control={addUserForm.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email</FormLabel>
                    <FormControl>
                      <Input placeholder="user@example.com" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={addUserForm.control}
                name="fullName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Full Name</FormLabel>
                    <FormControl>
                      <Input placeholder="John Doe" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={addUserForm.control}
                name="phoneNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Phone Number (Optional)</FormLabel>
                    <FormControl>
                      <Input placeholder="+123456789" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={addUserForm.control}
                name="password"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Password</FormLabel>
                    <FormControl>
                      <Input type="password" placeholder="******" {...field} />
                    </FormControl>
                    <FormDescription>
                      Must be at least 6 characters long
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={addUserForm.control}
                name="role"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Role</FormLabel>
                    <Select 
                      onValueChange={field.onChange} 
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a role" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="user">Regular User</SelectItem>
                        <SelectItem value="admin">Administrator</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <DialogFooter className="pt-4">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsAddDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  disabled={isProcessing}
                  className="bg-[#0078D7]"
                >
                  {isProcessing ? (
                    <>
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                      Creating...
                    </>
                  ) : (
                    <>
                      <UserPlus className="h-4 w-4 mr-2" />
                      Create User
                    </>
                  )}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Edit User Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit User</DialogTitle>
            <DialogDescription>Update user information</DialogDescription>
          </DialogHeader>
          
          <Form {...editUserForm}>
            <form onSubmit={editUserForm.handleSubmit(onEditUserSubmit)} className="space-y-4">
              <FormField
                control={editUserForm.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email</FormLabel>
                    <FormControl>
                      <Input placeholder="user@example.com" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={editUserForm.control}
                name="fullName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Full Name</FormLabel>
                    <FormControl>
                      <Input placeholder="John Doe" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={editUserForm.control}
                name="phoneNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Phone Number (Optional)</FormLabel>
                    <FormControl>
                      <Input placeholder="+123456789" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={editUserForm.control}
                name="role"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Role</FormLabel>
                    <Select 
                      onValueChange={field.onChange} 
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a role" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="user">Regular User</SelectItem>
                        <SelectItem value="admin">Administrator</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <DialogFooter className="pt-4">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsEditDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  disabled={isProcessing}
                  className="bg-[#0078D7]"
                >
                  {isProcessing ? (
                    <>
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                      Updating...
                    </>
                  ) : (
                    <>
                      <Edit className="h-4 w-4 mr-2" />
                      Update User
                    </>
                  )}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="text-red-600">Confirm Deletion</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this user? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          
          {selectedUser && (
            <div className="p-4 border border-red-200 rounded-md bg-red-50">
              <div className="flex items-center">
                <div className="w-8 h-8 rounded-full bg-red-100 flex items-center justify-center text-xs font-medium text-red-600 mr-3">
                  {selectedUser.fullName ? selectedUser.fullName.charAt(0).toUpperCase() : selectedUser.email.charAt(0).toUpperCase()}
                </div>
                <div>
                  <p className="font-medium">{selectedUser.fullName || 'No Name'}</p>
                  <p className="text-sm text-gray-600">{selectedUser.email}</p>
                </div>
              </div>
            </div>
          )}
          
          <DialogFooter className="pt-4">
            <Button 
              variant="outline" 
              onClick={() => setIsDeleteDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button 
              variant="destructive" 
              onClick={handleDeleteUser}
              disabled={isProcessing}
            >
              {isProcessing ? (
                <>
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  Deleting...
                </>
              ) : (
                <>
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete User
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default UserManagement;