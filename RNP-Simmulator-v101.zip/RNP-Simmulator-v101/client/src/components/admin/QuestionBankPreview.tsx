import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Clock, AlertCircle, Image, CheckCircle } from "lucide-react";

// Sample question types for preview
const questionTypes = [
  { 
    id: 1, 
    type: "Road Signs", 
    question: "What does this sign indicate?", 
    hasImage: true, 
    imagePath: "#",
    options: [
      { id: 1, text: "No entry", isCorrect: false },
      { id: 2, text: "Stop", isCorrect: true },
      { id: 3, text: "Give way", isCorrect: false },
      { id: 4, text: "No stopping", isCorrect: false }
    ]
  },
  { 
    id: 2, 
    type: "Traffic Laws", 
    question: "What is the maximum speed limit in urban areas?", 
    hasImage: false,
    options: [
      { id: 1, text: "30 km/h", isCorrect: false },
      { id: 2, text: "50 km/h", isCorrect: true },
      { id: 3, text: "60 km/h", isCorrect: false },
      { id: 4, text: "70 km/h", isCorrect: false }
    ]
  },
  { 
    id: 3, 
    type: "Vehicle Operation", 
    question: "When approaching a roundabout, who has the right of way?", 
    hasImage: false,
    options: [
      { id: 1, text: "Vehicles entering the roundabout", isCorrect: false },
      { id: 2, text: "Vehicles on the right", isCorrect: false },
      { id: 3, text: "Vehicles already in the roundabout", isCorrect: true },
      { id: 4, text: "Vehicles on the left", isCorrect: false }
    ]
  }
];

const QuestionBankPreview = () => {
  const [activeTab, setActiveTab] = useState<string>("all");
  const [selectedQuestionId, setSelectedQuestionId] = useState<number>(1);
  
  const selectedQuestion = questionTypes.find(q => q.id === selectedQuestionId);
  
  const filteredQuestions = activeTab === "all" 
    ? questionTypes
    : questionTypes.filter(q => q.type === activeTab);
  
  return (
    <div className="space-y-4">
      <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-4">
          <TabsTrigger value="all">All</TabsTrigger>
          <TabsTrigger value="Road Signs">Road Signs</TabsTrigger>
          <TabsTrigger value="Traffic Laws">Traffic Laws</TabsTrigger>
          <TabsTrigger value="Vehicle Operation">Vehicle Operation</TabsTrigger>
        </TabsList>
      </Tabs>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1 space-y-4">
          <p className="text-sm font-medium">Sample Questions</p>
          <div className="space-y-2">
            {filteredQuestions.map(q => (
              <div 
                key={q.id}
                className={`p-3 rounded-md cursor-pointer border ${selectedQuestionId === q.id ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:bg-gray-50'}`}
                onClick={() => setSelectedQuestionId(q.id)}
              >
                <div className="flex justify-between items-start mb-2">
                  <Badge className="bg-blue-100 text-blue-800">{q.type}</Badge>
                  {q.hasImage && <Image className="h-4 w-4 text-gray-500" />}
                </div>
                <p className="text-sm">{q.question}</p>
                <div className="flex items-center mt-2 text-xs text-gray-500">
                  <Clock className="h-3 w-3 mr-1" />
                  <span>Est. time: 30 sec</span>
                </div>
              </div>
            ))}
          </div>
        </div>
        
        <div className="lg:col-span-2">
          {selectedQuestion && (
            <div className="border rounded-md p-4 space-y-4">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="font-medium">Question Preview</h3>
                  <p className="text-sm text-gray-500">ID: {selectedQuestion.id}</p>
                </div>
                <Badge className="bg-blue-100 text-blue-800">{selectedQuestion.type}</Badge>
              </div>
              
              <Separator />
              
              <div>
                <p className="font-medium mb-2">{selectedQuestion.question}</p>
                {selectedQuestion.hasImage && (
                  <div className="flex items-center justify-center bg-gray-100 rounded-md p-6 mb-4">
                    <div className="flex flex-col items-center text-gray-500">
                      <Image className="h-16 w-16 mb-2" />
                      <p className="text-sm">Traffic sign image placeholder</p>
                    </div>
                  </div>
                )}
                
                <div className="mt-4">
                  <p className="text-sm font-medium mb-2">Options:</p>
                  <RadioGroup defaultValue="">
                    {selectedQuestion.options.map(option => (
                      <div key={option.id} className="flex items-start space-x-2 mb-3">
                        <RadioGroupItem value={option.id.toString()} id={`option-${option.id}`} />
                        <div className="grid gap-1.5 leading-none">
                          <Label 
                            htmlFor={`option-${option.id}`}
                            className={option.isCorrect ? "text-green-700 font-medium" : ""}
                          >
                            {option.text}
                            {option.isCorrect && (
                              <CheckCircle className="h-4 w-4 inline-block ml-2 text-green-600" />
                            )}
                          </Label>
                        </div>
                      </div>
                    ))}
                  </RadioGroup>
                </div>
              </div>
              
              <Separator />
              
              <div className="flex justify-between">
                <div className="flex items-center text-sm text-gray-600">
                  <AlertCircle className="h-4 w-4 mr-1" />
                  <span>Difficulty: Medium</span>
                </div>
                <Button variant="outline" size="sm">
                  Edit Question
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default QuestionBankPreview;