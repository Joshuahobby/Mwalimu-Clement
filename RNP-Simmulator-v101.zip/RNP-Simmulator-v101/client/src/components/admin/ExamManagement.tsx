import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle, 
  CardFooter 
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { 
  BarChart, 
  Bar, 
  PieChart, 
  Pie, 
  Cell, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer 
} from 'recharts';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { format } from "date-fns";
import { 
  Users, FileText, Filter, Calendar, ArrowUpDown, 
  CheckCircle, XCircle, Clock, BarChart as BarChartIcon, 
  Search, MoreHorizontal, FileSpreadsheet, RefreshCw,
  Settings, Eye, Printer, AlertTriangle
} from "lucide-react";
import QuestionBankPreview from "@/components/admin/QuestionBankPreview";

interface User {
  id: number;
  email: string;
  fullName?: string;
}

interface Answer {
  id: number;
  text: string;
  isCorrect: boolean;
}

interface Question {
  id: number;
  text: string;
  category: string;
  imageUrl?: string;
  answers: Answer[];
}

interface ExamQuestion {
  id: number;
  examId: number;
  questionId: number;
  selectedAnswerId?: number;
  isCorrect?: boolean;
  question: Question;
}

interface Exam {
  id: number;
  userId: number;
  startTime: string;
  endTime?: string;
  isCompleted: boolean;
  score?: number;
  totalQuestions: number;
  user: User;
  examQuestions?: ExamQuestion[];
  passFailStatus?: "passed" | "failed" | "incomplete";
  percentageScore?: number;
}

interface ExamStats {
  totalExams: number;
  completedExams: number;
  averageScore: number;
  passRate: number;
  totalUsers: number;
  examScoreDistribution: ScoreDistribution[];
  categoryPerformance: CategoryPerformance[];
  recentExams: Exam[];
}

interface ScoreDistribution {
  range: string;
  count: number;
  color: string;
}

interface CategoryPerformance {
  category: string;
  averageScore: number;
  color: string;
}

const initialStats: ExamStats = {
  totalExams: 0,
  completedExams: 0,
  averageScore: 0,
  passRate: 0,
  totalUsers: 0,
  examScoreDistribution: [],
  categoryPerformance: [],
  recentExams: [],
};

const ExamManagement = () => {
  const [loading, setLoading] = useState<boolean>(true);
  const [stats, setStats] = useState<ExamStats>(initialStats);
  const [activeTab, setActiveTab] = useState<string>("dashboard");
  const [isDetailsOpen, setIsDetailsOpen] = useState<boolean>(false);
  const [isConfigOpen, setIsConfigOpen] = useState<boolean>(false);
  const [selectedExam, setSelectedExam] = useState<Exam | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [dateFilter, setDateFilter] = useState<Date | undefined>(undefined);
  const [sortField, setSortField] = useState<string | null>(null);
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc");
  
  const { toast } = useToast();

  useEffect(() => {
    // Simulate API call
    setTimeout(() => {
      const mockStats: ExamStats = {
        totalExams: 256,
        completedExams: 214,
        averageScore: 14.8,
        passRate: 72.5,
        totalUsers: 187,
        examScoreDistribution: [
          { range: '90-100%', count: 42, color: '#4ade80' },
          { range: '80-89%', count: 67, color: '#a3e635' },
          { range: '70-79%', count: 46, color: '#facc15' },
          { range: '60-69%', count: 33, color: '#fb923c' },
          { range: '<60%', count: 26, color: '#f87171' },
        ],
        categoryPerformance: [
          { category: 'Road Signs', averageScore: 84, color: '#60a5fa' },
          { category: 'Traffic Laws', averageScore: 76, color: '#a78bfa' },
          { category: 'Vehicle Operation', averageScore: 64, color: '#fb7185' },
          { category: 'Safety Procedures', averageScore: 88, color: '#4ade80' },
          { category: 'Emergency Response', averageScore: 72, color: '#fbbf24' },
        ],
        recentExams: [
          {
            id: 1,
            userId: 123,
            startTime: '2025-04-14T09:25:00.000Z',
            endTime: '2025-04-14T09:45:00.000Z',
            isCompleted: true,
            score: 17,
            totalQuestions: 20,
            passFailStatus: 'passed',
            percentageScore: 85,
            user: {
              id: 123,
              email: 'getrwanda@gmail.com',
              fullName: 'Mwalimu Clement',
            }
          },
          {
            id: 2,
            userId: 124,
            startTime: '2025-04-14T10:10:00.000Z',
            endTime: '2025-04-14T10:28:00.000Z',
            isCompleted: true,
            score: 13,
            totalQuestions: 20,
            passFailStatus: 'failed',
            percentageScore: 65,
            user: {
              id: 124,
              email: 'user@example.com',
              fullName: 'Jean Bosco',
            }
          },
          {
            id: 3,
            userId: 125,
            startTime: '2025-04-14T11:15:00.000Z',
            isCompleted: false,
            totalQuestions: 20,
            passFailStatus: 'incomplete',
            user: {
              id: 125,
              email: 'trainee@example.com',
              fullName: 'Eric Ndahiro',
            }
          },
          {
            id: 4,
            userId: 126,
            startTime: '2025-04-13T14:30:00.000Z',
            endTime: '2025-04-13T14:48:00.000Z',
            isCompleted: true,
            score: 16,
            totalQuestions: 20,
            passFailStatus: 'passed',
            percentageScore: 80,
            user: {
              id: 126,
              email: 'driver@example.com',
              fullName: 'Marie Uwase',
            }
          },
          {
            id: 5,
            userId: 127,
            startTime: '2025-04-13T16:05:00.000Z',
            endTime: '2025-04-13T16:25:00.000Z',
            isCompleted: true,
            score: 15,
            totalQuestions: 20,
            passFailStatus: 'passed',
            percentageScore: 75,
            user: {
              id: 127,
              email: 'student@example.com',
              fullName: 'Joseph Mugabo',
            }
          }
        ]
      };
      
      // Generate more mock exams
      const mockExams = [...mockStats.recentExams];
      for (let i = 6; i <= 30; i++) {
        const score = Math.floor(Math.random() * 21);
        const isCompleted = Math.random() > 0.2;
        mockExams.push({
          id: i,
          userId: 120 + i,
          startTime: new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000).toISOString(),
          endTime: isCompleted ? new Date(Date.now() - Math.random() * 6 * 24 * 60 * 60 * 1000).toISOString() : undefined,
          isCompleted,
          score: isCompleted ? score : undefined,
          totalQuestions: 20,
          passFailStatus: !isCompleted ? 'incomplete' : (score >= 14 ? 'passed' : 'failed'),
          percentageScore: isCompleted ? (score / 20) * 100 : undefined,
          user: {
            id: 120 + i,
            email: `user${i}@example.com`,
            fullName: `Test User ${i}`,
          }
        });
      }
      
      setStats({
        ...mockStats,
        recentExams: mockExams.slice(0, 5)
      });
      setLoading(false);
    }, 1000);
  }, []);

  // Format date
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString('en-US', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: 'numeric',
      minute: 'numeric',
      hour12: true
    });
  };

  // Format duration
  const formatDuration = (startTime: string, endTime?: string) => {
    if (!endTime) return 'In progress';
    
    const start = new Date(startTime).getTime();
    const end = new Date(endTime).getTime();
    const durationMs = end - start;
    
    const minutes = Math.floor(durationMs / (1000 * 60));
    const seconds = Math.floor((durationMs % (1000 * 60)) / 1000);
    
    return `${minutes}m ${seconds}s`;
  };

  // Calculate pass rate for a specific category
  const calculateCategoryPassRate = (category: string): number => {
    // This would typically come from real data analysis
    // For now, we'll use a simple mapping for demonstration purposes
    const passRateMap: {[key: string]: number} = {
      'Road Signs': 82,
      'Traffic Laws': 76,
      'Vehicle Operation': 64,
      'Safety Procedures': 88,
      'Emergency Response': 72
    };
    
    return passRateMap[category] || Math.floor(Math.random() * 30) + 60;
  };
  
  // Handle column header click for sorting
  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  // View exam details
  const handleViewExam = (exam: Exam) => {
    setSelectedExam(exam);
    setIsDetailsOpen(true);
  };

  // Reset filters
  const resetFilters = () => {
    setSearchQuery("");
    setStatusFilter("all");
    setDateFilter(undefined);
    setSortField(null);
    setSortDirection("desc");
  };

  // Export exam data
  const handleExport = () => {
    toast({
      title: "Export Started",
      description: "Exam data is being exported. Please wait...",
    });
    
    setTimeout(() => {
      toast({
        title: "Export Complete",
        description: "Exam data has been exported successfully.",
      });
    }, 1500);
  };

  // Render exam status badge
  const renderStatusBadge = (exam: Exam) => {
    if (!exam.isCompleted) {
      return (
        <Badge className="bg-yellow-100 text-yellow-800">
          <Clock className="h-3 w-3 mr-1" />
          Incomplete
        </Badge>
      );
    }
    
    if (exam.passFailStatus === 'passed') {
      return (
        <Badge className="bg-green-100 text-green-800">
          <CheckCircle className="h-3 w-3 mr-1" />
          Passed
        </Badge>
      );
    } else {
      return (
        <Badge className="bg-red-100 text-red-800">
          <XCircle className="h-3 w-3 mr-1" />
          Failed
        </Badge>
      );
    }
  };

  return (
    <div className="space-y-6">
      <Tabs defaultValue="all-exams" value={activeTab} onValueChange={setActiveTab} className="w-full">
        <div className="flex justify-between items-center mb-4">
          <TabsList>
            <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
            <TabsTrigger value="all-exams">All Exams</TabsTrigger>
            <TabsTrigger value="config">Exam Config</TabsTrigger>
          </TabsList>
          <div className="flex items-center gap-2">
            <Button 
              size="sm" 
              variant="outline" 
              onClick={() => window.location.reload()}
              className="whitespace-nowrap"
            >
              <RefreshCw className="h-4 w-4 mr-2" />
              Refresh
            </Button>
            <Button 
              size="sm" 
              onClick={handleExport}
              className="whitespace-nowrap bg-[#0078D7]"
            >
              <FileSpreadsheet className="h-4 w-4 mr-2" />
              Export Data
            </Button>
          </div>
        </div>

        {/* Dashboard Tab */}
        <TabsContent value="dashboard">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {loading ? (
              Array.from({ length: 4 }).map((_, i) => (
                <Skeleton key={i} className="h-32 w-full" />
              ))
            ) : (
              <>
                {/* Total Exams */}
                <Card>
                  <CardContent className="pt-6">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="text-gray-600 text-sm">Total Exams</p>
                        <h3 className="text-2xl font-bold mt-1">{stats.totalExams}</h3>
                        <div className="flex items-center mt-2 text-sm text-gray-600">
                          <Badge className="bg-green-100 text-green-800 mr-2">
                            {stats.completedExams}
                          </Badge>
                          completed
                        </div>
                      </div>
                      <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                        <FileText className="h-5 w-5 text-blue-600" />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Average Score */}
                <Card>
                  <CardContent className="pt-6">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="text-gray-600 text-sm">Average Score</p>
                        <h3 className="text-2xl font-bold mt-1">
                          {stats.averageScore.toFixed(1)}/{20}
                        </h3>
                        <div className="flex items-center mt-2 text-sm text-gray-600">
                          {stats.averageScore >= 14 ? (
                            <Badge className="bg-green-100 text-green-800">
                              Above pass mark
                            </Badge>
                          ) : (
                            <Badge className="bg-red-100 text-red-800">
                              Below pass mark
                            </Badge>
                          )}
                        </div>
                      </div>
                      <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center">
                        <BarChartIcon className="h-5 w-5 text-purple-600" />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Pass Rate */}
                <Card>
                  <CardContent className="pt-6">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="text-gray-600 text-sm">Pass Rate</p>
                        <h3 className="text-2xl font-bold mt-1">
                          {stats.passRate.toFixed(1)}%
                        </h3>
                        <div className="flex items-center mt-2 text-sm text-gray-600">
                          {stats.completedExams > 0 ? (
                            `${stats.totalExams - stats.completedExams} pending`
                          ) : (
                            'No completed exams'
                          )}
                        </div>
                      </div>
                      <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center">
                        <CheckCircle className="h-5 w-5 text-green-600" />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Total Users */}
                <Card>
                  <CardContent className="pt-6">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="text-gray-600 text-sm">Total Users</p>
                        <h3 className="text-2xl font-bold mt-1">{stats.totalUsers}</h3>
                        <div className="flex items-center mt-2 text-sm text-gray-600">
                          {stats.totalUsers > 0 && stats.totalExams > 0 ? (
                            `Avg. ${(stats.totalExams / stats.totalUsers).toFixed(1)} exams per user`
                          ) : (
                            'No user data'
                          )}
                        </div>
                      </div>
                      <div className="w-10 h-10 rounded-full bg-yellow-100 flex items-center justify-center">
                        <Users className="h-5 w-5 text-yellow-600" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </>
            )}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            {/* Score Distribution */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg font-medium">Score Distribution</CardTitle>
                <CardDescription>Distribution of exam scores</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px] flex items-center justify-center">
                  {loading ? (
                    <Skeleton className="h-full w-full" />
                  ) : (
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={stats.examScoreDistribution}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={90}
                          paddingAngle={5}
                          dataKey="count"
                          nameKey="range"
                          label
                        >
                          {stats.examScoreDistribution.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip formatter={(value) => [`${value} exams`, 'Count']} />
                        <Legend />
                      </PieChart>
                    </ResponsiveContainer>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Category Performance */}
            <Card className="lg:row-span-2">
              <CardHeader>
                <CardTitle className="text-lg font-medium">Category Performance Analysis</CardTitle>
                <CardDescription>Comprehensive analytics by question category</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px] mb-6">
                  {loading ? (
                    <Skeleton className="h-full w-full" />
                  ) : (
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={stats.categoryPerformance}
                        layout="vertical"
                        margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis type="number" domain={[0, 100]} />
                        <YAxis dataKey="category" type="category" width={150} />
                        <Tooltip formatter={(value) => [`${value}%`, 'Average Score']} />
                        <Legend />
                        <Bar dataKey="averageScore" name="Average Score (%)">
                          {stats.categoryPerformance.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  )}
                </div>
                
                {/* Detailed Category Metrics */}
                <Separator className="my-4" />
                <h4 className="text-sm font-medium mb-4">Detailed Category Metrics</h4>
                
                <div className="space-y-6">
                  {stats.categoryPerformance.map((category, index) => (
                    <div key={index}>
                      <div className="flex justify-between items-center mb-2">
                        <div className="flex items-center">
                          <div 
                            className="w-3 h-3 rounded-full mr-2" 
                            style={{ backgroundColor: category.color }}
                          ></div>
                          <span className="font-medium">{category.category}</span>
                        </div>
                        <div className="flex items-center">
                          <span className="text-sm">{category.averageScore}% avg. score</span>
                          <Badge 
                            className={
                              category.averageScore >= 70 
                                ? "bg-green-100 text-green-800 ml-2" 
                                : "bg-amber-100 text-amber-800 ml-2"
                            }
                          >
                            {category.averageScore >= 70 ? "Above pass mark" : "Below pass mark"}
                          </Badge>
                        </div>
                      </div>
                      <div className="grid grid-cols-3 gap-4 mb-2">
                        <div className="p-2 bg-slate-50 rounded-md text-center">
                          <p className="text-xs text-gray-500">Pass Rate</p>
                          <p className="font-medium">{calculateCategoryPassRate(category.category)}%</p>
                        </div>
                        <div className="p-2 bg-slate-50 rounded-md text-center">
                          <p className="text-xs text-gray-500">Questions</p>
                          <p className="font-medium">{Math.floor(Math.random() * 40) + 20}</p>
                        </div>
                        <div className="p-2 bg-slate-50 rounded-md text-center">
                          <p className="text-xs text-gray-500">Difficulty</p>
                          <p className="font-medium">
                            {category.averageScore > 80 ? "Easy" : 
                             category.averageScore > 65 ? "Medium" : "Hard"}
                          </p>
                        </div>
                      </div>
                      <Progress 
                        value={category.averageScore} 
                        className="h-2"
                        style={{ backgroundColor: '#e5e7eb' }}
                      />
                    </div>
                  ))}
                </div>
                
                <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-md">
                  <h5 className="text-sm font-medium text-blue-900">Performance Insights</h5>
                  <p className="text-sm text-blue-800 mt-1">
                    Users are performing well in Road Signs and Safety Procedures categories, 
                    but struggling with Vehicle Operation questions. Consider providing more
                    practice questions in the challenging categories.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Recent Activity */}
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle className="text-lg font-medium">Recent Exams</CardTitle>
                  <CardDescription>Latest exam activity</CardDescription>
                </div>
                <Button 
                  size="sm" 
                  variant="outline" 
                  onClick={() => setActiveTab("all-exams")}
                >
                  View All
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="space-y-4">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Skeleton key={i} className="h-16 w-full" />
                  ))}
                </div>
              ) : stats.recentExams.length > 0 ? (
                <div className="space-y-4">
                  {stats.recentExams.map(exam => (
                    <div key={exam.id} className="flex justify-between items-center p-3 rounded-lg bg-gray-50 hover:bg-gray-100 transition-colors">
                      <div className="flex items-center">
                        <div className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center mr-3">
                          <Users className="h-5 w-5 text-gray-600" />
                        </div>
                        <div>
                          <p className="font-medium">{exam.user?.fullName || exam.user?.email}</p>
                          <p className="text-sm text-gray-500">{formatDate(exam.startTime)}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="flex items-center justify-end mb-1">
                          {renderStatusBadge(exam)}
                        </div>
                        <p className="font-bold">
                          {exam.score !== undefined ? `${exam.score}/${exam.totalQuestions}` : 'In progress'}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  <p>No recent exams found</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* All Exams Tab */}
        <TabsContent value="all-exams">
          <Card>
            <CardHeader>
              <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
                <div>
                  <CardTitle>Exam Results</CardTitle>
                  <CardDescription>View and manage all exam results</CardDescription>
                </div>
                <div className="flex flex-col sm:flex-row gap-3">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 h-4 w-4" />
                    <Input 
                      type="text" 
                      placeholder="Search by user or ID..." 
                      className="pl-10 w-full md:w-[250px]"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                  <div className="flex items-center gap-2">
                    <Select value={statusFilter} onValueChange={setStatusFilter}>
                      <SelectTrigger className="w-full md:w-[150px]">
                        <div className="flex items-center gap-2">
                          <Filter className="h-4 w-4 text-gray-500" />
                          <SelectValue placeholder="Status" />
                        </div>
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Status</SelectItem>
                        <SelectItem value="completed">Completed</SelectItem>
                        <SelectItem value="incomplete">Incomplete</SelectItem>
                        <SelectItem value="passed">Passed</SelectItem>
                        <SelectItem value="failed">Failed</SelectItem>
                      </SelectContent>
                    </Select>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button variant="outline" className="w-full md:w-[180px] justify-start">
                          <Calendar className="mr-2 h-4 w-4" />
                          {dateFilter ? format(dateFilter, "PPP") : "Filter by Date"}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0">
                        <CalendarComponent
                          mode="single"
                          selected={dateFilter}
                          onSelect={setDateFilter}
                          initialFocus
                        />
                        {dateFilter && (
                          <div className="p-3 border-t border-gray-100">
                            <Button variant="ghost" size="sm" onClick={() => setDateFilter(undefined)}>
                              Clear Date
                            </Button>
                          </div>
                        )}
                      </PopoverContent>
                    </Popover>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col-reverse sm:flex-row justify-between items-center mb-4 gap-4">
                <div className="flex items-center text-sm text-gray-500">
                  <span className="font-medium mr-1">{stats.recentExams.length}</span> 
                  {stats.recentExams.length === 1 ? "exam" : "exams"} found
                  {(searchQuery || statusFilter !== 'all' || dateFilter) && (
                    <Button variant="ghost" size="sm" onClick={resetFilters} className="ml-2">
                      Clear Filters
                    </Button>
                  )}
                </div>
                <div>
                  <Badge className="bg-green-100 text-green-800 mr-2">
                    {stats.recentExams.filter(e => e.passFailStatus === 'passed').length} passed
                  </Badge>
                  <Badge className="bg-red-100 text-red-800 mr-2">
                    {stats.recentExams.filter(e => e.passFailStatus === 'failed').length} failed
                  </Badge>
                  <Badge className="bg-yellow-100 text-yellow-800">
                    {stats.recentExams.filter(e => e.passFailStatus === 'incomplete').length} incomplete
                  </Badge>
                </div>
              </div>

              {loading ? (
                <div className="space-y-4">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Skeleton key={i} className="h-12 w-full" />
                  ))}
                </div>
              ) : (
                <div className="overflow-x-auto rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead 
                          className="cursor-pointer"
                          onClick={() => handleSort('id')}
                        >
                          <div className="flex items-center">
                            ID
                            {sortField === 'id' && (
                              <ArrowUpDown className="ml-1 h-3 w-3" />
                            )}
                          </div>
                        </TableHead>
                        <TableHead 
                          className="cursor-pointer"
                          onClick={() => handleSort('user')}
                        >
                          <div className="flex items-center">
                            User
                            {sortField === 'user' && (
                              <ArrowUpDown className="ml-1 h-3 w-3" />
                            )}
                          </div>
                        </TableHead>
                        <TableHead 
                          className="cursor-pointer"
                          onClick={() => handleSort('date')}
                        >
                          <div className="flex items-center">
                            Date
                            {sortField === 'date' && (
                              <ArrowUpDown className="ml-1 h-3 w-3" />
                            )}
                          </div>
                        </TableHead>
                        <TableHead>Duration</TableHead>
                        <TableHead 
                          className="cursor-pointer"
                          onClick={() => handleSort('score')}
                        >
                          <div className="flex items-center">
                            Score
                            {sortField === 'score' && (
                              <ArrowUpDown className="ml-1 h-3 w-3" />
                            )}
                          </div>
                        </TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {stats.recentExams.length > 0 ? (
                        stats.recentExams.map((exam) => (
                          <TableRow key={exam.id}>
                            <TableCell className="font-medium">{exam.id}</TableCell>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <div className="w-7 h-7 rounded-full bg-gray-100 flex items-center justify-center text-xs font-medium text-gray-600">
                                  {exam.user?.fullName ? exam.user.fullName.charAt(0).toUpperCase() : exam.user?.email.charAt(0).toUpperCase()}
                                </div>
                                <div className="flex flex-col">
                                  <span>{exam.user?.fullName || 'N/A'}</span>
                                  <span className="text-xs text-gray-500">{exam.user?.email}</span>
                                </div>
                              </div>
                            </TableCell>
                            <TableCell>{formatDate(exam.startTime)}</TableCell>
                            <TableCell>{formatDuration(exam.startTime, exam.endTime)}</TableCell>
                            <TableCell>
                              {exam.score !== undefined ? (
                                <div className="flex items-center">
                                  <span className="font-medium">{exam.score}/{exam.totalQuestions}</span>
                                  <span className="text-xs text-gray-500 ml-1">
                                    ({((exam.score / exam.totalQuestions) * 100).toFixed(0)}%)
                                  </span>
                                </div>
                              ) : (
                                <span className="text-gray-500">-</span>
                              )}
                            </TableCell>
                            <TableCell>{renderStatusBadge(exam)}</TableCell>
                            <TableCell className="text-right">
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="icon">
                                    <MoreHorizontal className="h-4 w-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuLabel>Actions</DropdownMenuLabel>
                                  <DropdownMenuItem onClick={() => handleViewExam(exam)}>
                                    <Eye className="h-4 w-4 mr-2" />
                                    View Details
                                  </DropdownMenuItem>
                                  <DropdownMenuItem>
                                    <Printer className="h-4 w-4 mr-2" />
                                    Print Result
                                  </DropdownMenuItem>
                                  <DropdownMenuSeparator />
                                  <DropdownMenuItem>
                                    <AlertTriangle className="h-4 w-4 mr-2" />
                                    Flag for Review
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </TableCell>
                          </TableRow>
                        ))
                      ) : (
                        <TableRow>
                          <TableCell colSpan={7} className="text-center py-6 text-gray-500">
                            No exam results found
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Configuration Tab */}
        <TabsContent value="config">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Left column */}
            <div className="space-y-6">
              {/* Exam Settings */}
              <Card>
                <CardHeader>
                  <CardTitle>Exam Settings</CardTitle>
                  <CardDescription>Configure exam defaults and behavior</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Questions Per Exam</label>
                        <Input type="text" value="20" disabled />
                        <p className="text-xs text-amber-600">
                          Fixed at 20 questions per NTPR requirements
                        </p>
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Time Limit (minutes)</label>
                        <Input type="text" value="20" disabled />
                        <p className="text-xs text-amber-600">
                          Fixed at 20 minutes per NTPR requirements
                        </p>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Pass Mark</label>
                        <Input type="text" value="70%" disabled />
                        <p className="text-xs text-amber-600">
                          Fixed at 70% (14/20) per NTPR requirements
                        </p>
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Attempts Allowed</label>
                        <Select defaultValue="unlimited">
                          <SelectTrigger>
                            <SelectValue placeholder="Select attempts" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="1">1 attempt</SelectItem>
                            <SelectItem value="3">3 attempts</SelectItem>
                            <SelectItem value="5">5 attempts</SelectItem>
                            <SelectItem value="unlimited">Unlimited</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Randomize Questions</label>
                        <Select defaultValue="yes">
                          <SelectTrigger>
                            <SelectValue placeholder="Select option" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="yes">Yes</SelectItem>
                            <SelectItem value="no">No</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Randomize Answers</label>
                        <Select defaultValue="yes">
                          <SelectTrigger>
                            <SelectValue placeholder="Select option" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="yes">Yes</SelectItem>
                            <SelectItem value="no">No</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              {/* Category Distribution */}
              <Card>
                <CardHeader>
                  <CardTitle>Category Distribution</CardTitle>
                  <CardDescription>Set number of questions per category</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div className="space-y-4">
                      <div className="flex justify-between">
                        <span className="text-sm font-medium">Road Signs</span>
                        <span className="text-sm font-medium">{calculateCategoryPassRate('Road Signs')}%</span>
                      </div>
                      <Progress value={calculateCategoryPassRate('Road Signs')} className="h-2" />
                      
                      <div className="flex justify-between">
                        <span className="text-sm font-medium">Traffic Laws</span>
                        <span className="text-sm font-medium">{calculateCategoryPassRate('Traffic Laws')}%</span>
                      </div>
                      <Progress value={calculateCategoryPassRate('Traffic Laws')} className="h-2" />
                      
                      <div className="flex justify-between">
                        <span className="text-sm font-medium">Vehicle Operation</span>
                        <span className="text-sm font-medium">{calculateCategoryPassRate('Vehicle Operation')}%</span>
                      </div>
                      <Progress value={calculateCategoryPassRate('Vehicle Operation')} className="h-2" />
                      
                      <div className="flex justify-between">
                        <span className="text-sm font-medium">Safety Procedures</span>
                        <span className="text-sm font-medium">{calculateCategoryPassRate('Safety Procedures')}%</span>
                      </div>
                      <Progress value={calculateCategoryPassRate('Safety Procedures')} className="h-2" />
                      
                      <div className="flex justify-between">
                        <span className="text-sm font-medium">Emergency Response</span>
                        <span className="text-sm font-medium">{calculateCategoryPassRate('Emergency Response')}%</span>
                      </div>
                      <Progress value={calculateCategoryPassRate('Emergency Response')} className="h-2" />
                    </div>
                    
                    <div className="p-3 bg-blue-50 rounded-md">
                      <p className="text-sm text-blue-800">
                        <strong>Note:</strong> The distribution above represents the current question pool. 
                        Each exam will contain 20 questions selected randomly from these categories.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            {/* Right column */}
            <div className="space-y-6">
              {/* User Experience */}
              <Card>
                <CardHeader>
                  <CardTitle>User Experience</CardTitle>
                  <CardDescription>Configure how users interact with exams</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Navigation</label>
                        <Select defaultValue="both">
                          <SelectTrigger>
                            <SelectValue placeholder="Select navigation" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="sequential">Sequential only</SelectItem>
                            <SelectItem value="free">Free navigation</SelectItem>
                            <SelectItem value="both">Combined</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Question Review</label>
                        <Select defaultValue="allowed">
                          <SelectTrigger>
                            <SelectValue placeholder="Select option" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="allowed">Allowed during exam</SelectItem>
                            <SelectItem value="afterSubmit">After submission only</SelectItem>
                            <SelectItem value="disabled">Disabled</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Time Display</label>
                        <Select defaultValue="countdown">
                          <SelectTrigger>
                            <SelectValue placeholder="Select option" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="countdown">Countdown Timer</SelectItem>
                            <SelectItem value="elapsed">Elapsed Time</SelectItem>
                            <SelectItem value="both">Both</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Results Display</label>
                        <Select defaultValue="score">
                          <SelectTrigger>
                            <SelectValue placeholder="Select option" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="score">Score Only</SelectItem>
                            <SelectItem value="detailed">Detailed Analysis</SelectItem>
                            <SelectItem value="full">Full Review with Answers</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Certification</label>
                        <Select defaultValue="pass">
                          <SelectTrigger>
                            <SelectValue placeholder="Select option" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="pass">Passing Only</SelectItem>
                            <SelectItem value="all">All Attempts</SelectItem>
                            <SelectItem value="none">None</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Time Warning</label>
                        <Select defaultValue="5min">
                          <SelectTrigger>
                            <SelectValue placeholder="Select option" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="none">Disabled</SelectItem>
                            <SelectItem value="10min">10 minutes remaining</SelectItem>
                            <SelectItem value="5min">5 minutes remaining</SelectItem>
                            <SelectItem value="both">Both</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              {/* Question Bank Preview */}
              <Card>
                <CardHeader>
                  <CardTitle>Question Bank Preview</CardTitle>
                  <CardDescription>Preview questions used in exams</CardDescription>
                </CardHeader>
                <CardContent>
                  <QuestionBankPreview />
                </CardContent>
                <CardFooter className="border-t px-6 py-4">
                  <Button 
                    onClick={() => setActiveTab("questions")} 
                    className="w-full bg-[#0078D7]"
                  >
                    <Settings className="h-4 w-4 mr-2" />
                    Manage Question Bank
                  </Button>
                </CardFooter>
              </Card>
            </div>
          </div>
        </TabsContent>
      </Tabs>

      {/* Exam Details Dialog */}
      <Dialog open={isDetailsOpen} onOpenChange={setIsDetailsOpen}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>Exam Details</DialogTitle>
            <DialogDescription>
              {selectedExam?.id ? `Exam #${selectedExam.id} - ${formatDate(selectedExam.startTime)}` : ''}
            </DialogDescription>
          </DialogHeader>
          {selectedExam && (
            <div className="space-y-6">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-sm text-gray-500">User</p>
                  <div className="flex items-center gap-2 mt-1">
                    <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center">
                      <Users className="h-4 w-4 text-gray-600" />
                    </div>
                    <div>
                      <p className="font-medium">{selectedExam.user?.fullName || 'Unknown User'}</p>
                      <p className="text-sm text-gray-500">{selectedExam.user?.email}</p>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm text-gray-500">Status</p>
                  <div className="mt-1">
                    {renderStatusBadge(selectedExam)}
                  </div>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="space-y-1">
                  <p className="text-sm text-gray-500">Date & Time</p>
                  <p className="font-medium">{formatDate(selectedExam.startTime)}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm text-gray-500">Duration</p>
                  <span className="font-medium">{formatDuration(selectedExam.startTime, selectedExam.endTime)}</span>
                </div>
                <div className="space-y-1">
                  <p className="text-sm text-gray-500">Score</p>
                  <div className="flex items-center">
                    {selectedExam.score !== undefined ? (
                      <>
                        <span className="font-medium">{selectedExam.score}/{selectedExam.totalQuestions}</span>
                        <Badge 
                          className={
                            selectedExam.passFailStatus === 'passed' 
                              ? 'bg-green-100 text-green-800 ml-2' 
                              : 'bg-red-100 text-red-800 ml-2'
                          }
                        >
                          {selectedExam.percentageScore?.toFixed(0)}%
                        </Badge>
                      </>
                    ) : (
                      <span>Not completed</span>
                    )}
                  </div>
                </div>
              </div>
              
              <Separator />
              
              <div>
                <h3 className="text-lg font-medium mb-4">Question Summary</h3>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <Card>
                      <CardContent className="p-4">
                        <div className="text-center">
                          <p className="text-gray-500 text-sm">Total Questions</p>
                          <p className="text-2xl font-bold mt-1">{selectedExam.totalQuestions}</p>
                        </div>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="p-4">
                        <div className="text-center">
                          <p className="text-gray-500 text-sm">Correct</p>
                          <p className="text-2xl font-bold mt-1 text-green-600">
                            {selectedExam.score || '0'}
                          </p>
                        </div>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="p-4">
                        <div className="text-center">
                          <p className="text-gray-500 text-sm">Incorrect</p>
                          <p className="text-2xl font-bold mt-1 text-red-600">
                            {selectedExam.isCompleted ? (selectedExam.totalQuestions - (selectedExam.score || 0)) : '0'}
                          </p>
                        </div>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="p-4">
                        <div className="text-center">
                          <p className="text-gray-500 text-sm">Unanswered</p>
                          <p className="text-2xl font-bold mt-1 text-gray-500">
                            {!selectedExam.isCompleted ? selectedExam.totalQuestions : '0'}
                          </p>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </div>
              
              <Separator />
              
              <div>
                <h3 className="text-lg font-medium mb-4">Category Performance</h3>
                <div className="space-y-4">
                  {stats.categoryPerformance.map((category, index) => (
                    <div key={index} className="flex justify-between items-center">
                      <div className="flex items-center gap-2">
                        <div 
                          className="w-3 h-3 rounded-full" 
                          style={{ backgroundColor: category.color }}
                        ></div>
                        <span>{category.category}</span>
                      </div>
                      <div className="flex items-center">
                        <span>
                          {Math.floor(Math.random() * 5) + 1}/{Math.floor(Math.random() * 5) + 1} correct
                        </span>
                        <Badge 
                          className={`ml-2 ${
                            Math.random() > 0.5 
                              ? 'bg-green-100 text-green-800' 
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {Math.floor(Math.random() * 40) + 60}%
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDetailsOpen(false)}>Close</Button>
            <Button className="bg-[#0078D7]">
              <Printer className="h-4 w-4 mr-2" />
              Print Results
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Exam Configuration Dialog */}
      <Dialog open={isConfigOpen} onOpenChange={setIsConfigOpen}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>Exam Configuration</DialogTitle>
            <DialogDescription>
              Configure exam settings and parameters
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-6">
            <div className="space-y-4">
              <h3 className="text-sm font-medium">Exam Length</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm text-gray-500">Questions per exam</label>
                  <Select defaultValue="20" disabled>
                    <SelectTrigger>
                      <SelectValue placeholder="Select questions" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="20">20 questions (Fixed)</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-amber-600 mt-1">
                    Note: Fixed at 20 questions per NTPR requirements
                  </p>
                </div>
                <div className="space-y-2">
                  <label className="text-sm text-gray-500">Time limit (minutes)</label>
                  <Select defaultValue="20" disabled>
                    <SelectTrigger>
                      <SelectValue placeholder="Select time limit" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="20">20 minutes (Fixed)</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-amber-600 mt-1">
                    Note: Fixed at 20 minutes per NTPR requirements
                  </p>
                </div>
              </div>
            </div>
            
            <Separator />
            
            <div className="space-y-4">
              <h3 className="text-sm font-medium">Passing Criteria</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm text-gray-500">Minimum score (%)</label>
                  <Select defaultValue="70" disabled>
                    <SelectTrigger>
                      <SelectValue placeholder="Select minimum score" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="70">70% (14/20 questions)</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-amber-600 mt-1">
                    Note: Fixed at 70% pass mark per NTPR requirements
                  </p>
                </div>
              </div>
            </div>
            
            <Separator />
            
            <div className="space-y-4">
              <h3 className="text-sm font-medium">Question Selection</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm text-gray-500">Selection method</label>
                  <Select defaultValue="random">
                    <SelectTrigger>
                      <SelectValue placeholder="Select method" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="random">Random</SelectItem>
                      <SelectItem value="sequential">Sequential</SelectItem>
                      <SelectItem value="difficulty">By difficulty</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm text-gray-500">Category distribution</label>
                  <Select defaultValue="auto">
                    <SelectTrigger>
                      <SelectValue placeholder="Select distribution" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="auto">Auto-balanced</SelectItem>
                      <SelectItem value="equal">Equal distribution</SelectItem>
                      <SelectItem value="custom">Custom weights</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
            
            <Separator />
            
            <div className="space-y-4">
              <h3 className="text-sm font-medium">Result Display</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm text-gray-500">Show correct answers</label>
                  <Select defaultValue="after">
                    <SelectTrigger>
                      <SelectValue placeholder="Select when to show" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="after">After completion</SelectItem>
                      <SelectItem value="during">During exam</SelectItem>
                      <SelectItem value="never">Never</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm text-gray-500">Certificate</label>
                  <Select defaultValue="passing">
                    <SelectTrigger>
                      <SelectValue placeholder="Select when to issue" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="passing">For passing only</SelectItem>
                      <SelectItem value="all">For all attempts</SelectItem>
                      <SelectItem value="none">No certificates</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsConfigOpen(false)}>Cancel</Button>
            <Button 
              onClick={() => {
                setIsConfigOpen(false);
                toast({
                  title: "Configuration Updated",
                  description: "Exam configuration has been updated successfully.",
                });
              }}
              className="bg-[#0078D7]"
            >
              <CheckCircle className="h-4 w-4 mr-2" />
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ExamManagement;