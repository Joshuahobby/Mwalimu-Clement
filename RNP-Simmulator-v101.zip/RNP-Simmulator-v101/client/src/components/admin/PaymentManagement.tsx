import { useState, useEffect, useMemo } from "react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { 
  Eye, Download, Filter, Search, Calendar, DollarSign, CreditCard, 
  RefreshCw, CheckCircle, XCircle, Clock, ArrowUpDown, ChevronDown,
  FileText, MoreHorizontal, Users
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import {
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger
} from "@/components/ui/tabs";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { format } from "date-fns";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from "recharts";
import { Separator } from "@/components/ui/separator";

interface Payment {
  id: number;
  userId: number;
  packageId: number;
  amount: number;
  currency: string;
  status: string;
  paymentMethod: string;
  transactionId: string;
  transactionRef?: string;
  processingFee?: number;
  createdAt: string;
  notes?: string;
  user: {
    email: string;
    fullName?: string;
    id: number;
  };
  package: {
    name: string;
    id: number;
  };
}

interface PaymentSummary {
  totalRevenue: number;
  totalTransactions: number;
  completedTransactions: number;
  pendingTransactions: number;
  failedTransactions: number;
  averageAmount: number;
  currency: string;
}

interface RevenueData {
  name: string;
  revenue: number;
}

interface PaymentMethodData {
  name: string;
  value: number;
  color: string;
}

const PaymentManagement = () => {
  const [payments, setPayments] = useState<Payment[]>([]);
  const [filteredPayments, setFilteredPayments] = useState<Payment[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState("all");
  const [dateFilter, setDateFilter] = useState<Date | undefined>(undefined);
  const [searchQuery, setSearchQuery] = useState("");
  const [sortField, setSortField] = useState<string | null>(null);
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc");
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);
  const [selectedPayment, setSelectedPayment] = useState<Payment | null>(null);
  const [activeTab, setActiveTab] = useState("all-payments");
  const { toast } = useToast();

  // Payment summary stats
  const [summary, setSummary] = useState<PaymentSummary>({
    totalRevenue: 0,
    totalTransactions: 0,
    completedTransactions: 0,
    pendingTransactions: 0,
    failedTransactions: 0,
    averageAmount: 0,
    currency: "RWF"
  });

  // Mock revenue data for charts
  const revenueData: RevenueData[] = [
    { name: 'Jan', revenue: 18000 },
    { name: 'Feb', revenue: 25000 },
    { name: 'Mar', revenue: 32000 },
    { name: 'Apr', revenue: 41000 },
    { name: 'May', revenue: 35000 },
    { name: 'Jun', revenue: 48000 },
    { name: 'Jul', revenue: 52000 },
  ];

  // Mock payment method distribution data
  const paymentMethodData: PaymentMethodData[] = [
    { name: 'Mobile Money', value: 65, color: '#0088FE' },
    { name: 'Card Payment', value: 20, color: '#00C49F' },
    { name: 'Bank Transfer', value: 15, color: '#FFBB28' },
  ];

  useEffect(() => {
    const fetchPayments = async () => {
      try {
        setLoading(true);
        const response = await fetch('/api/admin/payments', {
          credentials: 'include',
        });
        
        if (!response.ok) {
          throw new Error('Failed to fetch payments');
        }
        
        const data = await response.json();
        setPayments(data.payments);
        
        // Calculate payment summary
        calculatePaymentSummary(data.payments);
      } catch (error) {
        console.error('Error fetching payments:', error);
        toast({
          title: 'Error',
          description: 'Failed to load payment data.',
          variant: 'destructive',
        });
      } finally {
        setLoading(false);
      }
    };

    fetchPayments();
  }, [toast]);

  // Calculate payment summary
  const calculatePaymentSummary = (paymentData: Payment[]) => {
    if (!paymentData || paymentData.length === 0) {
      return;
    }

    const totalTransactions = paymentData.length;
    const completedTransactions = paymentData.filter(p => p.status === 'completed').length;
    const pendingTransactions = paymentData.filter(p => p.status === 'pending').length;
    const failedTransactions = paymentData.filter(p => p.status === 'failed').length;
    
    const completedPayments = paymentData.filter(p => p.status === 'completed');
    const totalRevenue = completedPayments.reduce((sum, p) => sum + p.amount, 0);
    const averageAmount = completedPayments.length > 0 
      ? totalRevenue / completedPayments.length 
      : 0;
    
    const currency = paymentData[0]?.currency || "RWF";

    setSummary({
      totalRevenue,
      totalTransactions,
      completedTransactions,
      pendingTransactions,
      failedTransactions,
      averageAmount,
      currency
    });
  };

  // Apply filters and search whenever the source data or filters change
  useEffect(() => {
    let filtered = [...payments];
    
    // Apply status filter
    if (statusFilter !== 'all') {
      filtered = filtered.filter(payment => payment.status === statusFilter);
    }
    
    // Apply date filter
    if (dateFilter) {
      const filterDate = format(dateFilter, 'yyyy-MM-dd');
      filtered = filtered.filter(payment => {
        const paymentDate = format(new Date(payment.createdAt), 'yyyy-MM-dd');
        return paymentDate === filterDate;
      });
    }
    
    // Apply search
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(payment => 
        (payment.user?.fullName && payment.user.fullName.toLowerCase().includes(query)) ||
        payment.user?.email.toLowerCase().includes(query) ||
        payment.transactionId.toLowerCase().includes(query) ||
        (payment.transactionRef && payment.transactionRef.toLowerCase().includes(query)) ||
        payment.package.name.toLowerCase().includes(query) ||
        payment.paymentMethod.toLowerCase().includes(query)
      );
    }
    
    // Apply sorting
    if (sortField) {
      filtered.sort((a, b) => {
        let valueA: any;
        let valueB: any;
        
        switch (sortField) {
          case 'id':
            valueA = a.id;
            valueB = b.id;
            break;
          case 'user':
            valueA = a.user?.fullName || a.user?.email || '';
            valueB = b.user?.fullName || b.user?.email || '';
            break;
          case 'package':
            valueA = a.package?.name || '';
            valueB = b.package?.name || '';
            break;
          case 'amount':
            valueA = a.amount;
            valueB = b.amount;
            break;
          case 'method':
            valueA = a.paymentMethod;
            valueB = b.paymentMethod;
            break;
          case 'date':
            valueA = new Date(a.createdAt).getTime();
            valueB = new Date(b.createdAt).getTime();
            break;
          default:
            valueA = a[sortField as keyof Payment];
            valueB = b[sortField as keyof Payment];
        }
        
        if (valueA < valueB) return sortDirection === 'asc' ? -1 : 1;
        if (valueA > valueB) return sortDirection === 'asc' ? 1 : -1;
        return 0;
      });
    }
    
    setFilteredPayments(filtered);
  }, [payments, statusFilter, dateFilter, searchQuery, sortField, sortDirection]);

  // Format date to a readable format
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  // Format date without time
  const formatDateOnly = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  // Format currency
  const formatCurrency = (amount: number | null | undefined, currency: string) => {
    if (amount === null || amount === undefined) {
      return `0 ${currency}`;
    }
    return `${amount.toLocaleString()} ${currency}`;
  };

  // Handle column header click for sorting
  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  // Handle payment details view
  const handleViewPayment = (payment: Payment) => {
    setSelectedPayment(payment);
    setIsDetailsOpen(true);
  };

  // Handle export function
  const handleExport = () => {
    toast({
      title: "Export Started",
      description: "Payment data is being exported. Please wait...",
    });
    
    setTimeout(() => {
      toast({
        title: "Export Complete",
        description: "Payment data has been exported successfully.",
      });
    }, 1500);
  };

  // Clear all filters
  const clearFilters = () => {
    setStatusFilter('all');
    setDateFilter(undefined);
    setSearchQuery('');
    setSortField(null);
    setSortDirection('desc');
  };

  // Generate recent transactions for the dashboard
  const recentTransactions = useMemo(() => {
    return payments
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, 5);
  }, [payments]);

  // Payment Trends component for the Dashboard tab
  const PaymentTrends = () => {
    return (
      <Card className="col-span-2">
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle className="text-lg font-semibold">Revenue Trends</CardTitle>
              <CardDescription>Monthly revenue overview</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart
              data={revenueData}
              margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip formatter={(value) => [`${value.toLocaleString()} ${summary.currency}`, 'Revenue']} />
              <Area 
                type="monotone" 
                dataKey="revenue" 
                stroke="#0078D7" 
                fill="#0078D7" 
                fillOpacity={0.2} 
                name="Revenue"
              />
            </AreaChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    );
  };

  // Payment Method Distribution chart
  const PaymentMethodDistribution = () => {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-semibold">Payment Methods</CardTitle>
          <CardDescription>Distribution by payment method</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[250px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={paymentMethodData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  fill="#8884d8"
                  paddingAngle={5}
                  dataKey="value"
                >
                  {paymentMethodData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip formatter={(value) => [`${value}%`, 'Percentage']} />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="space-y-6">
      <Tabs defaultValue="all-payments" value={activeTab} onValueChange={setActiveTab} className="w-full">
        <div className="flex justify-between items-center mb-4">
          <TabsList>
            <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
            <TabsTrigger value="all-payments">All Payments</TabsTrigger>
            <TabsTrigger value="reports">Reports</TabsTrigger>
          </TabsList>
          <div className="flex items-center gap-2">
            <Button 
              size="sm" 
              variant="outline" 
              onClick={() => window.location.reload()}
              className="whitespace-nowrap"
            >
              <RefreshCw className="h-4 w-4 mr-2" />
              Refresh
            </Button>
            <Button 
              size="sm" 
              onClick={handleExport}
              className="whitespace-nowrap bg-[#0078D7]"
            >
              <Download className="h-4 w-4 mr-2" />
              Export Data
            </Button>
          </div>
        </div>

        {/* Dashboard Tab */}
        <TabsContent value="dashboard">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {loading ? (
              Array.from({ length: 4 }).map((_, i) => (
                <Skeleton key={i} className="h-32 w-full" />
              ))
            ) : (
              <>
                {/* Total Revenue */}
                <Card>
                  <CardContent className="pt-6">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="text-gray-600 text-sm">Total Revenue</p>
                        <h3 className="text-2xl font-bold mt-1">
                          {formatCurrency(summary.totalRevenue, summary.currency)}
                        </h3>
                        <div className="flex items-center mt-2">
                          <Badge className="bg-green-100 text-green-800">
                            <CheckCircle className="h-3 w-3 mr-1" />
                            Verified
                          </Badge>
                        </div>
                      </div>
                      <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                        <DollarSign className="h-5 w-5 text-blue-600" />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Total Transactions */}
                <Card>
                  <CardContent className="pt-6">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="text-gray-600 text-sm">Total Transactions</p>
                        <h3 className="text-2xl font-bold mt-1">{summary.totalTransactions}</h3>
                        <div className="flex items-center mt-2 text-sm text-gray-600">
                          <Badge className="bg-green-100 text-green-800 mr-2">
                            {summary.completedTransactions}
                          </Badge>
                          completed
                        </div>
                      </div>
                      <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center">
                        <CreditCard className="h-5 w-5 text-purple-600" />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Average Amount */}
                <Card>
                  <CardContent className="pt-6">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="text-gray-600 text-sm">Average Amount</p>
                        <h3 className="text-2xl font-bold mt-1">
                          {formatCurrency(summary.averageAmount, summary.currency)}
                        </h3>
                        <div className="flex items-center mt-2 text-sm text-gray-600">
                          per transaction
                        </div>
                      </div>
                      <div className="w-10 h-10 rounded-full bg-yellow-100 flex items-center justify-center">
                        <FileText className="h-5 w-5 text-yellow-600" />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Success Rate */}
                <Card>
                  <CardContent className="pt-6">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="text-gray-600 text-sm">Success Rate</p>
                        <h3 className="text-2xl font-bold mt-1">
                          {summary.totalTransactions > 0 
                            ? Math.round((summary.completedTransactions / summary.totalTransactions) * 100) 
                            : 0}%
                        </h3>
                        <div className="flex items-center mt-2 gap-1">
                          <Badge className="bg-green-100 text-green-800">
                            <CheckCircle className="h-3 w-3 mr-1" />
                            {summary.completedTransactions}
                          </Badge>
                          <Badge className="bg-red-100 text-red-800">
                            <XCircle className="h-3 w-3 mr-1" />
                            {summary.failedTransactions}
                          </Badge>
                        </div>
                      </div>
                      <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center">
                        <CheckCircle className="h-5 w-5 text-green-600" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </>
            )}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
            <PaymentTrends />
            <PaymentMethodDistribution />
          </div>

          {/* Recent Transactions */}
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle className="text-lg font-semibold">Recent Transactions</CardTitle>
                  <CardDescription>Latest payment activities</CardDescription>
                </div>
                <Button 
                  size="sm" 
                  variant="outline" 
                  onClick={() => setActiveTab("all-payments")}
                >
                  View All
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="space-y-4">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Skeleton key={i} className="h-16 w-full" />
                  ))}
                </div>
              ) : recentTransactions.length > 0 ? (
                <div className="space-y-4">
                  {recentTransactions.map(payment => (
                    <div key={payment.id} className="flex justify-between items-center p-3 rounded-lg bg-gray-50 hover:bg-gray-100 transition-colors">
                      <div className="flex items-center">
                        <div className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center mr-3">
                          <Users className="h-5 w-5 text-gray-600" />
                        </div>
                        <div>
                          <p className="font-medium">{payment.user?.fullName || payment.user?.email}</p>
                          <p className="text-sm text-gray-500">{payment.package?.name}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-bold">{formatCurrency(payment.amount, payment.currency)}</p>
                        <div className="flex items-center justify-end gap-2">
                          <p className="text-sm text-gray-500">{formatDateOnly(payment.createdAt)}</p>
                          <Badge className={
                            payment.status === 'completed' ? 'bg-green-100 text-green-800' :
                            payment.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                            'bg-red-100 text-red-800'
                          }>
                            {payment.status}
                          </Badge>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  <p>No recent transactions found</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* All Payments Tab */}
        <TabsContent value="all-payments">
          <Card>
            <CardHeader>
              <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
                <div>
                  <CardTitle className="text-xl font-bold">Payment Transactions</CardTitle>
                  <CardDescription>Manage and track all payment transactions</CardDescription>
                </div>
                <div className="flex flex-col sm:flex-row gap-3">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 h-4 w-4" />
                    <Input 
                      type="text" 
                      placeholder="Search transactions..." 
                      className="pl-10 w-full md:w-[250px]"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                  <div className="flex items-center gap-2">
                    <Select value={statusFilter} onValueChange={setStatusFilter}>
                      <SelectTrigger className="w-full md:w-[130px]">
                        <div className="flex items-center gap-2">
                          <Filter className="h-4 w-4 text-gray-500" />
                          <SelectValue placeholder="Status" />
                        </div>
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Status</SelectItem>
                        <SelectItem value="completed">Completed</SelectItem>
                        <SelectItem value="pending">Pending</SelectItem>
                        <SelectItem value="failed">Failed</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button variant="outline" className="w-full md:w-[180px] justify-start">
                        <Calendar className="mr-2 h-4 w-4" />
                        {dateFilter ? format(dateFilter, "PPP") : "Filter by Date"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <CalendarComponent
                        mode="single"
                        selected={dateFilter}
                        onSelect={setDateFilter}
                        initialFocus
                      />
                      {dateFilter && (
                        <div className="p-3 border-t border-gray-100">
                          <Button variant="ghost" size="sm" onClick={() => setDateFilter(undefined)}>
                            Clear Date
                          </Button>
                        </div>
                      )}
                    </PopoverContent>
                  </Popover>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col-reverse sm:flex-row justify-between items-center mb-4 gap-4">
                <div className="flex items-center text-sm text-gray-500">
                  <span className="font-medium mr-1">{filteredPayments.length}</span> 
                  {filteredPayments.length === 1 ? "transaction" : "transactions"} found
                  {(statusFilter !== 'all' || dateFilter || searchQuery) && (
                    <Button variant="ghost" size="sm" onClick={clearFilters} className="ml-2">
                      Clear Filters
                    </Button>
                  )}
                </div>
                <div>
                  <Badge className="bg-green-100 text-green-800 mr-2">
                    {filteredPayments.filter(p => p.status === 'completed').length} completed
                  </Badge>
                  <Badge className="bg-yellow-100 text-yellow-800 mr-2">
                    {filteredPayments.filter(p => p.status === 'pending').length} pending
                  </Badge>
                  <Badge className="bg-red-100 text-red-800">
                    {filteredPayments.filter(p => p.status === 'failed').length} failed
                  </Badge>
                </div>
              </div>

              {loading ? (
                <div className="space-y-4">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Skeleton key={i} className="h-12 w-full" />
                  ))}
                </div>
              ) : (
                <div className="overflow-x-auto rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead 
                          className="cursor-pointer"
                          onClick={() => handleSort('id')}
                        >
                          <div className="flex items-center">
                            ID
                            {sortField === 'id' && (
                              <ArrowUpDown className="ml-1 h-3 w-3" />
                            )}
                          </div>
                        </TableHead>
                        <TableHead 
                          className="cursor-pointer"
                          onClick={() => handleSort('user')}
                        >
                          <div className="flex items-center">
                            User
                            {sortField === 'user' && (
                              <ArrowUpDown className="ml-1 h-3 w-3" />
                            )}
                          </div>
                        </TableHead>
                        <TableHead 
                          className="cursor-pointer"
                          onClick={() => handleSort('package')}
                        >
                          <div className="flex items-center">
                            Package
                            {sortField === 'package' && (
                              <ArrowUpDown className="ml-1 h-3 w-3" />
                            )}
                          </div>
                        </TableHead>
                        <TableHead 
                          className="cursor-pointer"
                          onClick={() => handleSort('amount')}
                        >
                          <div className="flex items-center">
                            Amount
                            {sortField === 'amount' && (
                              <ArrowUpDown className="ml-1 h-3 w-3" />
                            )}
                          </div>
                        </TableHead>
                        <TableHead 
                          className="cursor-pointer"
                          onClick={() => handleSort('method')}
                        >
                          <div className="flex items-center">
                            Method
                            {sortField === 'method' && (
                              <ArrowUpDown className="ml-1 h-3 w-3" />
                            )}
                          </div>
                        </TableHead>
                        <TableHead 
                          className="cursor-pointer"
                          onClick={() => handleSort('date')}
                        >
                          <div className="flex items-center">
                            Date
                            {sortField === 'date' && (
                              <ArrowUpDown className="ml-1 h-3 w-3" />
                            )}
                          </div>
                        </TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredPayments.length > 0 ? (
                        filteredPayments.map((payment) => (
                          <TableRow key={payment.id}>
                            <TableCell className="font-medium">{payment.id}</TableCell>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <div className="w-7 h-7 rounded-full bg-gray-100 flex items-center justify-center text-xs font-medium text-gray-600">
                                  {payment.user?.fullName ? payment.user.fullName.charAt(0).toUpperCase() : payment.user?.email.charAt(0).toUpperCase()}
                                </div>
                                <div className="flex flex-col">
                                  <span>{payment.user?.fullName || 'N/A'}</span>
                                  <span className="text-xs text-gray-500">{payment.user?.email}</span>
                                </div>
                              </div>
                            </TableCell>
                            <TableCell>{payment.package?.name}</TableCell>
                            <TableCell>{formatCurrency(payment.amount, payment.currency)}</TableCell>
                            <TableCell>{payment.paymentMethod}</TableCell>
                            <TableCell>{formatDate(payment.createdAt)}</TableCell>
                            <TableCell>
                              <Badge 
                                className={
                                  payment.status === 'completed' ? 'bg-green-100 text-green-800' :
                                  payment.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                                  'bg-red-100 text-red-800'
                                }
                              >
                                {payment.status === 'completed' ? (
                                  <div className="flex items-center">
                                    <CheckCircle className="h-3 w-3 mr-1" />
                                    {payment.status}
                                  </div>
                                ) : payment.status === 'pending' ? (
                                  <div className="flex items-center">
                                    <Clock className="h-3 w-3 mr-1" />
                                    {payment.status}
                                  </div>
                                ) : (
                                  <div className="flex items-center">
                                    <XCircle className="h-3 w-3 mr-1" />
                                    {payment.status}
                                  </div>
                                )}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-right">
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="icon">
                                    <MoreHorizontal className="h-4 w-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuLabel>Actions</DropdownMenuLabel>
                                  <DropdownMenuItem onClick={() => handleViewPayment(payment)}>
                                    <Eye className="h-4 w-4 mr-2" />
                                    View Details
                                  </DropdownMenuItem>
                                  <DropdownMenuSeparator />
                                  <DropdownMenuItem onClick={() => { /* Add export functionality */ }}>
                                    <Download className="h-4 w-4 mr-2" />
                                    Export Receipt
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </TableCell>
                          </TableRow>
                        ))
                      ) : (
                        <TableRow>
                          <TableCell colSpan={8} className="h-24 text-center">
                            No payment transactions found.
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
            <CardFooter className="flex justify-between">
              <div className="text-xs text-gray-500">
                Last updated: {new Date().toLocaleString()}
              </div>
              <Button variant="ghost" size="sm" onClick={() => window.location.reload()}>
                <RefreshCw className="h-4 w-4 mr-2" />
                Refresh
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        {/* Reports Tab */}
        <TabsContent value="reports">
          <Card>
            <CardHeader>
              <CardTitle className="text-xl font-bold">Payment Reports</CardTitle>
              <CardDescription>Generate and view payment reports</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
                {/* Monthly Revenue */}
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base font-medium">Monthly Revenue</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[200px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          data={revenueData}
                          margin={{ top: 5, right: 5, left: 5, bottom: 5 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="name" />
                          <YAxis />
                          <Tooltip formatter={(value) => [`${value.toLocaleString()} ${summary.currency}`, 'Revenue']} />
                          <Bar dataKey="revenue" fill="#0078D7" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
                
                {/* Payment Method Stats */}
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base font-medium">Payment Methods</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[200px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={paymentMethodData}
                            cx="50%"
                            cy="50%"
                            outerRadius={80}
                            fill="#8884d8"
                            dataKey="value"
                            label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                          >
                            {paymentMethodData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={entry.color} />
                            ))}
                          </Pie>
                          <Tooltip />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
                
                {/* Transaction Stats */}
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base font-medium">Transaction Status</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm text-gray-600">Completed</span>
                          <span className="text-sm font-medium">
                            {Math.round((summary.completedTransactions / (summary.totalTransactions || 1)) * 100)}%
                          </span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-green-500 h-2 rounded-full" 
                            style={{ width: `${Math.round((summary.completedTransactions / (summary.totalTransactions || 1)) * 100)}%` }}
                          ></div>
                        </div>
                      </div>
                      
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm text-gray-600">Pending</span>
                          <span className="text-sm font-medium">
                            {Math.round((summary.pendingTransactions / (summary.totalTransactions || 1)) * 100)}%
                          </span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-yellow-500 h-2 rounded-full" 
                            style={{ width: `${Math.round((summary.pendingTransactions / (summary.totalTransactions || 1)) * 100)}%` }}
                          ></div>
                        </div>
                      </div>
                      
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm text-gray-600">Failed</span>
                          <span className="text-sm font-medium">
                            {Math.round((summary.failedTransactions / (summary.totalTransactions || 1)) * 100)}%
                          </span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-red-500 h-2 rounded-full" 
                            style={{ width: `${Math.round((summary.failedTransactions / (summary.totalTransactions || 1)) * 100)}%` }}
                          ></div>
                        </div>
                      </div>
                      
                      <div className="text-center pt-4">
                        <p className="text-sm text-gray-600">Total Transactions: {summary.totalTransactions}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              <Separator className="my-8" />
              
              <div className="space-y-6">
                <h3 className="text-lg font-medium">Generate Custom Reports</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <Card className="cursor-pointer hover:bg-gray-50 transition-colors">
                    <CardContent className="pt-6">
                      <div className="text-center">
                        <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center mx-auto mb-4">
                          <FileText className="h-6 w-6 text-blue-600" />
                        </div>
                        <h3 className="font-medium">Monthly Revenue Report</h3>
                        <p className="text-sm text-gray-500 mt-2">Generate a detailed report of monthly revenue and transaction counts</p>
                        <Button className="mt-4 w-full" variant="outline">
                          Generate Report
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card className="cursor-pointer hover:bg-gray-50 transition-colors">
                    <CardContent className="pt-6">
                      <div className="text-center">
                        <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-4">
                          <Users className="h-6 w-6 text-green-600" />
                        </div>
                        <h3 className="font-medium">User Payment Analysis</h3>
                        <p className="text-sm text-gray-500 mt-2">Analyze payment patterns and behavior by user segments</p>
                        <Button className="mt-4 w-full" variant="outline">
                          Generate Report
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card className="cursor-pointer hover:bg-gray-50 transition-colors">
                    <CardContent className="pt-6">
                      <div className="text-center">
                        <div className="w-12 h-12 rounded-full bg-purple-100 flex items-center justify-center mx-auto mb-4">
                          <CreditCard className="h-6 w-6 text-purple-600" />
                        </div>
                        <h3 className="font-medium">Payment Method Report</h3>
                        <p className="text-sm text-gray-500 mt-2">Detailed breakdown of transactions by payment method</p>
                        <Button className="mt-4 w-full" variant="outline">
                          Generate Report
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Payment Details Dialog */}
      <Dialog open={isDetailsOpen} onOpenChange={setIsDetailsOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Payment Transaction Details</DialogTitle>
            <DialogDescription>
              Detailed information about this payment transaction
            </DialogDescription>
          </DialogHeader>
          
          {selectedPayment && (
            <div className="space-y-6 py-4">
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="text-lg font-medium">Transaction #{selectedPayment.id}</h3>
                  <p className="text-sm text-gray-500">{formatDate(selectedPayment.createdAt)}</p>
                </div>
                <Badge
                  className={
                    selectedPayment.status === 'completed' ? 'bg-green-100 text-green-800 text-lg' :
                    selectedPayment.status === 'pending' ? 'bg-yellow-100 text-yellow-800 text-lg' :
                    'bg-red-100 text-red-800 text-lg'
                  }
                >
                  {selectedPayment.status === 'completed' ? (
                    <div className="flex items-center">
                      <CheckCircle className="h-4 w-4 mr-1" />
                      {selectedPayment.status}
                    </div>
                  ) : selectedPayment.status === 'pending' ? (
                    <div className="flex items-center">
                      <Clock className="h-4 w-4 mr-1" />
                      {selectedPayment.status}
                    </div>
                  ) : (
                    <div className="flex items-center">
                      <XCircle className="h-4 w-4 mr-1" />
                      {selectedPayment.status}
                    </div>
                  )}
                </Badge>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <h4 className="text-sm font-medium text-gray-500 mb-3">Payment Information</h4>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Amount:</span>
                      <span className="font-medium">{formatCurrency(selectedPayment.amount, selectedPayment.currency)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Payment Method:</span>
                      <span className="font-medium">{selectedPayment.paymentMethod}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Transaction ID:</span>
                      <span className="font-medium">{selectedPayment.transactionId}</span>
                    </div>
                    {selectedPayment.transactionRef && (
                      <div className="flex justify-between">
                        <span className="text-gray-600">Reference:</span>
                        <span className="font-medium">{selectedPayment.transactionRef}</span>
                      </div>
                    )}
                    {selectedPayment.processingFee !== undefined && (
                      <div className="flex justify-between">
                        <span className="text-gray-600">Processing Fee:</span>
                        <span className="font-medium">{formatCurrency(selectedPayment.processingFee, selectedPayment.currency)}</span>
                      </div>
                    )}
                    <div className="flex justify-between">
                      <span className="text-gray-600">Date:</span>
                      <span className="font-medium">{formatDate(selectedPayment.createdAt)}</span>
                    </div>
                  </div>
                </div>
                
                <div>
                  <h4 className="text-sm font-medium text-gray-500 mb-3">User & Package Information</h4>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-600">User ID:</span>
                      <span className="font-medium">{selectedPayment.userId}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">User Name:</span>
                      <span className="font-medium">{selectedPayment.user?.fullName || 'N/A'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">User Email:</span>
                      <span className="font-medium">{selectedPayment.user?.email}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Package ID:</span>
                      <span className="font-medium">{selectedPayment.packageId}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Package Name:</span>
                      <span className="font-medium">{selectedPayment.package?.name}</span>
                    </div>
                  </div>
                </div>
              </div>
              
              {selectedPayment.notes && (
                <div>
                  <h4 className="text-sm font-medium text-gray-500 mb-2">Additional Notes</h4>
                  <p className="text-gray-600 p-3 bg-gray-50 rounded-md">{selectedPayment.notes}</p>
                </div>
              )}
            </div>
          )}
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDetailsOpen(false)}>Close</Button>
            <Button
              onClick={() => {
                toast({
                  title: "Receipt Generated",
                  description: "The receipt has been generated and is ready to download.",
                });
              }}
              className="bg-[#0078D7]"
            >
              <FileText className="h-4 w-4 mr-2" />
              Generate Receipt
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default PaymentManagement;