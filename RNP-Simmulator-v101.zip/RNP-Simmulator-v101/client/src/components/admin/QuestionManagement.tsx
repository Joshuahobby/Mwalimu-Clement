import { useState, useEffect, useRef } from "react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle, 
  CardFooter 
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { 
  Alert,
  AlertTitle,
  AlertDescription
} from "@/components/ui/alert";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogClose,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Checkbox } from "@/components/ui/checkbox";
import { Switch } from "@/components/ui/switch";
import { 
  Edit, 
  Trash2, 
  Plus, 
  Check, 
  X, 
  Search, 
  RefreshCw, 
  Filter,
  Eye,
  Copy,
  Download,
  Upload,
  Image as ImageIcon,
  FileQuestion,
  MoreHorizontal,
  CheckCircle2,
  ListFilter,
  BarChart,
  ArrowDownUp
} from "lucide-react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import { ScrollArea } from "@/components/ui/scroll-area";

// Form validation schemas
const answerSchema = z.object({
  id: z.number().optional(),
  text: z.string().min(1, "Answer text is required"),
  isCorrect: z.boolean().default(false),
});

const questionSchema = z.object({
  text: z.string().min(3, "Question text is required"),
  category: z.string().min(1, "Category is required"),
  imageUrl: z.string().optional(),
  answers: z.array(answerSchema)
    .min(2, "At least 2 answers are required")
    .max(5, "Maximum 5 answers allowed")
    .refine(
      (answers) => answers.some(answer => answer.isCorrect),
      {
        message: "At least one answer must be marked as correct",
      }
    ),
});

interface Answer {
  id: number;
  text: string;
  isCorrect: boolean;
}

interface Question {
  id: number;
  text: string;
  category: string;
  imageUrl?: string;
  answers: Answer[];
  createdAt?: string;
  updatedAt?: string;
}

interface Category {
  id: string;
  name: string;
  count: number;
}

const initialAnswers: Omit<Answer, "id">[] = [
  { text: "", isCorrect: true },
  { text: "", isCorrect: false },
  { text: "", isCorrect: false },
  { text: "", isCorrect: false },
];

// Stats for the dashboard
interface QuestionStats {
  totalQuestions: number;
  categoryCounts: { name: string; count: number }[];
  answersPerQuestion: number;
  imageCount: number;
}

// Mock categories (in a real app, these would come from the API)
const availableCategories: Category[] = [
  { id: "road-signs", name: "Road Signs", count: 25 },
  { id: "traffic-laws", name: "Traffic Laws", count: 32 },
  { id: "vehicle-operation", name: "Vehicle Operation", count: 18 },
  { id: "safety-procedures", name: "Safety Procedures", count: 15 },
  { id: "emergency-response", name: "Emergency Response", count: 10 },
];

const QuestionManagement = () => {
  const [questions, setQuestions] = useState<Question[]>([]);
  const [filteredQuestions, setFilteredQuestions] = useState<Question[]>([]);
  const [loading, setLoading] = useState(true);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [selectedQuestion, setSelectedQuestion] = useState<Question | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [hasImageFilter, setHasImageFilter] = useState<boolean | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [activeTab, setActiveTab] = useState("all-questions");
  const [stats, setStats] = useState<QuestionStats>({
    totalQuestions: 0,
    categoryCounts: [],
    answersPerQuestion: 0,
    imageCount: 0,
  });
  const [bulkSelected, setBulkSelected] = useState<number[]>([]);
  const [view, setView] = useState<"cards" | "table">("cards");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  // Initialize form for creating/editing questions
  const form = useForm<z.infer<typeof questionSchema>>({
    resolver: zodResolver(questionSchema),
    defaultValues: {
      text: "",
      category: "",
      imageUrl: "",
      answers: initialAnswers,
    },
  });

  useEffect(() => {
    const fetchQuestions = async () => {
      try {
        setLoading(true);
        const response = await fetch('/api/admin/questions', {
          credentials: 'include',
        });
        
        if (!response.ok) {
          throw new Error('Failed to fetch questions');
        }
        
        const data = await response.json();
        setQuestions(data.questions);
        calculateStats(data.questions);
      } catch (error) {
        console.error('Error fetching questions:', error);
        toast({
          title: 'Error',
          description: 'Failed to load questions.',
          variant: 'destructive',
        });
      } finally {
        setLoading(false);
      }
    };

    fetchQuestions();
  }, [toast]);

  // Calculate question statistics
  const calculateStats = (questionData: Question[]) => {
    if (!questionData.length) return;

    // Count questions by category
    const categories: { [key: string]: number } = {};
    questionData.forEach(q => {
      if (categories[q.category]) {
        categories[q.category]++;
      } else {
        categories[q.category] = 1;
      }
    });

    const categoryCounts = Object.entries(categories).map(([name, count]) => ({ name, count }));
    
    // Count questions with images
    const imageCount = questionData.filter(q => q.imageUrl).length;
    
    // Calculate average answers per question
    const totalAnswers = questionData.reduce((sum, q) => sum + q.answers.length, 0);
    const answersPerQuestion = totalAnswers / questionData.length;

    setStats({
      totalQuestions: questionData.length,
      categoryCounts,
      answersPerQuestion,
      imageCount,
    });
  };

  // Apply filters
  useEffect(() => {
    let filtered = [...questions];
    
    // Apply search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(question => 
        question.text.toLowerCase().includes(query) || 
        question.category.toLowerCase().includes(query) ||
        question.answers.some(a => a.text.toLowerCase().includes(query))
      );
    }
    
    // Apply category filter
    if (categoryFilter !== 'all') {
      filtered = filtered.filter(question => question.category === categoryFilter);
    }
    
    // Apply image filter
    if (hasImageFilter !== null) {
      filtered = filtered.filter(question => 
        hasImageFilter ? !!question.imageUrl : !question.imageUrl
      );
    }
    
    setFilteredQuestions(filtered);
  }, [questions, searchQuery, categoryFilter, hasImageFilter]);

  // Reset form when dialog is opened
  const resetForm = () => {
    form.reset({
      text: "",
      category: "",
      imageUrl: "",
      answers: initialAnswers,
    });
  };

  // Prepare form for editing a question
  const prepareEditForm = (question: Question) => {
    form.reset({
      text: question.text,
      category: question.category,
      imageUrl: question.imageUrl || "",
      answers: question.answers,
    });
  };

  // Handle creating a new question
  const handleCreateQuestion = async (data: z.infer<typeof questionSchema>) => {
    try {
      setIsProcessing(true);
      
      // In a real implementation, we would make an API call
      // For now, we'll simulate a successful response
      
      const newQuestion: Question = {
        id: questions.length + 1,
        text: data.text,
        category: data.category,
        imageUrl: data.imageUrl,
        answers: data.answers.map((answer, index) => ({
          ...answer,
          id: index + 1,
        })),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      
      // Add the new question to state
      const updatedQuestions = [...questions, newQuestion];
      setQuestions(updatedQuestions);
      calculateStats(updatedQuestions);
      
      toast({
        title: "Success",
        description: "Question created successfully",
      });
      
      setIsCreateDialogOpen(false);
    } catch (error) {
      console.error("Error creating question:", error);
      toast({
        title: "Error",
        description: "Failed to create question",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  // Handle updating a question
  const handleUpdateQuestion = async (data: z.infer<typeof questionSchema>) => {
    if (!selectedQuestion) return;
    
    try {
      setIsProcessing(true);
      
      // In a real implementation, we would make an API call
      // For now, we'll simulate a successful response
      
      const updatedQuestion: Question = {
        ...selectedQuestion,
        text: data.text,
        category: data.category,
        imageUrl: data.imageUrl,
        answers: data.answers.map((answer, index) => ({
          ...answer,
          id: answer.id || index + 1, // Preserve existing IDs if available
        })),
        updatedAt: new Date().toISOString(),
      };
      
      // Update the question in state
      const updatedQuestions = questions.map(q => 
        q.id === selectedQuestion.id ? updatedQuestion : q
      );
      
      setQuestions(updatedQuestions);
      calculateStats(updatedQuestions);
      
      toast({
        title: "Success",
        description: "Question updated successfully",
      });
      
      setIsEditDialogOpen(false);
    } catch (error) {
      console.error("Error updating question:", error);
      toast({
        title: "Error",
        description: "Failed to update question",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  // Handle deleting a question
  const handleDeleteQuestion = async () => {
    if (!selectedQuestion) return;
    
    try {
      setIsProcessing(true);
      
      // In a real implementation, we would make an API call
      // For now, we'll simulate a successful response
      
      // Remove the question from state
      const updatedQuestions = questions.filter(q => q.id !== selectedQuestion.id);
      setQuestions(updatedQuestions);
      calculateStats(updatedQuestions);
      
      toast({
        title: "Success",
        description: "Question deleted successfully",
      });
      
      setIsDeleteDialogOpen(false);
    } catch (error) {
      console.error("Error deleting question:", error);
      toast({
        title: "Error",
        description: "Failed to delete question",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  // Handle bulk deletion
  const handleBulkDelete = async () => {
    if (!bulkSelected.length) return;
    
    try {
      setIsProcessing(true);
      
      // In a real implementation, we would make an API call
      // For now, we'll simulate a successful response
      
      // Remove the selected questions from state
      const updatedQuestions = questions.filter(q => !bulkSelected.includes(q.id));
      setQuestions(updatedQuestions);
      calculateStats(updatedQuestions);
      
      toast({
        title: "Success",
        description: `${bulkSelected.length} questions deleted successfully`,
      });
      
      // Clear selection
      setBulkSelected([]);
    } catch (error) {
      console.error("Error bulk deleting questions:", error);
      toast({
        title: "Error",
        description: "Failed to delete questions",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  // Handle bulk category update
  const handleBulkCategoryUpdate = async (category: string) => {
    if (!bulkSelected.length) return;
    
    try {
      setIsProcessing(true);
      
      // In a real implementation, we would make an API call
      // For now, we'll simulate a successful response
      
      // Update the category for selected questions
      const updatedQuestions = questions.map(q => 
        bulkSelected.includes(q.id) ? { ...q, category, updatedAt: new Date().toISOString() } : q
      );
      
      setQuestions(updatedQuestions);
      calculateStats(updatedQuestions);
      
      toast({
        title: "Success",
        description: `Category updated for ${bulkSelected.length} questions`,
      });
      
      // Clear selection
      setBulkSelected([]);
    } catch (error) {
      console.error("Error updating question categories:", error);
      toast({
        title: "Error",
        description: "Failed to update question categories",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  // Toggle selection of a question for bulk operations
  const toggleQuestionSelection = (questionId: number) => {
    setBulkSelected(prev => 
      prev.includes(questionId)
        ? prev.filter(id => id !== questionId)
        : [...prev, questionId]
    );
  };

  // Toggle selection of all questions
  const toggleSelectAll = () => {
    if (bulkSelected.length === filteredQuestions.length) {
      setBulkSelected([]);
    } else {
      setBulkSelected(filteredQuestions.map(q => q.id));
    }
  };

  // Handle file import
  const handleFileImport = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const content = e.target?.result as string;
        const data = JSON.parse(content);
        
        if (Array.isArray(data) && data.length > 0) {
          // Validate the imported data
          const importedQuestions = data.filter(q => 
            q.text && q.category && Array.isArray(q.answers) && q.answers.length >= 2
          );
          
          if (importedQuestions.length === 0) {
            throw new Error("No valid questions found in the imported file");
          }
          
          // Add IDs to the imported questions
          const nextId = Math.max(...questions.map(q => q.id), 0) + 1;
          const newQuestions = importedQuestions.map((q, index) => ({
            ...q,
            id: nextId + index,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            answers: q.answers.map((a: any, aIndex: number) => ({
              ...a,
              id: aIndex + 1,
            })),
          }));
          
          // Add the imported questions to state
          const updatedQuestions = [...questions, ...newQuestions];
          setQuestions(updatedQuestions);
          calculateStats(updatedQuestions);
          
          toast({
            title: "Success",
            description: `Imported ${newQuestions.length} questions successfully`,
          });
        } else {
          throw new Error("Invalid file format");
        }
      } catch (error) {
        console.error("Error importing questions:", error);
        toast({
          title: "Error",
          description: error instanceof Error ? error.message : "Failed to import questions",
          variant: "destructive",
        });
      } finally {
        // Reset the file input
        if (fileInputRef.current) {
          fileInputRef.current.value = "";
        }
      }
    };
    
    reader.readAsText(file);
  };

  // Handle file export
  const handleFileExport = () => {
    try {
      const dataToExport = questions.map(({ id, text, category, imageUrl, answers }) => ({
        text,
        category,
        imageUrl,
        answers: answers.map(({ id, text, isCorrect }) => ({ text, isCorrect })),
      }));
      
      const jsonString = JSON.stringify(dataToExport, null, 2);
      const blob = new Blob([jsonString], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      
      const a = document.createElement("a");
      a.href = url;
      a.download = `question-bank-export-${new Date().toISOString().split("T")[0]}.json`;
      document.body.appendChild(a);
      a.click();
      
      // Clean up
      setTimeout(() => {
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      }, 0);
      
      toast({
        title: "Success",
        description: `Exported ${questions.length} questions successfully`,
      });
    } catch (error) {
      console.error("Error exporting questions:", error);
      toast({
        title: "Error",
        description: "Failed to export questions",
        variant: "destructive",
      });
    }
  };

  // Reset filters
  const resetFilters = () => {
    setSearchQuery("");
    setCategoryFilter("all");
    setHasImageFilter(null);
  };

  // Get all unique categories from the questions
  const uniqueCategories = [...new Set(questions.map(q => q.category))];

  // Table view for questions
  const QuestionTable = () => (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-12">
              <Checkbox 
                checked={bulkSelected.length === filteredQuestions.length && filteredQuestions.length > 0}
                onCheckedChange={toggleSelectAll}
                aria-label="Select all questions"
              />
            </TableHead>
            <TableHead className="w-14">ID</TableHead>
            <TableHead>Question</TableHead>
            <TableHead>Category</TableHead>
            <TableHead className="text-center">Image</TableHead>
            <TableHead className="text-center">Answers</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {filteredQuestions.length > 0 ? (
            filteredQuestions.map((question) => (
              <TableRow key={question.id}>
                <TableCell>
                  <Checkbox 
                    checked={bulkSelected.includes(question.id)}
                    onCheckedChange={() => toggleQuestionSelection(question.id)}
                    aria-label={`Select question ${question.id}`}
                  />
                </TableCell>
                <TableCell className="font-medium">{question.id}</TableCell>
                <TableCell className="max-w-sm truncate">
                  {question.text.length > 70 
                    ? `${question.text.substring(0, 70)}...` 
                    : question.text}
                </TableCell>
                <TableCell>
                  <Badge className="bg-[#0078D7]">{question.category}</Badge>
                </TableCell>
                <TableCell className="text-center">
                  {question.imageUrl ? (
                    <div className="flex justify-center">
                      <ImageIcon className="h-5 w-5 text-green-500" />
                    </div>
                  ) : (
                    <div className="flex justify-center">
                      <X className="h-5 w-5 text-gray-400" />
                    </div>
                  )}
                </TableCell>
                <TableCell className="text-center">
                  <Badge variant="outline">{question.answers.length}</Badge>
                </TableCell>
                <TableCell className="text-right">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuLabel>Actions</DropdownMenuLabel>
                      <DropdownMenuItem onClick={() => {
                        setSelectedQuestion(question);
                        prepareEditForm(question);
                        setIsEditDialogOpen(true);
                      }}>
                        <Edit className="h-4 w-4 mr-2" />
                        Edit Question
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => {
                        const newQuestion = { ...question };
                        delete newQuestion.id;
                        delete newQuestion.createdAt;
                        delete newQuestion.updatedAt;
                        form.reset({
                          text: `${question.text} (Copy)`,
                          category: question.category,
                          imageUrl: question.imageUrl,
                          answers: question.answers.map(a => ({ 
                            text: a.text, 
                            isCorrect: a.isCorrect 
                          })),
                        });
                        setIsCreateDialogOpen(true);
                      }}>
                        <Copy className="h-4 w-4 mr-2" />
                        Duplicate
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem 
                        onClick={() => {
                          setSelectedQuestion(question);
                          setIsDeleteDialogOpen(true);
                        }}
                        className="text-red-600"
                      >
                        <Trash2 className="h-4 w-4 mr-2" />
                        Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))
          ) : (
            <TableRow>
              <TableCell colSpan={7} className="h-24 text-center">
                No questions found.
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
    </div>
  );

  return (
    <div className="space-y-6">
      <Tabs defaultValue="all-questions" value={activeTab} onValueChange={setActiveTab} className="w-full">
        <div className="flex justify-between items-center mb-4">
          <TabsList>
            <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
            <TabsTrigger value="all-questions">All Questions</TabsTrigger>
            <TabsTrigger value="categories">Categories</TabsTrigger>
          </TabsList>
          <div className="flex items-center gap-2">
            <input 
              type="file" 
              ref={fileInputRef} 
              onChange={handleFileImport} 
              accept=".json" 
              className="hidden" 
            />
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm">
                  <ArrowDownUp className="h-4 w-4 mr-2" />
                  Import/Export
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem onClick={() => fileInputRef.current?.click()}>
                  <Upload className="h-4 w-4 mr-2" />
                  Import Questions
                </DropdownMenuItem>
                <DropdownMenuItem onClick={handleFileExport}>
                  <Download className="h-4 w-4 mr-2" />
                  Export Questions
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <Button 
              onClick={() => {
                resetForm();
                setIsCreateDialogOpen(true);
              }}
              size="sm"
              className="bg-[#0078D7]"
            >
              <Plus className="h-4 w-4 mr-2" />
              Add Question
            </Button>
          </div>
        </div>

        {/* Dashboard Tab */}
        <TabsContent value="dashboard">
          <Card>
            <CardHeader>
              <CardTitle>Question Bank Overview</CardTitle>
              <CardDescription>Statistics and insights about your question bank</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                {/* Total Questions */}
                <Card>
                  <CardContent className="pt-6">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="text-gray-600 text-sm">Total Questions</p>
                        <h3 className="text-2xl font-bold mt-1">{stats.totalQuestions}</h3>
                      </div>
                      <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                        <FileQuestion className="h-5 w-5 text-blue-600" />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Categories */}
                <Card>
                  <CardContent className="pt-6">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="text-gray-600 text-sm">Categories</p>
                        <h3 className="text-2xl font-bold mt-1">{stats.categoryCounts.length}</h3>
                      </div>
                      <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center">
                        <ListFilter className="h-5 w-5 text-purple-600" />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Images */}
                <Card>
                  <CardContent className="pt-6">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="text-gray-600 text-sm">Questions with Images</p>
                        <h3 className="text-2xl font-bold mt-1">{stats.imageCount}</h3>
                        <p className="text-xs text-gray-500 mt-1">
                          {stats.totalQuestions > 0 
                            ? `(${Math.round((stats.imageCount / stats.totalQuestions) * 100)}%)` 
                            : '(0%)'}
                        </p>
                      </div>
                      <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center">
                        <ImageIcon className="h-5 w-5 text-green-600" />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Avg Answers */}
                <Card>
                  <CardContent className="pt-6">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="text-gray-600 text-sm">Avg. Answers per Question</p>
                        <h3 className="text-2xl font-bold mt-1">{stats.answersPerQuestion.toFixed(1)}</h3>
                      </div>
                      <div className="w-10 h-10 rounded-full bg-yellow-100 flex items-center justify-center">
                        <BarChart className="h-5 w-5 text-yellow-600" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Category distribution */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Categories Distribution</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {stats.categoryCounts.length > 0 ? (
                        stats.categoryCounts
                          .sort((a, b) => b.count - a.count)
                          .map(category => (
                            <div key={category.name}>
                              <div className="flex justify-between mb-1">
                                <span className="text-sm font-medium">
                                  {category.name}
                                </span>
                                <span className="text-sm text-gray-500">
                                  {category.count} questions
                                </span>
                              </div>
                              <Progress 
                                value={(category.count / stats.totalQuestions) * 100}
                                className="h-2"
                              />
                            </div>
                          ))
                      ) : (
                        <div className="text-center py-6 text-gray-500">
                          <p>No categories data available</p>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Recent Updates</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {questions.length > 0 ? (
                        [...questions]
                          .sort((a, b) => new Date(b.updatedAt || "").getTime() - new Date(a.updatedAt || "").getTime())
                          .slice(0, 5)
                          .map(question => (
                            <div key={question.id} className="flex items-start gap-3 p-3 rounded-lg bg-gray-50">
                              <div className="w-8 h-8 rounded-full bg-[#0078D7] flex items-center justify-center text-white font-bold">
                                {question.id}
                              </div>
                              <div className="flex-1 min-w-0">
                                <p className="text-sm font-medium truncate">{question.text}</p>
                                <div className="flex items-center mt-1">
                                  <Badge className="bg-[#0078D7] text-xs mr-2">{question.category}</Badge>
                                  <p className="text-xs text-gray-500">
                                    Updated: {new Date(question.updatedAt || "").toLocaleDateString()}
                                  </p>
                                </div>
                              </div>
                              <Button 
                                variant="ghost" 
                                size="icon"
                                onClick={() => {
                                  setSelectedQuestion(question);
                                  prepareEditForm(question);
                                  setIsEditDialogOpen(true);
                                }}
                              >
                                <Edit className="h-4 w-4" />
                              </Button>
                            </div>
                          ))
                      ) : (
                        <div className="text-center py-6 text-gray-500">
                          <p>No recent updates</p>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Quick Actions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    <Button
                      onClick={() => {
                        resetForm();
                        setIsCreateDialogOpen(true);
                      }}
                      variant="outline"
                      className="h-auto py-4 flex flex-col items-center justify-center gap-2"
                    >
                      <Plus className="h-6 w-6" />
                      <span>Add Question</span>
                    </Button>
                    <Button
                      onClick={() => fileInputRef.current?.click()}
                      variant="outline"
                      className="h-auto py-4 flex flex-col items-center justify-center gap-2"
                    >
                      <Upload className="h-6 w-6" />
                      <span>Import Questions</span>
                    </Button>
                    <Button
                      onClick={handleFileExport}
                      variant="outline"
                      className="h-auto py-4 flex flex-col items-center justify-center gap-2"
                    >
                      <Download className="h-6 w-6" />
                      <span>Export Questions</span>
                    </Button>
                    <Button
                      onClick={() => setActiveTab("categories")}
                      variant="outline"
                      className="h-auto py-4 flex flex-col items-center justify-center gap-2"
                    >
                      <ListFilter className="h-6 w-6" />
                      <span>Manage Categories</span>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </CardContent>
          </Card>
        </TabsContent>

        {/* All Questions Tab */}
        <TabsContent value="all-questions">
          <Card>
            <CardHeader>
              <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
                <div>
                  <CardTitle>Question Management</CardTitle>
                  <CardDescription>Manage and organize exam questions</CardDescription>
                </div>
                <div className="flex flex-col sm:flex-row gap-3">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 h-4 w-4" />
                    <Input 
                      type="text" 
                      placeholder="Search questions..." 
                      className="pl-10 w-full md:w-[250px]"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                  <div className="flex items-center gap-2">
                    <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                      <SelectTrigger className="w-full md:w-[150px]">
                        <div className="flex items-center gap-2">
                          <Filter className="h-4 w-4 text-gray-500" />
                          <SelectValue placeholder="Category" />
                        </div>
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Categories</SelectItem>
                        {uniqueCategories.map(category => (
                          <SelectItem key={category} value={category}>
                            {category}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Select 
                      value={hasImageFilter === null ? "all" : hasImageFilter ? "with-image" : "no-image"}
                      onValueChange={(value) => {
                        if (value === "all") setHasImageFilter(null);
                        else if (value === "with-image") setHasImageFilter(true);
                        else setHasImageFilter(false);
                      }}
                    >
                      <SelectTrigger className="w-full md:w-[130px]">
                        <div className="flex items-center gap-2">
                          <ImageIcon className="h-4 w-4 text-gray-500" />
                          <SelectValue placeholder="Images" />
                        </div>
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Questions</SelectItem>
                        <SelectItem value="with-image">With Images</SelectItem>
                        <SelectItem value="no-image">No Images</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col-reverse sm:flex-row justify-between items-center mb-4 gap-4">
                <div className="flex items-center text-sm text-gray-500">
                  <span className="font-medium mr-1">{filteredQuestions.length}</span> 
                  {filteredQuestions.length === 1 ? "question" : "questions"} found
                  {(searchQuery || categoryFilter !== 'all' || hasImageFilter !== null) && (
                    <Button variant="ghost" size="sm" onClick={resetFilters} className="ml-2">
                      Clear Filters
                    </Button>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  {/* View toggle */}
                  <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-md">
                    <Button 
                      variant={view === "cards" ? "default" : "ghost"} 
                      size="sm" 
                      onClick={() => setView("cards")}
                      className={view === "cards" ? "bg-[#0078D7]" : ""}
                    >
                      Cards
                    </Button>
                    <Button 
                      variant={view === "table" ? "default" : "ghost"} 
                      size="sm" 
                      onClick={() => setView("table")}
                      className={view === "table" ? "bg-[#0078D7]" : ""}
                    >
                      Table
                    </Button>
                  </div>
                  
                  {/* Bulk actions dropdown */}
                  {bulkSelected.length > 0 && (
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="outline" size="sm">
                          Bulk Actions ({bulkSelected.length})
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent>
                        <DropdownMenuLabel>Update {bulkSelected.length} questions</DropdownMenuLabel>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem onClick={() => setBulkSelected([])}>
                          Unselect All
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem>
                          <span className="font-medium">Change Category</span>
                        </DropdownMenuItem>
                        {uniqueCategories.map(category => (
                          <DropdownMenuItem 
                            key={category}
                            onClick={() => handleBulkCategoryUpdate(category)}
                            className="pl-6"
                          >
                            {category}
                          </DropdownMenuItem>
                        ))}
                        <DropdownMenuSeparator />
                        <DropdownMenuItem onClick={handleBulkDelete} className="text-red-600">
                          <Trash2 className="h-4 w-4 mr-2" />
                          Delete Selected
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  )}
                </div>
              </div>

              {loading ? (
                <div className="space-y-4">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Skeleton key={i} className="h-24 w-full" />
                  ))}
                </div>
              ) : (
                <>
                  {/* Card View */}
                  {view === "cards" && (
                    <div className="space-y-4">
                      {filteredQuestions.length > 0 ? (
                        filteredQuestions.map((question) => (
                          <Card key={question.id} className="overflow-hidden">
                            <CardContent className="p-0">
                              <div className="p-4 bg-slate-50 border-b">
                                <div className="flex justify-between items-start">
                                  <div className="flex-1">
                                    <div className="flex items-center gap-2 mb-2">
                                      <Checkbox 
                                        checked={bulkSelected.includes(question.id)}
                                        onCheckedChange={() => toggleQuestionSelection(question.id)}
                                        aria-label={`Select question ${question.id}`}
                                      />
                                      <Badge variant="outline" className="text-xs">ID: {question.id}</Badge>
                                      <Badge className="bg-[#0078D7] text-xs">{question.category}</Badge>
                                    </div>
                                    <p className="font-medium">{question.text}</p>
                                  </div>
                                  <div className="flex items-center space-x-2 ml-2">
                                    <Button 
                                      variant="ghost" 
                                      size="icon"
                                      onClick={() => {
                                        setSelectedQuestion(question);
                                        prepareEditForm(question);
                                        setIsEditDialogOpen(true);
                                      }}
                                    >
                                      <Edit className="h-4 w-4" />
                                    </Button>
                                    <Button 
                                      variant="ghost" 
                                      size="icon"
                                      onClick={() => {
                                        setSelectedQuestion(question);
                                        setIsDeleteDialogOpen(true);
                                      }}
                                    >
                                      <Trash2 className="h-4 w-4 text-red-500" />
                                    </Button>
                                  </div>
                                </div>
                                {question.imageUrl && (
                                  <div className="mt-2">
                                    <img 
                                      src={question.imageUrl} 
                                      alt={`Image for question ${question.id}`} 
                                      className="max-h-32 rounded-md"
                                    />
                                  </div>
                                )}
                              </div>
                              <div className="p-4">
                                <h4 className="text-sm font-medium mb-2">Answers</h4>
                                <div className="space-y-2">
                                  {question.answers.map((answer) => (
                                    <div key={answer.id} className="flex items-center gap-2 p-2 rounded-md border">
                                      {answer.isCorrect ? (
                                        <Check className="h-4 w-4 text-green-500" />
                                      ) : (
                                        <X className="h-4 w-4 text-red-500" />
                                      )}
                                      <p className="text-sm">{answer.text}</p>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        ))
                      ) : (
                        <div className="text-center py-12 bg-gray-50 rounded-lg">
                          <FileQuestion className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                          <h3 className="text-lg font-medium text-gray-900 mb-2">No questions found</h3>
                          <p className="text-gray-500 mb-4">
                            {searchQuery || categoryFilter !== 'all' || hasImageFilter !== null
                              ? "Try adjusting your filters"
                              : "Get started by adding some questions to your question bank"}
                          </p>
                          {searchQuery || categoryFilter !== 'all' || hasImageFilter !== null ? (
                            <Button variant="outline" onClick={resetFilters}>Clear Filters</Button>
                          ) : (
                            <Button 
                              onClick={() => {
                                resetForm();
                                setIsCreateDialogOpen(true);
                              }}
                              className="bg-[#0078D7]"
                            >
                              <Plus className="h-4 w-4 mr-2" />
                              Add First Question
                            </Button>
                          )}
                        </div>
                      )}
                    </div>
                  )}

                  {/* Table View */}
                  {view === "table" && <QuestionTable />}
                </>
              )}
            </CardContent>
            <CardFooter className="flex justify-between">
              <div className="text-xs text-gray-500">
                Last updated: {new Date().toLocaleString()}
              </div>
              <Button variant="ghost" size="sm" onClick={() => window.location.reload()}>
                <RefreshCw className="h-4 w-4 mr-2" />
                Refresh
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        {/* Categories Tab */}
        <TabsContent value="categories">
          <Card>
            <CardHeader>
              <CardTitle>Category Management</CardTitle>
              <CardDescription>Organize and manage question categories</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="col-span-1 lg:col-span-2">
                  <div className="space-y-6">
                    {/* Category list */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {availableCategories.map(category => (
                        <Card key={category.id}>
                          <CardContent className="pt-6">
                            <div className="flex justify-between items-start">
                              <div>
                                <h3 className="font-medium">{category.name}</h3>
                                <p className="text-sm text-gray-500 mt-1">{category.count} questions</p>
                                <div className="mt-2">
                                  <Button variant="outline" size="sm" className="mr-2">
                                    <Edit className="h-3.5 w-3.5 mr-1" />
                                    Edit
                                  </Button>
                                  <Button 
                                    variant="outline" 
                                    size="sm"
                                    onClick={() => {
                                      setCategoryFilter(category.name);
                                      setActiveTab("all-questions");
                                    }}
                                  >
                                    <Eye className="h-3.5 w-3.5 mr-1" />
                                    View Questions
                                  </Button>
                                </div>
                              </div>
                              <Badge variant="outline" className="px-3">
                                {Math.round((category.count / stats.totalQuestions) * 100)}%
                              </Badge>
                            </div>
                            <div className="mt-4">
                              <Progress 
                                value={(category.count / stats.totalQuestions) * 100}
                                className="h-2"
                              />
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </div>
                </div>
                <div className="col-span-1">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Add Category</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <form className="space-y-4">
                        <div className="space-y-2">
                          <Label htmlFor="categoryName">Category Name</Label>
                          <Input id="categoryName" placeholder="e.g. Road Signs" />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="categoryDescription">Description (Optional)</Label>
                          <Textarea id="categoryDescription" placeholder="Category description..." />
                        </div>
                        <Button className="w-full bg-[#0078D7]">
                          <Plus className="h-4 w-4 mr-2" />
                          Add Category
                        </Button>
                      </form>
                    </CardContent>
                  </Card>
                  
                  <Card className="mt-6">
                    <CardHeader>
                      <CardTitle className="text-lg">Category Actions</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <Button variant="outline" className="w-full justify-start" onClick={handleFileExport}>
                        <Download className="h-4 w-4 mr-2" />
                        Export Categories
                      </Button>
                      <Button variant="outline" className="w-full justify-start">
                        <RefreshCw className="h-4 w-4 mr-2" />
                        Recalculate Counts
                      </Button>
                      <Alert>
                        <AlertTitle className="flex items-center">
                          <CheckCircle2 className="h-4 w-4 mr-2 text-green-500" />
                          Category Distribution
                        </AlertTitle>
                        <AlertDescription className="pl-6">
                          Your categories are well-distributed with questions.
                        </AlertDescription>
                      </Alert>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Create Question Dialog */}
      <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Add New Question</DialogTitle>
            <DialogDescription>
              Create a new question for the exam database
            </DialogDescription>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleCreateQuestion)} className="space-y-6">
              <FormField
                control={form.control}
                name="text"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Question Text</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Enter the question text here..." 
                        className="min-h-24"
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="category"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Category</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a category" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {availableCategories.map(category => (
                          <SelectItem key={category.id} value={category.name}>
                            {category.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="imageUrl"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Image URL (Optional)</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter image URL" {...field} />
                    </FormControl>
                    <FormDescription>
                      Add an image to supplement the question
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div>
                <h3 className="text-base font-medium mb-2">Answers</h3>
                <p className="text-sm text-gray-500 mb-4">
                  Add answers and mark the correct one(s)
                </p>
                <div className="space-y-4">
                  {form.watch("answers")?.map((_, index) => (
                    <div key={index} className="flex gap-3">
                      <FormField
                        control={form.control}
                        name={`answers.${index}.isCorrect`}
                        render={({ field }) => (
                          <FormItem className="flex items-center space-x-2 space-y-0 mt-2">
                            <FormControl>
                              <Checkbox 
                                checked={field.value} 
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name={`answers.${index}.text`}
                        render={({ field }) => (
                          <FormItem className="flex-1">
                            <FormControl>
                              <Input 
                                placeholder={`Answer option ${index + 1}`} 
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        onClick={() => {
                          const answers = form.getValues("answers");
                          if (answers.length <= 2) {
                            toast({
                              title: "Cannot remove",
                              description: "Questions must have at least 2 answers",
                              variant: "destructive",
                            });
                            return;
                          }
                          const newAnswers = [...answers];
                          newAnswers.splice(index, 1);
                          form.setValue("answers", newAnswers);
                        }}
                      >
                        <Trash2 className="h-4 w-4 text-red-500" />
                      </Button>
                    </div>
                  ))}
                  
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      const answers = form.getValues("answers") || [];
                      if (answers.length >= 5) {
                        toast({
                          title: "Maximum reached",
                          description: "Questions can have a maximum of 5 answers",
                          variant: "destructive",
                        });
                        return;
                      }
                      form.setValue("answers", [...answers, { text: "", isCorrect: false }]);
                    }}
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Add Answer Option
                  </Button>
                </div>
              </div>
              
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsCreateDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  disabled={isProcessing}
                  className="bg-[#0078D7]"
                >
                  {isProcessing ? (
                    <>
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                      Creating...
                    </>
                  ) : (
                    <>
                      <Plus className="h-4 w-4 mr-2" />
                      Create Question
                    </>
                  )}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Edit Question Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Question</DialogTitle>
            <DialogDescription>
              Update the question details
            </DialogDescription>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleUpdateQuestion)} className="space-y-6">
              <FormField
                control={form.control}
                name="text"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Question Text</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Enter the question text here..." 
                        className="min-h-24"
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="category"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Category</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a category" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {availableCategories.map(category => (
                          <SelectItem key={category.id} value={category.name}>
                            {category.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="imageUrl"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Image URL (Optional)</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter image URL" {...field} />
                    </FormControl>
                    <FormDescription>
                      Add an image to supplement the question
                    </FormDescription>
                    <FormMessage />
                    {field.value && (
                      <div className="mt-2">
                        <img 
                          src={field.value} 
                          alt="Question image" 
                          className="max-h-40 rounded-md"
                          onError={(e) => {
                            e.currentTarget.src = "https://placehold.co/400x200?text=Image+Not+Found";
                          }}
                        />
                      </div>
                    )}
                  </FormItem>
                )}
              />
              
              <div>
                <h3 className="text-base font-medium mb-2">Answers</h3>
                <p className="text-sm text-gray-500 mb-4">
                  Add answers and mark the correct one(s)
                </p>
                <div className="space-y-4">
                  {form.watch("answers")?.map((_, index) => (
                    <div key={index} className="flex gap-3">
                      <FormField
                        control={form.control}
                        name={`answers.${index}.isCorrect`}
                        render={({ field }) => (
                          <FormItem className="flex items-center space-x-2 space-y-0 mt-2">
                            <FormControl>
                              <Checkbox 
                                checked={field.value} 
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name={`answers.${index}.text`}
                        render={({ field }) => (
                          <FormItem className="flex-1">
                            <FormControl>
                              <Input 
                                placeholder={`Answer option ${index + 1}`} 
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        onClick={() => {
                          const answers = form.getValues("answers");
                          if (answers.length <= 2) {
                            toast({
                              title: "Cannot remove",
                              description: "Questions must have at least 2 answers",
                              variant: "destructive",
                            });
                            return;
                          }
                          const newAnswers = [...answers];
                          newAnswers.splice(index, 1);
                          form.setValue("answers", newAnswers);
                        }}
                      >
                        <Trash2 className="h-4 w-4 text-red-500" />
                      </Button>
                    </div>
                  ))}
                  
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      const answers = form.getValues("answers") || [];
                      if (answers.length >= 5) {
                        toast({
                          title: "Maximum reached",
                          description: "Questions can have a maximum of 5 answers",
                          variant: "destructive",
                        });
                        return;
                      }
                      form.setValue("answers", [...answers, { text: "", isCorrect: false }]);
                    }}
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Add Answer Option
                  </Button>
                </div>
              </div>
              
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsEditDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  disabled={isProcessing}
                  className="bg-[#0078D7]"
                >
                  {isProcessing ? (
                    <>
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                      Updating...
                    </>
                  ) : (
                    <>
                      <Check className="h-4 w-4 mr-2" />
                      Update Question
                    </>
                  )}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="text-red-600">Confirm Deletion</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this question? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          
          {selectedQuestion && (
            <div className="p-4 border border-red-200 rounded-md bg-red-50">
              <p className="font-medium">{selectedQuestion.text}</p>
              <div className="flex mt-2">
                <Badge className="bg-[#0078D7] mr-2">{selectedQuestion.category}</Badge>
                <Badge variant="outline">ID: {selectedQuestion.id}</Badge>
              </div>
            </div>
          )}
          
          <DialogFooter className="pt-4">
            <Button 
              variant="outline" 
              onClick={() => setIsDeleteDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button 
              variant="destructive" 
              onClick={handleDeleteQuestion}
              disabled={isProcessing}
            >
              {isProcessing ? (
                <>
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  Deleting...
                </>
              ) : (
                <>
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete Question
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

// Label component (to avoid importing from a separate file)
const Label = ({ htmlFor, children }: { htmlFor: string; children: React.ReactNode }) => (
  <label htmlFor={htmlFor} className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
    {children}
  </label>
);

export default QuestionManagement;