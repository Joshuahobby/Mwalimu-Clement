import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

// Mock data for charts
const examData = [
  { name: 'Jan', exams: 40 },
  { name: 'Feb', exams: 35 },
  { name: 'Mar', exams: 50 },
  { name: 'Apr', exams: 65 },
  { name: 'May', exams: 55 },
  { name: 'Jun', exams: 75 },
  { name: 'Jul', exams: 85 },
  { name: 'Aug', exams: 78 },
  { name: 'Sep', exams: 90 },
  { name: 'Oct', exams: 100 },
  { name: 'Nov', exams: 110 },
  { name: 'Dec', exams: 120 },
];

const revenueData = [
  { name: 'Jan', revenue: 5000 },
  { name: 'Feb', revenue: 4500 },
  { name: 'Mar', revenue: 6000 },
  { name: 'Apr', revenue: 7500 },
  { name: 'May', revenue: 8000 },
  { name: 'Jun', revenue: 10000 },
  { name: 'Jul', revenue: 11000 },
  { name: 'Aug', revenue: 9500 },
  { name: 'Sep', revenue: 12000 },
  { name: 'Oct', revenue: 15000 },
  { name: 'Nov', revenue: 16000 },
  { name: 'Dec', revenue: 20000 },
];

const packageDistributionData = [
  { name: 'One-time Practice', users: 250 },
  { name: '24-Hour Access', users: 180 },
  { name: 'Weekly Access', users: 320 },
  { name: 'Monthly Access', users: 450 },
];

const examScoreDistributionData = [
  { score: '0-20%', count: 12 },
  { score: '21-40%', count: 25 },
  { score: '41-60%', count: 75 },
  { score: '61-80%', count: 150 },
  { score: '81-100%', count: 80 },
];

const ReportsDashboard = () => {
  const [period, setPeriod] = useState('year');

  return (
    <div className="space-y-6">
      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="mb-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="exams">Exams</TabsTrigger>
          <TabsTrigger value="revenue">Revenue</TabsTrigger>
          <TabsTrigger value="users">Users</TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Exams Taken (2023)</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={examData}
                      margin={{ top: 10, right: 10, left: 0, bottom: 20 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="exams" fill="#0078D7" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Revenue (2023)</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={revenueData}
                      margin={{ top: 10, right: 10, left: 0, bottom: 20 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip formatter={(value) => `${value.toLocaleString()} RWF`} />
                      <Bar dataKey="revenue" fill="#00843D" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Package Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={packageDistributionData}
                      layout="vertical"
                      margin={{ top: 10, right: 10, left: 40, bottom: 20 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis type="number" />
                      <YAxis dataKey="name" type="category" />
                      <Tooltip />
                      <Bar dataKey="users" fill="#FAD201" radius={[0, 4, 4, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Exam Score Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={examScoreDistributionData}
                      margin={{ top: 10, right: 10, left: 0, bottom: 20 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="score" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="count" fill="#9c27b0" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="exams">
          <Card>
            <CardHeader>
              <CardTitle>Exam Analytics</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-500">Detailed exam analytics will be implemented in future updates.</p>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="revenue">
          <Card>
            <CardHeader>
              <CardTitle>Revenue Analytics</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-500">Detailed revenue analytics will be implemented in future updates.</p>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="users">
          <Card>
            <CardHeader>
              <CardTitle>User Analytics</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-500">Detailed user analytics will be implemented in future updates.</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ReportsDashboard;