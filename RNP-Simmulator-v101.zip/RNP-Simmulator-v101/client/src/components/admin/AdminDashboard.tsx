import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { 
  TrendingUp, TrendingDown, Users, BookOpen, DollarSign, Calendar, 
  CheckCircle2, XCircle, CircleDashed, ArrowUpRight, BarChart, 
  PieChart, Activity, Clock, ChartPie
} from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  AreaChart, BarChart as RechartsBarChart, PieChart as RechartsPieChart, 
  Area, Bar, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, 
  ResponsiveContainer, Pie, Label 
} from "recharts";

interface StatsData {
  totalUsers: number;
  totalExams: number;
  totalRevenue: number;
  activeSubscriptions: number;
  passingRate: number;
  averageScore: number;
  examsPassed: number;
  examsFailed: number;
  monthlyStats?: Array<{
    month: string;
    users: number;
    exams: number;
    revenue: number;
  }>;
  packageDistribution?: Array<{
    name: string;
    value: number;
    color: string;
  }>;
  timeDistribution?: Array<{
    hour: string;
    exams: number;
  }>;
  examCategories?: Array<{
    category: string;
    count: number;
    color: string;
  }>;
  recentPayments?: Array<{
    id: number;
    user: string;
    amount: number;
    date: string;
    status: string;
  }>;
  recentUsers?: Array<{
    id: number;
    name: string;
    email: string;
    date: string;
  }>;
}

// Mock data for charts - will be replaced with real API data when available
const mockStatsData: StatsData = {
  totalUsers: 0,
  totalExams: 0,
  totalRevenue: 0,
  activeSubscriptions: 0,
  passingRate: 72,
  averageScore: 68,
  examsPassed: 180,
  examsFailed: 70,
  monthlyStats: [
    { month: 'Jan', users: 20, exams: 45, revenue: 25000 },
    { month: 'Feb', users: 32, exams: 58, revenue: 35000 },
    { month: 'Mar', users: 45, exams: 90, revenue: 52000 },
    { month: 'Apr', users: 58, exams: 102, revenue: 61000 },
    { month: 'May', users: 64, exams: 110, revenue: 68000 },
    { month: 'Jun', users: 80, exams: 122, revenue: 75000 },
  ],
  packageDistribution: [
    { name: 'One-time Practice', value: 55, color: '#0088FE' },
    { name: 'Monthly Standard', value: 30, color: '#00C49F' },
    { name: 'Yearly Premium', value: 15, color: '#FFBB28' },
  ],
  timeDistribution: [
    { hour: '8AM', exams: 12 },
    { hour: '10AM', exams: 28 },
    { hour: '12PM', exams: 45 },
    { hour: '2PM', exams: 60 },
    { hour: '4PM', exams: 38 },
    { hour: '6PM', exams: 25 },
    { hour: '8PM', exams: 18 },
  ],
  examCategories: [
    { category: 'Road Signs', count: 120, color: '#0088FE' },
    { category: 'Traffic Laws', count: 90, color: '#00C49F' },
    { category: 'Vehicle Operation', count: 70, color: '#FFBB28' },
    { category: 'Safety Procedures', count: 60, color: '#FF8042' },
    { category: 'Emergency Response', count: 40, color: '#8884d8' },
  ],
  recentPayments: [
    { id: 1, user: 'John Doe', amount: 5000, date: '2025-04-12', status: 'completed' },
    { id: 2, user: 'Jane Smith', amount: 15000, date: '2025-04-11', status: 'completed' },
    { id: 3, user: 'Robert Johnson', amount: 5000, date: '2025-04-10', status: 'failed' },
    { id: 4, user: 'Maria Garcia', amount: 5000, date: '2025-04-09', status: 'completed' },
  ],
  recentUsers: [
    { id: 1, name: 'Alice Johnson', email: 'alice@example.com', date: '2025-04-12' },
    { id: 2, name: 'Bob Williams', email: 'bob@example.com', date: '2025-04-11' },
    { id: 3, name: 'Carol Martinez', email: 'carol@example.com', date: '2025-04-10' },
    { id: 4, name: 'David Thompson', email: 'david@example.com', date: '2025-04-09' },
  ]
};

const AdminDashboard = () => {
  const [stats, setStats] = useState<StatsData | null>(null);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();
  const [chartData, setChartData] = useState<StatsData | null>(null);
  const [chartPeriod, setChartPeriod] = useState("month");

  useEffect(() => {
    const fetchStats = async () => {
      try {
        setLoading(true);
        const response = await fetch('/api/admin/stats', {
          credentials: 'include',
        });
        
        if (!response.ok) {
          throw new Error('Failed to fetch admin stats');
        }
        
        const data = await response.json();
        setStats(data.stats);
        
        // After fetching main stats, merge with mock chart data (temporary until API provides full data)
        setChartData({
          ...data.stats,
          ...mockStatsData
        });
      } catch (error) {
        console.error('Error fetching admin stats:', error);
        toast({
          title: 'Error',
          description: 'Failed to load dashboard statistics.',
          variant: 'destructive',
        });
        
        // For demo purposes, use mock data if API fails
        setChartData(mockStatsData);
        
      } finally {
        setLoading(false);
      }
    };

    fetchStats();
  }, [toast]);

  // Format number with commas
  const formatNumber = (num: number) => {
    return num?.toLocaleString() || '0';
  };

  // Format currency
  const formatCurrency = (amount: number) => {
    return `${formatNumber(amount || 0)} RWF`;
  };
  
  // Format date
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };
  
  // Calculate pass rate color
  const getPassRateColor = (rate: number) => {
    if (rate >= 80) return 'text-green-600';
    if (rate >= 60) return 'text-amber-500';
    return 'text-red-500';
  };

  return (
    <div className="space-y-8">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {loading ? (
          // Loading skeletons
          Array.from({ length: 4 }).map((_, i) => (
            <Card key={i}>
              <CardContent className="p-6">
                <Skeleton className="h-24 w-full" />
              </CardContent>
            </Card>
          ))
        ) : (
          <>
            {/* Total Users */}
            <Card>
              <CardContent className="pt-6">
                <div className="flex">
                  <div className="w-12 h-12 rounded-full bg-[#0078D7] bg-opacity-10 flex items-center justify-center mr-4">
                    <Users className="w-6 h-6 text-[#0078D7]" />
                  </div>
                  <div>
                    <p className="text-gray-600 text-sm">Total Users</p>
                    <h3 className="text-2xl font-bold">{formatNumber(stats?.totalUsers || 0)}</h3>
                    <p className="text-[#00843D] text-xs flex items-center mt-1">
                      <TrendingUp className="w-3 h-3 mr-1" />
                      <span>12% increase</span>
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Total Exams */}
            <Card>
              <CardContent className="pt-6">
                <div className="flex">
                  <div className="w-12 h-12 rounded-full bg-[#00843D] bg-opacity-10 flex items-center justify-center mr-4">
                    <BookOpen className="w-6 h-6 text-[#00843D]" />
                  </div>
                  <div>
                    <p className="text-gray-600 text-sm">Total Exams</p>
                    <h3 className="text-2xl font-bold">{formatNumber(stats?.totalExams || 0)}</h3>
                    <p className="text-[#00843D] text-xs flex items-center mt-1">
                      <TrendingUp className="w-3 h-3 mr-1" />
                      <span>8% increase</span>
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Total Revenue */}
            <Card>
              <CardContent className="pt-6">
                <div className="flex">
                  <div className="w-12 h-12 rounded-full bg-[#FAD201] bg-opacity-20 flex items-center justify-center mr-4">
                    <DollarSign className="w-6 h-6 text-[#FAD201]" />
                  </div>
                  <div>
                    <p className="text-gray-600 text-sm">Total Revenue</p>
                    <h3 className="text-2xl font-bold">{formatCurrency(stats?.totalRevenue || 0)}</h3>
                    <p className="text-[#00843D] text-xs flex items-center mt-1">
                      <TrendingUp className="w-3 h-3 mr-1" />
                      <span>15% increase</span>
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Active Subscriptions */}
            <Card>
              <CardContent className="pt-6">
                <div className="flex">
                  <div className="w-12 h-12 rounded-full bg-purple-100 flex items-center justify-center mr-4">
                    <Calendar className="w-6 h-6 text-purple-600" />
                  </div>
                  <div>
                    <p className="text-gray-600 text-sm">Active Packages</p>
                    <h3 className="text-2xl font-bold">{formatNumber(stats?.activeSubscriptions || 0)}</h3>
                    <p className="text-red-500 text-xs flex items-center mt-1">
                      <TrendingDown className="w-3 h-3 mr-1" />
                      <span>3% decrease</span>
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </>
        )}
      </div>

      {/* Exam Performance Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Performance Card */}
        <Card className="col-span-1">
          <CardHeader>
            <CardTitle className="text-lg font-medium">Exam Performance</CardTitle>
            <CardDescription>Average score and pass rates</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-8">
              {/* Pass Rate */}
              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm text-gray-600">Pass Rate</span>
                  <span className={`text-lg font-bold ${getPassRateColor(chartData?.passingRate || 0)}`}>
                    {chartData?.passingRate || 0}%
                  </span>
                </div>
                <Progress value={chartData?.passingRate || 0} className="h-2" />
                <div className="mt-2 flex justify-between text-xs text-gray-500">
                  <span>0%</span>
                  <span>50%</span>
                  <span>100%</span>
                </div>
              </div>
              
              {/* Average Score */}
              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm text-gray-600">Average Score</span>
                  <span className="text-lg font-bold text-[#0078D7]">
                    {chartData?.averageScore || 0}%
                  </span>
                </div>
                <Progress value={chartData?.averageScore || 0} className="h-2" />
                <div className="mt-2 flex justify-between text-xs text-gray-500">
                  <span>0%</span>
                  <span>50%</span>
                  <span>100%</span>
                </div>
              </div>
              
              {/* Pass/Fail Stats */}
              <div className="grid grid-cols-2 gap-4 mt-6">
                <div className="bg-green-50 p-4 rounded-lg">
                  <div className="flex items-center mb-2">
                    <CheckCircle2 className="w-5 h-5 text-green-500 mr-2" />
                    <span className="text-sm text-gray-700">Exams Passed</span>
                  </div>
                  <p className="text-xl font-bold text-green-700">{formatNumber(chartData?.examsPassed || 0)}</p>
                </div>
                <div className="bg-red-50 p-4 rounded-lg">
                  <div className="flex items-center mb-2">
                    <XCircle className="w-5 h-5 text-red-500 mr-2" />
                    <span className="text-sm text-gray-700">Exams Failed</span>
                  </div>
                  <p className="text-xl font-bold text-red-700">{formatNumber(chartData?.examsFailed || 0)}</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* Activity Charts */}
        <Card className="col-span-2">
          <CardHeader>
            <div className="flex justify-between items-center">
              <div>
                <CardTitle className="text-lg font-medium">Activity Overview</CardTitle>
                <CardDescription>User registrations, exams, and revenue</CardDescription>
              </div>
              <Tabs defaultValue="month" value={chartPeriod} onValueChange={setChartPeriod} className="w-[200px]">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="week">Week</TabsTrigger>
                  <TabsTrigger value="month">Month</TabsTrigger>
                  <TabsTrigger value="year">Year</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart
                data={chartData?.monthlyStats || []}
                margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
              >
                <defs>
                  <linearGradient id="colorUsers" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#0078D7" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#0078D7" stopOpacity={0.1}/>
                  </linearGradient>
                  <linearGradient id="colorExams" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#00843D" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#00843D" stopOpacity={0.1}/>
                  </linearGradient>
                  <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#FAD201" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#FAD201" stopOpacity={0.1}/>
                  </linearGradient>
                </defs>
                <XAxis dataKey="month" />
                <YAxis />
                <CartesianGrid strokeDasharray="3 3" />
                <Tooltip />
                <Legend />
                <Area 
                  type="monotone" 
                  dataKey="users" 
                  stroke="#0078D7" 
                  fillOpacity={1} 
                  fill="url(#colorUsers)" 
                  name="Users"
                />
                <Area 
                  type="monotone" 
                  dataKey="exams" 
                  stroke="#00843D" 
                  fillOpacity={1} 
                  fill="url(#colorExams)" 
                  name="Exams"
                />
                <Area 
                  type="monotone" 
                  dataKey="revenue" 
                  stroke="#FAD201" 
                  fillOpacity={1} 
                  fill="url(#colorRevenue)" 
                  name="Revenue (RWF)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
      
      {/* Detail Charts */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Package Distribution */}
        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <div>
                <CardTitle className="text-lg font-medium">Package Distribution</CardTitle>
                <CardDescription>Subscription type breakdown</CardDescription>
              </div>
              <ChartPie className="h-5 w-5 text-gray-500" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="h-[300px] flex items-center justify-center">
              <ResponsiveContainer width="100%" height={300}>
                <RechartsPieChart>
                  <Pie
                    data={chartData?.packageDistribution || []}
                    cx="50%"
                    cy="50%"
                    innerRadius={70}
                    outerRadius={90}
                    fill="#8884d8"
                    paddingAngle={5}
                    dataKey="value"
                    nameKey="name"
                    label
                  >
                    {chartData?.packageDistribution?.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                    <Label 
                      value="Packages" 
                      position="center"
                      className="text-gray-500 text-sm"
                    />
                  </Pie>
                  <Tooltip />
                  <Legend />
                </RechartsPieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
        
        {/* Time Distribution */}
        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <div>
                <CardTitle className="text-lg font-medium">Exam Time Distribution</CardTitle>
                <CardDescription>When exams are taken</CardDescription>
              </div>
              <Clock className="h-5 w-5 text-gray-500" />
            </div>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <RechartsBarChart
                data={chartData?.timeDistribution || []}
                margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="hour" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="exams" name="Exams Taken" fill="#0078D7" />
              </RechartsBarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
      
      {/* Recent Activity Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Payments */}
        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <div>
                <CardTitle className="text-lg font-medium">Recent Payments</CardTitle>
                <CardDescription>Latest transactions</CardDescription>
              </div>
              <DollarSign className="h-5 w-5 text-gray-500" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {chartData?.recentPayments?.map(payment => (
                <div key={payment.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div>
                    <p className="font-medium">{payment.user}</p>
                    <p className="text-sm text-gray-500">{formatDate(payment.date)}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-bold">{formatCurrency(payment.amount)}</p>
                    <span className={`text-xs px-2 py-1 rounded-full ${
                      payment.status === 'completed' ? 'bg-green-100 text-green-800' : 
                      payment.status === 'pending' ? 'bg-yellow-100 text-yellow-800' : 
                      'bg-red-100 text-red-800'
                    }`}>
                      {payment.status.charAt(0).toUpperCase() + payment.status.slice(1)}
                    </span>
                  </div>
                </div>
              ))}
              
              {chartData?.recentPayments?.length === 0 && (
                <div className="text-center py-6 text-gray-500">
                  <p>No recent payments to display</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
        
        {/* Recent Users */}
        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <div>
                <CardTitle className="text-lg font-medium">Recent Users</CardTitle>
                <CardDescription>Newly registered users</CardDescription>
              </div>
              <Users className="h-5 w-5 text-gray-500" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {chartData?.recentUsers?.map(user => (
                <div key={user.id} className="flex items-start justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex">
                    <div className="w-8 h-8 rounded-full bg-[#0078D7] flex items-center justify-center text-white font-medium mr-3">
                      {user.name.charAt(0)}
                    </div>
                    <div>
                      <p className="font-medium">{user.name}</p>
                      <p className="text-sm text-gray-500">{user.email}</p>
                    </div>
                  </div>
                  <div className="text-xs text-gray-500">
                    Joined {formatDate(user.date)}
                  </div>
                </div>
              ))}
              
              {chartData?.recentUsers?.length === 0 && (
                <div className="text-center py-6 text-gray-500">
                  <p>No recent users to display</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Category Distribution */}
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle className="text-lg font-medium">Exam Categories</CardTitle>
              <CardDescription>Category distribution of exams taken</CardDescription>
            </div>
            <BarChart className="h-5 w-5 text-gray-500" />
          </div>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <RechartsBarChart
              data={chartData?.examCategories || []}
              margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
              layout="vertical"
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis type="number" />
              <YAxis dataKey="category" type="category" width={150} />
              <Tooltip />
              <Legend />
              <Bar dataKey="count" name="Exams Taken">
                {chartData?.examCategories?.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Bar>
            </RechartsBarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  );
};

export default AdminDashboard;
