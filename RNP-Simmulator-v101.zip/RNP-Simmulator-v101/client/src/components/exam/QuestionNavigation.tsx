import { Button } from "@/components/ui/button";
import { useState } from "react";
import { CheckCircle, Circle, AlertCircle } from "lucide-react";

interface QuestionNavigationProps {
  totalQuestions: number;
  currentQuestionIndex: number;
  answeredQuestions: boolean[];
  onQuestionClick: (index: number) => void;
  onEndExam: () => void;
}

const QuestionNavigation = ({
  totalQuestions,
  currentQuestionIndex,
  answeredQuestions,
  onQuestionClick,
  onEndExam
}: QuestionNavigationProps) => {
  const [showWarning, setShowWarning] = useState(false);
  
  // Calculate how many questions are answered
  const answeredCount = answeredQuestions.filter(Boolean).length;
  const unansweredCount = totalQuestions - answeredCount;
  
  // Show warning when clicking End Exam with unanswered questions
  const handleEndExamClick = () => {
    if (unansweredCount > 0) {
      setShowWarning(true);
    } else {
      onEndExam();
    }
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-3">
        <h3 className="text-lg font-medium">Question Navigation</h3>
        <div className="text-sm text-gray-600">
          <span className="font-medium">{answeredCount}</span> of <span className="font-medium">{totalQuestions}</span> answered
        </div>
      </div>
      
      <div className="grid grid-cols-5 sm:grid-cols-10 gap-2">
        {Array.from({ length: totalQuestions }).map((_, index) => {
          const isAnswered = answeredQuestions[index];
          const isCurrent = index === currentQuestionIndex;
          
          return (
            <button
              key={index}
              onClick={() => onQuestionClick(index)}
              className={`
                w-full py-2 font-medium rounded transition-all duration-200
                ${isAnswered 
                  ? 'bg-[#00843D] text-white shadow-sm hover:bg-[#00743a]' 
                  : isCurrent 
                    ? 'bg-[#0078D7] text-white shadow-sm hover:bg-[#0068c0]' 
                    : 'bg-white border border-[#E0E0E0] hover:border-[#0078D7] hover:text-[#0078D7]'
                }
                ${isCurrent ? 'ring-2 ring-offset-2 ring-[#0078D7]' : ''}
              `}
              aria-label={`Go to question ${index + 1}${isAnswered ? ' (answered)' : ' (not answered)'}`}
            >
              {isAnswered ? (
                <CheckCircle className="w-3 h-3 mx-auto text-white" />
              ) : (
                <span>{index + 1}</span>
              )}
            </button>
          );
        })}
      </div>
      
      <div className="mt-4 flex justify-between items-center bg-gray-50 p-2 rounded-md">
        <div className="flex items-center">
          <div className="w-4 h-4 bg-[#00843D] rounded-sm mr-2 flex items-center justify-center text-white">
            <CheckCircle className="w-3 h-3" />
          </div>
          <span className="text-sm">Answered</span>
        </div>
        <div className="flex items-center">
          <div className="w-4 h-4 bg-[#0078D7] rounded-sm mr-2"></div>
          <span className="text-sm">Current</span>
        </div>
        <div className="flex items-center">
          <div className="w-4 h-4 bg-white border border-[#E0E0E0] rounded-sm mr-2 flex items-center justify-center">
            <Circle className="w-3 h-3 text-gray-400" />
          </div>
          <span className="text-sm">Unanswered</span>
        </div>
      </div>
      
      {showWarning && (
        <div className="mt-4 p-3 bg-yellow-50 border border-yellow-200 rounded-md flex items-start">
          <AlertCircle className="w-5 h-5 text-yellow-500 mr-2 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-sm text-yellow-700">
              You have {unansweredCount} unanswered {unansweredCount === 1 ? 'question' : 'questions'}. 
              Are you sure you want to end the exam?
            </p>
            <div className="mt-2 flex space-x-2">
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => setShowWarning(false)}
                className="text-xs h-8"
              >
                Continue Exam
              </Button>
              <Button 
                size="sm" 
                onClick={onEndExam}
                className="bg-yellow-600 hover:bg-yellow-700 text-white text-xs h-8"
              >
                End Anyway
              </Button>
            </div>
          </div>
        </div>
      )}
      
      {!showWarning && (
        <div className="mt-6 flex justify-center">
          <Button 
            onClick={handleEndExamClick}
            className="bg-red-600 hover:bg-red-700 text-white"
          >
            End Exam
          </Button>
        </div>
      )}
    </div>
  );
};

export default QuestionNavigation;
