import { useState } from 'react';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { CheckCircle, ArrowRight, Clock, AlertCircle } from 'lucide-react';

export default function ExamConfigForm() {
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  const [, navigate] = useLocation();

  const handleStartExam = async () => {
    setLoading(true);
    
    try {
      // Make API request to start a new exam (always 20 questions as per requirements)
      const response = await fetch('/api/exams/start', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({}),
        credentials: 'include'
      });
      
      // Parse the response JSON
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.message || 'Failed to start exam');
      }
      
      toast({
        title: 'Exam Started',
        description: 'Your exam has been started. Good luck!',
      });
      
      // Navigate to the exam page
      navigate(`/exam/${data.examId}`);
    } catch (error) {
      console.error('Error starting exam:', error);
      toast({
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to start exam. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle className="text-xl font-bold">Start New Exam</CardTitle>
        <CardDescription>
          Review the exam rules before starting
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
          <h3 className="font-medium text-amber-800 flex items-center gap-2 mb-2">
            <AlertCircle className="h-4 w-4" />
            Important Information
          </h3>
          <ul className="space-y-2 text-sm text-amber-700">
            <li>Once you start the exam, the timer cannot be paused</li>
            <li>Ensure you have a stable internet connection</li>
            <li>Do not refresh or close the browser during the exam</li>
          </ul>
        </div>

        <div className="space-y-3 pt-2">
          <h4 className="font-medium">Exam Structure</h4>
          <ul className="space-y-3 text-sm">
            <li className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-green-500 flex-shrink-0" />
              <span><strong>20 questions</strong> - Each question is worth 1 mark</span>
            </li>
            <li className="flex items-center gap-2">
              <Clock className="h-4 w-4 text-blue-500 flex-shrink-0" />
              <span><strong>20 minutes</strong> maximum time limit</span>
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-green-500 flex-shrink-0" />
              <span><strong>Passing score: 14/20</strong> (70%)</span>
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-green-500 flex-shrink-0" />
              <span>Questions are randomly selected from different categories</span>
            </li>
          </ul>
        </div>
      </CardContent>
      <CardFooter>
        <Button 
          className="w-full bg-[#0078D7] hover:bg-[#0067be] py-6 text-base"
          onClick={handleStartExam}
          disabled={loading}
        >
          {loading ? (
            <span className="flex items-center gap-2">
              <span className="h-4 w-4 border-2 border-current border-r-transparent animate-spin rounded-full"></span>
              Starting Exam...
            </span>
          ) : (
            <span className="flex items-center gap-2">
              Start Exam <ArrowRight className="h-4 w-4" />
            </span>
          )}
        </Button>
      </CardFooter>
    </Card>
  );
}