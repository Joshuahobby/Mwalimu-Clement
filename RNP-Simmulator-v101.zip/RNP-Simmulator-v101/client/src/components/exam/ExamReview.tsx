import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { CheckCircle2, XCircle } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

interface Answer {
  id: number;
  text: string;
  isCorrect: boolean;
}

interface ExamQuestion {
  id: number;
  examId: number;
  questionId: number;
  selectedAnswerId?: number;
  isCorrect?: boolean;
  question: {
    id: number;
    text: string;
    category: string;
    imageUrl?: string;
  };
  answers: Answer[];
}

interface Exam {
  id: number;
  userId: number;
  startTime: string;
  endTime?: string;
  isCompleted: boolean;
  score?: number;
  totalQuestions: number;
}

interface ExamReviewProps {
  examId: number;
}

const ExamReview = ({ examId }: ExamReviewProps) => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [exam, setExam] = useState<Exam | null>(null);
  const [questions, setQuestions] = useState<ExamQuestion[]>([]);
  
  useEffect(() => {
    const fetchExamData = async () => {
      try {
        setLoading(true);
        const response = await fetch(`/api/exams/${examId}`, {
          credentials: 'include',
        });

        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.message || 'Failed to fetch exam results');
        }

        const data = await response.json();
        setExam(data.exam);
        setQuestions(data.questions);
        setError(null);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'An error occurred');
      } finally {
        setLoading(false);
      }
    };

    fetchExamData();
  }, [examId]);

  // Calculate pass status
  const isPassed = exam?.score && exam.score >= 70;

  // Calculate time spent
  const calculateTimeSpent = () => {
    if (!exam || !exam.startTime || !exam.endTime) return "N/A";
    
    const start = new Date(exam.startTime);
    const end = new Date(exam.endTime);
    const diffMs = end.getTime() - start.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffSecs = Math.floor((diffMs % 60000) / 1000);
    
    return `${diffMins}m ${diffSecs}s`;
  };

  // Format date for display
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString();
  };

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto px-4">
        <Card className="mb-6">
          <CardHeader>
            <CardTitle><Skeleton className="h-8 w-48" /></CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              <Skeleton className="h-24 w-full" />
              <Skeleton className="h-24 w-full" />
            </div>
            <Skeleton className="h-10 w-32 mx-auto" />
          </CardContent>
        </Card>
        
        {Array.from({ length: 3 }).map((_, i) => (
          <Card key={i} className="mb-4">
            <CardContent className="pt-6">
              <Skeleton className="h-6 w-full mb-4" />
              <Skeleton className="h-24 w-full mb-4" />
              {Array.from({ length: 4 }).map((_, j) => (
                <Skeleton key={j} className="h-12 w-full mb-2" />
              ))}
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (error || !exam) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-8">
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <XCircle className="h-12 w-12 text-red-500 mx-auto mb-4" />
              <h2 className="text-xl font-bold mb-2">Error Loading Exam Results</h2>
              <p className="text-gray-600 mb-4">{error || "Exam data not found"}</p>
              <Link href="/dashboard">
                <Button>Return to Dashboard</Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  const correctAnswers = questions.filter(q => q.isCorrect).length;

  return (
    <div className="max-w-4xl mx-auto px-4">
      {/* Exam Summary */}
      <Card className="mb-6 border-t-4 overflow-hidden" style={{ borderTopColor: isPassed ? '#00843D' : '#DC2626' }}>
        <CardHeader className="bg-gray-50 pb-2">
          <div className="flex justify-between items-center">
            <CardTitle className="text-2xl font-bold">Exam Results</CardTitle>
            <div className={`px-3 py-1 rounded-full text-white font-medium text-sm ${isPassed ? 'bg-green-600' : 'bg-red-600'}`}>
              {isPassed ? 'PASSED' : 'FAILED'}
            </div>
          </div>
        </CardHeader>
        <CardContent className="pt-6">
          {/* Score Visualization */}
          <div className="flex justify-center mb-6">
            <div className="relative w-48 h-48">
              <div className="absolute inset-0 flex items-center justify-center flex-col">
                <span className="text-4xl font-bold">{exam.score || 0}%</span>
                <span className="text-gray-500 text-sm">Score</span>
              </div>
              <svg className="w-full h-full" viewBox="0 0 100 100">
                <circle 
                  cx="50" cy="50" r="45" 
                  fill="none" 
                  stroke="#e6e6e6" 
                  strokeWidth="10"
                />
                <circle 
                  cx="50" cy="50" r="45" 
                  fill="none" 
                  stroke={isPassed ? "#00843D" : "#DC2626"} 
                  strokeWidth="10"
                  strokeDasharray={`${2 * Math.PI * 45 * (exam.score || 0) / 100} ${2 * Math.PI * 45 * (1 - (exam.score || 0) / 100)}`}
                  strokeDashoffset={2 * Math.PI * 45 * 0.25}
                  strokeLinecap="round"
                  transform="rotate(-90, 50, 50)"
                />
              </svg>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <div className="bg-gray-50 p-4 rounded-lg shadow-sm">
              <h3 className="font-semibold text-lg mb-2 flex items-center">
                <svg className="w-5 h-5 mr-2 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                Score Details
              </h3>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <p className="text-gray-600 text-sm">Passing Score:</p>
                  <p className="font-bold">14/20 (70%)</p>
                </div>
                <div>
                  <p className="text-gray-600 text-sm">Your Score:</p>
                  <p className="font-bold text-lg" style={{ color: isPassed ? '#00843D' : '#DC2626' }}>
                    {exam.score || 0}%
                  </p>
                </div>
                <div>
                  <p className="text-gray-600 text-sm">Correct Answers:</p>
                  <p className="font-bold">{correctAnswers}/{exam.totalQuestions}</p>
                </div>
                <div>
                  <p className="text-gray-600 text-sm">Accuracy:</p>
                  <p className="font-bold">{Math.round((correctAnswers / exam.totalQuestions) * 100)}%</p>
                </div>
              </div>
            </div>
            
            <div className="bg-gray-50 p-4 rounded-lg shadow-sm">
              <h3 className="font-semibold text-lg mb-2 flex items-center">
                <svg className="w-5 h-5 mr-2 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                Exam Details
              </h3>
              <div className="space-y-2">
                <div className="flex justify-between items-center pb-1 border-b border-gray-200">
                  <span className="text-gray-600 text-sm">Time Spent:</span>
                  <span className="font-medium">{calculateTimeSpent()}</span>
                </div>
                <div className="flex justify-between items-center pb-1 border-b border-gray-200">
                  <span className="text-gray-600 text-sm">Started:</span>
                  <span className="font-medium">{formatDate(exam.startTime)}</span>
                </div>
                <div className="flex justify-between items-center pb-1 border-b border-gray-200">
                  <span className="text-gray-600 text-sm">Completed:</span>
                  <span className="font-medium">{exam.endTime ? formatDate(exam.endTime) : 'N/A'}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600 text-sm">Exam ID:</span>
                  <span className="font-medium text-gray-500">{exam.id}</span>
                </div>
              </div>
            </div>
          </div>
          
          <div className="flex flex-col sm:flex-row justify-center gap-3">
            <Link href="/dashboard">
              <Button className="bg-[#0078D7] w-full sm:w-auto">
                <svg className="w-4 h-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
                </svg>
                Return to Dashboard
              </Button>
            </Link>
            <Link href="/exams/config">
              <Button className="bg-[#00843D] w-full sm:w-auto">
                <svg className="w-4 h-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                </svg>
                Take Another Exam
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>
      
      {/* Questions Review */}
      <div className="bg-white rounded-lg p-4 mb-6 shadow-sm">
        <h2 className="text-xl font-bold mb-2">Performance by Question</h2>
        <p className="text-gray-600 mb-4">
          Review all questions and see where you did well and where you need improvement.
        </p>
        
        <div className="flex items-center justify-between mb-6 border-b pb-4">
          <div className="flex items-center">
            <div className="w-4 h-4 bg-green-500 rounded-sm mr-2"></div>
            <span className="text-sm mr-4">Correct ({questions.filter(q => q.isCorrect).length})</span>
          </div>
          <div className="flex items-center">
            <div className="w-4 h-4 bg-red-500 rounded-sm mr-2"></div>
            <span className="text-sm mr-4">Incorrect ({questions.filter(q => q.isCorrect === false).length})</span>
          </div>
          <div className="flex items-center">
            <div className="w-4 h-4 bg-gray-300 rounded-sm mr-2"></div>
            <span className="text-sm">Unanswered ({questions.filter(q => q.selectedAnswerId === undefined).length})</span>
          </div>
        </div>
      </div>
      
      {questions.map((question, index) => {
        const isCorrect = question.isCorrect;
        const isAnswered = question.selectedAnswerId !== undefined;
        
        return (
          <Card 
            key={question.id} 
            className={`mb-4 overflow-hidden border-l-4 ${
              isCorrect ? 'border-l-green-500' : 
              (isAnswered ? 'border-l-red-500' : 'border-l-gray-300')
            }`}
          >
            <CardContent className="pt-6">
              <div className="flex items-start mb-4">
                <div className={`
                  rounded-full h-7 w-7 flex items-center justify-center mr-3 flex-shrink-0
                  ${isCorrect ? 'bg-green-100 text-green-700' : 
                    (isAnswered ? 'bg-red-100 text-red-700' : 'bg-gray-100 text-gray-500')}
                `}>
                  <span className="text-sm font-medium">{index + 1}</span>
                </div>
                <div>
                  <div className="flex items-center mb-1">
                    <span className={`
                      px-2 py-0.5 rounded-full text-xs font-medium mr-2
                      ${isCorrect ? 'bg-green-100 text-green-700' : 
                        (isAnswered ? 'bg-red-100 text-red-700' : 'bg-gray-100 text-gray-500')}
                    `}>
                      {isCorrect ? 'Correct' : (isAnswered ? 'Incorrect' : 'Unanswered')}
                    </span>
                    <span className="text-xs text-gray-500">Category: {question.question.category}</span>
                  </div>
                  <h3 className="text-lg font-medium">{question.question.text}</h3>
                </div>
              </div>
              
              {question.question.imageUrl && (
                <div className="my-4 flex justify-center">
                  <img 
                    src={question.question.imageUrl} 
                    alt={`Question ${index + 1}`} 
                    className="max-h-64 rounded-lg shadow-md" 
                  />
                </div>
              )}
              
              <div className="space-y-3 mt-4">
                {question.answers.map((answer) => {
                  const isSelected = question.selectedAnswerId === answer.id;
                  const showCorrect = answer.isCorrect;
                  const showIncorrect = isSelected && !answer.isCorrect;
                  
                  return (
                    <div
                      key={answer.id}
                      className={`
                        border rounded-lg p-3 flex items-center transition-colors
                        ${showCorrect ? 'border-green-500 bg-green-50' : ''}
                        ${showIncorrect ? 'border-red-500 bg-red-50' : ''}
                        ${isSelected && !showIncorrect && !showCorrect ? 'border-[#0078D7] bg-[#0078D7] bg-opacity-5' : ''}
                        ${!isSelected && !showCorrect ? 'border-[#E0E0E0]' : ''}
                      `}
                    >
                      <div className="flex w-full items-center justify-between">
                        <div className="flex items-center">
                          <div className={`
                            w-6 h-6 rounded-full flex-shrink-0 flex items-center justify-center mr-3
                            ${isSelected ? 'bg-[#0078D7] text-white' : 'border border-gray-400'}
                            ${showCorrect ? 'bg-green-500 text-white border-0' : ''}
                            ${showIncorrect ? 'bg-red-500 text-white border-0' : ''}
                          `}>
                            <span className="text-sm font-medium">
                              {String.fromCharCode(65 + question.answers.indexOf(answer))}
                            </span>
                          </div>
                          <span className={showCorrect ? 'font-medium' : ''}>{answer.text}</span>
                        </div>
                        
                        <div className="flex items-center">
                          {showCorrect && (
                            <div className="flex items-center bg-green-100 px-2 py-0.5 rounded text-green-700 text-xs">
                              <CheckCircle2 className="h-3.5 w-3.5 mr-1" />
                              <span>Correct</span>
                            </div>
                          )}
                          {showIncorrect && (
                            <div className="flex items-center bg-red-100 px-2 py-0.5 rounded text-red-700 text-xs">
                              <XCircle className="h-3.5 w-3.5 mr-1" />
                              <span>Your Answer</span>
                            </div>
                          )}
                          {isSelected && !showIncorrect && !showCorrect && (
                            <div className="flex items-center bg-blue-100 px-2 py-0.5 rounded text-blue-700 text-xs">
                              <span>Your Answer</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
              
              {/* Correct Answer Explanation */}
              {question.isCorrect === false && (
                <div className="mt-4 p-4 bg-blue-50 border border-blue-100 rounded-lg">
                  <div className="flex items-center mb-2">
                    <svg className="w-5 h-5 text-blue-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <p className="text-sm font-medium text-blue-800">Explanation</p>
                  </div>
                  <p className="text-sm text-blue-700 pl-7">
                    The correct answer is: <span className="font-medium">{question.answers.find(a => a.isCorrect)?.text}</span>
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        );
      })}
      
      {/* Back to Top Button */}
      <div className="flex justify-center my-6">
        <Button 
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          variant="outline"
          className="border-[#0078D7] text-[#0078D7]"
        >
          Back to Top
        </Button>
      </div>
    </div>
  );
};

export default ExamReview;
