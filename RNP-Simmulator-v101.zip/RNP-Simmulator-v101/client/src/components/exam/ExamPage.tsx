import { useExam } from "@/hooks/useExam";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Skeleton } from "@/components/ui/skeleton";
import QuestionNavigation from "./QuestionNavigation";
import { AlertCircle, CheckCircle2 } from "lucide-react";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useState } from "react";

interface ExamPageProps {
  examId: number;
}

const ExamPage = ({ examId }: ExamPageProps) => {
  const {
    examData,
    loading,
    error,
    currentQuestion,
    currentQuestionIndex,
    timeRemaining,
    answeredQuestionsCount,
    submitAnswer,
    completeExam,
    nextQuestion,
    previousQuestion,
    goToQuestion,
  } = useExam(examId);

  const [showEndExamDialog, setShowEndExamDialog] = useState(false);

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto px-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex justify-between items-center mb-6">
              <Skeleton className="h-8 w-64" />
              <Skeleton className="h-8 w-24" />
            </div>
            <Skeleton className="h-4 w-full mb-2" />
            <Skeleton className="h-2.5 w-full mb-6" />
            <Skeleton className="h-6 w-3/4 mb-4" />
            <Skeleton className="h-48 w-full mb-6" />
            {Array.from({ length: 4 }).map((_, i) => (
              <Skeleton key={i} className="h-16 w-full mb-3" />
            ))}
            <div className="flex justify-between mt-6">
              <Skeleton className="h-10 w-24" />
              <Skeleton className="h-10 w-24" />
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (error) {
    return (
      <Alert variant="destructive" className="max-w-4xl mx-auto mt-8">
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>{error}</AlertDescription>
      </Alert>
    );
  }

  if (!examData || !currentQuestion) {
    return (
      <Alert className="max-w-4xl mx-auto mt-8">
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>No exam data available. Please return to dashboard and start a new exam.</AlertDescription>
      </Alert>
    );
  }

  const handleAnswerSelect = (answerId: number) => {
    submitAnswer(currentQuestion.questionId, answerId);
  };

  return (
    <div className="max-w-4xl mx-auto px-4">
      <Card className="overflow-hidden">
        {/* Exam Header */}
        <div className="bg-[#0078D7] text-white p-4 flex justify-between items-center">
          <h2 className="text-xl font-roboto font-bold">Traffic Theory Practice Exam</h2>
          
          {/* Timer Component */}
          <div className="flex items-center bg-white bg-opacity-20 px-3 py-1 rounded-lg">
            <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
            </svg>
            <span className="font-medium">
              {timeRemaining}
            </span>
          </div>
        </div>
        
        {/* Progress Bar */}
        <div className="px-4 pt-4">
          <div className="flex justify-between text-sm mb-2">
            <span>Question <span>{currentQuestionIndex + 1}</span> of {examData.questions.length}</span>
            <span><span>{answeredQuestionsCount}</span> Answered</span>
          </div>
          <div className="w-full bg-[#E0E0E0] rounded-full h-2.5">
            <div 
              className="bg-[#00843D] h-2.5 rounded-full transition-all duration-300" 
              style={{ width: `${(answeredQuestionsCount / examData.questions.length) * 100}%` }}
            ></div>
          </div>
        </div>
        
        {/* Question Content */}
        <div className="p-6">
          <div className="question-container">
            <h3 className="text-lg font-medium mb-4">
              {currentQuestion.question.text}
            </h3>
            
            {/* Image (if applicable) */}
            {currentQuestion.question.imageUrl && (
              <div className="mb-6">
                <img 
                  src={currentQuestion.question.imageUrl} 
                  alt={`Question ${currentQuestionIndex + 1}`} 
                  className="mx-auto max-h-64 rounded-lg shadow" 
                />
              </div>
            )}
            
            {/* Answer Options */}
            <div className="space-y-3 mb-8">
              {currentQuestion.answers.map((answer) => (
                <div
                  key={answer.id}
                  onClick={() => handleAnswerSelect(answer.id)}
                  className={`
                    border rounded-lg p-3 hover:bg-[#F5F5F5] cursor-pointer flex items-center
                    ${currentQuestion.selectedAnswerId === answer.id 
                      ? 'border-[#0078D7] bg-[#0078D7] bg-opacity-5' 
                      : 'border-[#E0E0E0]'
                    }
                  `}
                >
                  <div className={`
                    w-6 h-6 rounded-full flex-shrink-0 flex items-center justify-center mr-3
                    ${currentQuestion.selectedAnswerId === answer.id 
                      ? 'bg-[#0078D7] text-white' 
                      : 'border border-gray-400'
                    }
                  `}>
                    <span className="text-sm font-medium">
                      {String.fromCharCode(65 + currentQuestion.answers.indexOf(answer))}
                    </span>
                  </div>
                  <span>{answer.text}</span>
                </div>
              ))}
            </div>
          </div>
          
          {/* Navigation Buttons */}
          <div className="flex justify-between pt-4 border-t border-[#E0E0E0]">
            <Button 
              variant="outline"
              onClick={previousQuestion}
              disabled={currentQuestionIndex === 0}
              className="border-[#0078D7] text-[#0078D7]"
            >
              Previous
            </Button>
            
            {currentQuestionIndex === examData.questions.length - 1 ? (
              <Button 
                onClick={() => setShowEndExamDialog(true)}
                className="bg-[#00843D]"
              >
                Finish Exam
              </Button>
            ) : (
              <Button 
                onClick={nextQuestion}
                className="bg-[#0078D7]"
              >
                Next
              </Button>
            )}
          </div>
        </div>
      </Card>
      
      {/* Question Navigation */}
      <Card className="mt-6 p-4">
        <QuestionNavigation 
          totalQuestions={examData.questions.length}
          currentQuestionIndex={currentQuestionIndex}
          answeredQuestions={examData.questions.map(q => q.selectedAnswerId !== undefined)}
          onQuestionClick={goToQuestion}
          onEndExam={() => setShowEndExamDialog(true)}
        />
      </Card>

      {/* End Exam Confirmation Dialog */}
      <AlertDialog open={showEndExamDialog} onOpenChange={setShowEndExamDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>End Exam</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to end this exam? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={completeExam}
              className="bg-red-600 hover:bg-red-700"
            >
              End Exam
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default ExamPage;
