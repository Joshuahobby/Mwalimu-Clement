import { useState, useEffect } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Award, Clock, TrendingUp, AlertCircle, CheckCircle, BarChart } from "lucide-react";

interface Stats {
  examsTaken: number;
  avgScore: number;
  passed: number;
  failed: number;
  bestScore: number;
  lastExamDate?: string;
  improvement: number; // percentage points improvement in last 3 exams
}

interface Exam {
  id: number;
  startTime: string;
  endTime?: string;
  isCompleted: boolean;
  score?: number;
  totalQuestions: number;
}

const UserStats = () => {
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchExamHistory = async () => {
      try {
        setLoading(true);
        const response = await fetch('/api/exams/history', {
          credentials: 'include',
        });
        
        if (!response.ok) {
          throw new Error('Failed to fetch exam history');
        }
        
        const data = await response.json();
        
        if (data.exams && Array.isArray(data.exams)) {
          // Calculate stats from exams
          const exams: Exam[] = data.exams;
          const completedExams = exams.filter(exam => exam.isCompleted);
          const examCount = completedExams.length;
          
          if (examCount === 0) {
            setStats({
              examsTaken: 0,
              avgScore: 0,
              passed: 0,
              failed: 0,
              bestScore: 0,
              improvement: 0
            });
          } else {
            // Sort exams by date (newest first)
            const sortedExams = [...completedExams].sort(
              (a, b) => new Date(b.startTime).getTime() - new Date(a.startTime).getTime()
            );
            
            const totalScore = completedExams.reduce((sum, exam) => sum + (exam.score || 0), 0);
            const avgScore = Math.round(totalScore / examCount);
            const passed = completedExams.filter(exam => (exam.score || 0) >= 70).length;
            const bestScore = Math.max(...completedExams.map(exam => exam.score || 0));
            
            // Calculate improvement (difference between avg of last 3 and avg of previous 3)
            let improvement = 0;
            if (examCount >= 3) {
              const recent3 = sortedExams.slice(0, 3);
              const avgRecent = recent3.reduce((sum, exam) => sum + (exam.score || 0), 0) / recent3.length;
              
              if (examCount >= 6) {
                const previous3 = sortedExams.slice(3, 6);
                const avgPrevious = previous3.reduce((sum, exam) => sum + (exam.score || 0), 0) / previous3.length;
                improvement = Math.round(avgRecent - avgPrevious);
              } else {
                improvement = Math.round(avgRecent - avgScore);
              }
            }
            
            setStats({
              examsTaken: examCount,
              avgScore,
              passed,
              failed: examCount - passed,
              bestScore,
              lastExamDate: sortedExams[0]?.endTime,
              improvement
            });
          }
        }
      } catch (error) {
        console.error('Error fetching exam history:', error);
        // Set default stats in case of error
        setStats({
          examsTaken: 0,
          avgScore: 0,
          passed: 0,
          failed: 0,
          bestScore: 0,
          improvement: 0
        });
      } finally {
        setLoading(false);
      }
    };

    fetchExamHistory();
  }, []);

  // Format relative time
  const getRelativeTime = (dateString?: string) => {
    if (!dateString) return 'Never';
    
    const now = new Date();
    const then = new Date(dateString);
    const diffMs = now.getTime() - then.getTime();
    
    const mins = Math.floor(diffMs / 60000);
    const hours = Math.floor(mins / 60);
    const days = Math.floor(hours / 24);
    
    if (days > 0) return days === 1 ? 'Yesterday' : `${days} days ago`;
    if (hours > 0) return hours === 1 ? '1 hour ago' : `${hours} hours ago`;
    if (mins > 0) return mins === 1 ? '1 minute ago' : `${mins} minutes ago`;
    return 'Just now';
  };

  if (loading) {
    return (
      <Card>
        <CardHeader className="border-b pb-3">
          <CardTitle className="text-lg font-roboto font-bold flex items-center">
            <BarChart className="mr-2 h-5 w-5 text-[#0078D7]" />
            Performance Metrics
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-4">
          <div className="grid grid-cols-2 gap-4">
            {Array.from({ length: 4 }).map((_, i) => (
              <Skeleton key={i} className="h-24 w-full rounded-lg" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  const passRate = stats && stats.examsTaken > 0 
    ? Math.round((stats.passed / stats.examsTaken) * 100) 
    : 0;

  return (
    <Card>
      <CardHeader className="border-b pb-3">
        <CardTitle className="text-lg font-roboto font-bold flex items-center">
          <BarChart className="mr-2 h-5 w-5 text-[#0078D7]" />
          Performance Metrics
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-4">
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-4 rounded-lg border border-blue-200">
            <div className="flex justify-between items-start mb-2">
              <div className="text-sm font-medium text-blue-700">Exams Completed</div>
              <div className="bg-blue-600 text-white p-1.5 rounded-full">
                <CheckCircle className="h-4 w-4" />
              </div>
            </div>
            <div className="text-2xl font-bold text-blue-800 mb-1">{stats?.examsTaken || 0}</div>
            <div className="text-xs text-blue-600">
              Last exam: {getRelativeTime(stats?.lastExamDate)}
            </div>
          </div>
          
          <div className="bg-gradient-to-br from-emerald-50 to-emerald-100 p-4 rounded-lg border border-emerald-200">
            <div className="flex justify-between items-start mb-2">
              <div className="text-sm font-medium text-emerald-700">Average Score</div>
              <div className="bg-emerald-600 text-white p-1.5 rounded-full">
                <Award className="h-4 w-4" />
              </div>
            </div>
            <div className="text-2xl font-bold text-emerald-800 mb-1">{stats?.avgScore || 0}%</div>
            <div className="text-xs text-emerald-600">
              Best score: {stats?.bestScore || 0}%
            </div>
          </div>
          
          <div className="bg-gradient-to-br from-amber-50 to-amber-100 p-4 rounded-lg border border-amber-200">
            <div className="flex justify-between items-start mb-2">
              <div className="text-sm font-medium text-amber-700">Pass Rate</div>
              <div className="bg-amber-600 text-white p-1.5 rounded-full">
                <TrendingUp className="h-4 w-4" />
              </div>
            </div>
            <div className="text-2xl font-bold text-amber-800 mb-1">{passRate}%</div>
            <div className="text-xs text-amber-600">
              {stats?.passed || 0} passed | {stats?.failed || 0} failed
            </div>
          </div>
          
          <div className="bg-gradient-to-br from-indigo-50 to-indigo-100 p-4 rounded-lg border border-indigo-200">
            <div className="flex justify-between items-start mb-2">
              <div className="text-sm font-medium text-indigo-700">Recent Trend</div>
              <div className="bg-indigo-600 text-white p-1.5 rounded-full">
                <Clock className="h-4 w-4" />
              </div>
            </div>
            <div className="text-2xl font-bold text-indigo-800 mb-1">
              {stats?.improvement === 0 ? 'Stable' : (
                stats?.improvement && stats.improvement > 0 
                  ? `+${stats.improvement}%` 
                  : `${stats?.improvement || 0}%`
              )}
            </div>
            <div className="text-xs text-indigo-600">
              {stats?.improvement === 0 ? 'Consistent performance' : (
                stats?.improvement && stats.improvement > 0 
                  ? 'Improving! Keep it up!' 
                  : 'Focus on weak areas'
              )}
            </div>
          </div>
        </div>
        
        {!stats?.examsTaken || stats?.examsTaken === 0 ? (
          <div className="mt-4 p-3 rounded-lg border border-dashed border-gray-300 bg-gray-50 text-center">
            <p className="text-sm text-gray-600">
              Take your first exam to begin tracking your performance statistics.
            </p>
          </div>
        ) : null}
      </CardContent>
    </Card>
  );
};

export default UserStats;
