import { useState, useEffect } from "react";
import { useAuth } from "@/context/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import UserStats from "./UserStats";
import ExamHistory from "./ExamHistory";
import PaymentHistory from "./PaymentHistory";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useLocation } from "wouter";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

// Subscription interface
interface Subscription {
  id: number;
  userId: number;
  packageId: number;
  startDate: string;
  endDate: string;
  isActive: boolean;
  transactionId?: string;
}

// Package interface
interface Package {
  id: number;
  name: string;
  type: string;
  price: number;
  duration: number;
  description: string;
}

const UserDashboard = () => {
  const { user, subscription } = useAuth();
  const [packages, setPackages] = useState<Package[]>([]);
  const [loadingPackages, setLoadingPackages] = useState(false);
  const [startingExam, setStartingExam] = useState(false);
  const { toast } = useToast();
  const [, navigate] = useLocation();

  useEffect(() => {
    const fetchPackages = async () => {
      try {
        setLoadingPackages(true);
        const response = await fetch('/api/packages');
        const data = await response.json();
        setPackages(data.packages);
      } catch (error) {
        console.error('Error fetching packages:', error);
        toast({
          title: 'Error',
          description: 'Failed to load packages. Please refresh the page.',
          variant: 'destructive',
        });
      } finally {
        setLoadingPackages(false);
      }
    };

    fetchPackages();
  }, [toast]);

  // Get the active package details
  const activePackage = subscription && packages.length > 0
    ? packages.find(pkg => pkg.id === subscription.packageId)
    : null;

  // Calculate time left for subscription
  const calculateTimeLeft = (): { days: number, hours: number, minutes: number } => {
    if (!subscription || !subscription.endDate) {
      return { days: 0, hours: 0, minutes: 0 };
    }

    const endDate = new Date(subscription.endDate);
    const now = new Date();
    
    if (endDate <= now) {
      return { days: 0, hours: 0, minutes: 0 };
    }

    const diffMs = endDate.getTime() - now.getTime();
    const days = Math.floor(diffMs / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diffMs % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));

    return { days, hours, minutes };
  };

  // Format the end date for display
  const formatEndDate = (): string => {
    if (!subscription || !subscription.endDate) return 'N/A';
    return new Date(subscription.endDate).toLocaleString();
  };

  // Calculate subscription progress percentage
  const calculateProgress = (): number => {
    if (!subscription || !subscription.startDate || !subscription.endDate) {
      return 0;
    }

    const startDate = new Date(subscription.startDate);
    const endDate = new Date(subscription.endDate);
    const now = new Date();

    if (now <= startDate) return 0;
    if (now >= endDate) return 100;

    const totalDuration = endDate.getTime() - startDate.getTime();
    const elapsedDuration = now.getTime() - startDate.getTime();
    
    return Math.min(100, Math.round((elapsedDuration / totalDuration) * 100));
  };

  // Navigate to the exam start page
  const handleStartExam = () => {
    if (!subscription || !subscription.isActive) {
      toast({
        title: 'No Active Subscription',
        description: 'Please purchase a package to start an exam.',
        variant: 'destructive',
      });
      return;
    }

    // Navigate to the exam start page where users review rules before starting
    navigate('/exams/config');
  };

  const timeLeft = calculateTimeLeft();

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-roboto font-bold text-[#0078D7]">My Dashboard</h1>
        <p className="text-gray-600">Welcome back, {user?.fullName}</p>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column - User Info & Package */}
        <div className="space-y-6">
          {/* User Profile Card */}
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center">
                <div className="w-16 h-16 rounded-full bg-[#0078D7] text-white flex items-center justify-center text-2xl font-bold mr-4">
                  {user?.fullName 
                    ? user.fullName.split(' ').map(name => name[0]).join('') 
                    : user?.email 
                      ? user.email.charAt(0).toUpperCase() 
                      : 'U'
                  }
                </div>
                <div>
                  <h2 className="text-xl font-roboto font-bold">{user?.fullName || 'User'}</h2>
                  <p className="text-gray-600">{user?.phoneNumber || 'No phone number'}</p>
                  <p className="text-gray-600">{user?.email}</p>
                </div>
              </div>
              <div className="mt-4 pt-4 border-t border-[#E0E0E0]">
                <Button 
                  variant="link" 
                  className="text-[#0078D7] p-0 h-auto"
                >
                  Edit Profile
                </Button>
              </div>
            </CardContent>
          </Card>
          
          {/* Active Package Card */}
          <Card className="overflow-hidden">
            <CardHeader className="bg-gradient-to-r from-[#0078D7] to-[#005ea8] text-white p-4">
              <div className="flex justify-between items-center">
                <CardTitle className="text-lg font-roboto font-bold">Package Status</CardTitle>
                {subscription && subscription.isActive && (
                  <div className="px-2 py-1 bg-green-500 rounded-full text-xs font-semibold uppercase tracking-wide">
                    Active
                  </div>
                )}
                {subscription && !subscription.isActive && (
                  <div className="px-2 py-1 bg-red-500 rounded-full text-xs font-semibold uppercase tracking-wide">
                    Expired
                  </div>
                )}
              </div>
            </CardHeader>
            <CardContent className="p-0">
              {subscription && activePackage ? (
                <div>
                  <div className="p-5">
                    <div className="flex items-center mb-4">
                      <div className="h-10 w-10 rounded-full bg-[#0078D7] bg-opacity-20 flex items-center justify-center text-[#0078D7] mr-3">
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                      </div>
                      <div>
                        <h3 className="font-bold text-lg">{activePackage.name}</h3>
                        <p className="text-sm text-gray-500">{activePackage.description}</p>
                      </div>
                    </div>

                    <div className="bg-gray-50 p-4 rounded-lg mb-4">
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <p className="text-xs text-gray-500 uppercase">Start Date</p>
                          <p className="text-sm font-medium">
                            {new Date(subscription.startDate).toLocaleDateString()}
                          </p>
                        </div>
                        <div>
                          <p className="text-xs text-gray-500 uppercase">End Date</p>
                          <p className="text-sm font-medium">
                            {new Date(subscription.endDate).toLocaleDateString()}
                          </p>
                        </div>
                        <div>
                          <p className="text-xs text-gray-500 uppercase">Time Remaining</p>
                          <p className="text-sm font-medium">
                            {timeLeft.days > 0 ? (
                              <span className="text-green-600">{timeLeft.days} days</span>
                            ) : timeLeft.hours > 0 ? (
                              <span className="text-yellow-600">{timeLeft.hours} hours</span>
                            ) : (
                              <span className="text-red-600">Expires soon</span>
                            )}
                          </p>
                        </div>
                        <div>
                          <p className="text-xs text-gray-500 uppercase">Package Type</p>
                          <p className="text-sm font-medium capitalize">{activePackage.type}</p>
                        </div>
                      </div>
                    </div>

                    <div className="mb-4">
                      <div className="flex justify-between mb-2">
                        <span className="text-sm font-medium">Subscription progress</span>
                        <span className="text-sm font-medium">{calculateProgress()}%</span>
                      </div>
                      <div className="h-2.5 bg-gray-200 rounded-full overflow-hidden">
                        <div 
                          className={`h-2.5 rounded-full ${
                            calculateProgress() > 75 ? 'bg-yellow-500' : 'bg-[#0078D7]'
                          }`}
                          style={{ width: `${calculateProgress()}%` }}
                        ></div>
                      </div>
                    </div>
                  </div>

                  <div className="border-t border-gray-100 p-5">
                    <Button 
                      onClick={handleStartExam}
                      className={`w-full ${subscription.isActive ? 'bg-[#0078D7]' : 'bg-gray-400'}`}
                      disabled={startingExam || !subscription.isActive}
                    >
                      <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                      </svg>
                      {startingExam ? 'Starting...' : 'Start New Exam'}
                    </Button>

                    {!subscription.isActive && (
                      <div className="mt-3 text-center">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            navigate('/');
                            setTimeout(() => {
                              const packagesSection = document.getElementById('packages');
                              if (packagesSection) {
                                packagesSection.scrollIntoView({ behavior: 'smooth' });
                              }
                            }, 100);
                          }}
                          className="text-[#0078D7] border-[#0078D7]"
                        >
                          Renew Subscription
                        </Button>
                      </div>
                    )}
                  </div>
                </div>
              ) : loadingPackages ? (
                <div className="p-5 space-y-4">
                  <div className="flex items-center">
                    <Skeleton className="h-10 w-10 rounded-full mr-3" />
                    <div className="flex-1">
                      <Skeleton className="h-5 w-3/4 mb-2" />
                      <Skeleton className="h-4 w-1/2" />
                    </div>
                  </div>
                  <Skeleton className="h-32 w-full" />
                  <Skeleton className="h-10 w-full" />
                </div>
              ) : (
                <div className="p-6">
                  <div className="text-center bg-gray-50 rounded-lg p-6">
                    <div className="h-16 w-16 rounded-full bg-gray-200 flex items-center justify-center text-gray-400 mx-auto mb-4">
                      <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                      </svg>
                    </div>
                    <h3 className="text-lg font-medium mb-2">No Active Package</h3>
                    <p className="text-sm text-gray-500 mb-4">
                      You don't have an active package. Purchase a package to start taking exams and track your progress.
                    </p>
                    <Button
                      onClick={() => {
                        navigate('/');
                        setTimeout(() => {
                          const packagesSection = document.getElementById('packages');
                          if (packagesSection) {
                            packagesSection.scrollIntoView({ behavior: 'smooth' });
                          }
                        }, 100);
                      }}
                      className="bg-[#0078D7]"
                    >
                      <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
                      </svg>
                      Purchase a Package
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
          
          {/* Quick Stats Card */}
          <UserStats />
        </div>
        
        {/* Right Column - Tabs for Exam History and Payment History */}
        <div className="lg:col-span-2">
          <Tabs defaultValue="exams" className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-4">
              <TabsTrigger value="exams" className="text-sm">Exam History</TabsTrigger>
              <TabsTrigger value="payments" className="text-sm">Payment History</TabsTrigger>
            </TabsList>
            <TabsContent value="exams" className="mt-0">
              <ExamHistory onStartExam={handleStartExam} startingExam={startingExam} />
            </TabsContent>
            <TabsContent value="payments" className="mt-0">
              <PaymentHistory />
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
};

export default UserDashboard;
