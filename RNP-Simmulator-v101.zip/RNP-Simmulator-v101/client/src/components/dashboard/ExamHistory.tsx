import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { CheckCircle, AlertCircle, Clock, ExternalLink, BarChart } from "lucide-react";

interface Exam {
  id: number;
  startTime: string;
  endTime?: string;
  isCompleted: boolean;
  score?: number;
  totalQuestions: number;
}

interface ExamHistoryProps {
  onStartExam: () => void;
  startingExam: boolean;
}

const ExamHistory = ({ onStartExam, startingExam }: ExamHistoryProps) => {
  const [exams, setExams] = useState<Exam[]>([]);
  const [loading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState<'list' | 'card'>('card');
  const { toast } = useToast();

  useEffect(() => {
    const fetchExamHistory = async () => {
      try {
        setLoading(true);
        const response = await fetch('/api/exams/history', {
          credentials: 'include',
        });
        
        if (!response.ok) {
          throw new Error('Failed to fetch exam history');
        }
        
        const data = await response.json();
        setExams(data.exams || []);
      } catch (error) {
        console.error('Error fetching exam history:', error);
        toast({
          title: 'Error',
          description: 'Failed to load your exam history.',
          variant: 'destructive',
        });
      } finally {
        setLoading(false);
      }
    };

    fetchExamHistory();
  }, [toast]);

  // Format date for display
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  // Calculate time spent on exam
  const calculateTimeSpent = (exam: Exam) => {
    if (!exam.endTime || !exam.isCompleted) return 'Incomplete';
    
    const start = new Date(exam.startTime);
    const end = new Date(exam.endTime);
    const diffMs = end.getTime() - start.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffSecs = Math.floor((diffMs % 60000) / 1000);
    
    return `${diffMins}m ${diffSecs}s`;
  };

  // Get how long ago the exam was taken
  const getTimeAgo = (dateString: string) => {
    const now = new Date();
    const then = new Date(dateString);
    const diffMs = now.getTime() - then.getTime();
    
    const mins = Math.floor(diffMs / 60000);
    const hours = Math.floor(mins / 60);
    const days = Math.floor(hours / 24);
    
    if (days > 0) return days === 1 ? '1 day ago' : `${days} days ago`;
    if (hours > 0) return hours === 1 ? '1 hour ago' : `${hours} hours ago`;
    if (mins > 0) return mins === 1 ? '1 minute ago' : `${mins} minutes ago`;
    return 'Just now';
  };

  // Get summary stats
  const getStats = () => {
    const completed = exams.filter(exam => exam.isCompleted);
    const passed = completed.filter(exam => exam.score && exam.score >= 70);
    const averageScore = completed.length > 0 
      ? completed.reduce((acc, exam) => acc + (exam.score || 0), 0) / completed.length 
      : 0;
    
    return {
      total: exams.length,
      completed: completed.length,
      passed: passed.length,
      averageScore: Math.round(averageScore)
    };
  };

  const stats = getStats();

  return (
    <Card className="h-full flex flex-col">
      <CardHeader className="border-b">
        <div className="flex justify-between items-center">
          <CardTitle className="text-lg font-roboto font-bold flex items-center">
            <BarChart className="mr-2 h-5 w-5 text-[#0078D7]" />
            Exam History
          </CardTitle>
          {exams.length > 0 && (
            <div className="flex space-x-2">
              <Button 
                size="sm" 
                variant={viewMode === 'card' ? 'default' : 'outline'}
                className={viewMode === 'card' ? 'bg-[#0078D7]' : 'border-[#0078D7] text-[#0078D7]'}
                onClick={() => setViewMode('card')}
              >
                Cards
              </Button>
              <Button 
                size="sm" 
                variant={viewMode === 'list' ? 'default' : 'outline'} 
                className={viewMode === 'list' ? 'bg-[#0078D7]' : 'border-[#0078D7] text-[#0078D7]'}
                onClick={() => setViewMode('list')}
              >
                List
              </Button>
            </div>
          )}
        </div>
      </CardHeader>
      
      {exams.length > 0 && (
        <div className="border-b px-6 py-3 bg-gray-50">
          <div className="flex flex-wrap gap-4 md:gap-6 text-sm">
            <div>
              <span className="text-gray-500">Total exams:</span>
              <span className="ml-1 font-medium">{stats.total}</span>
            </div>
            <div>
              <span className="text-gray-500">Completed:</span>
              <span className="ml-1 font-medium">{stats.completed}</span>
            </div>
            <div>
              <span className="text-gray-500">Pass rate:</span>
              <span className="ml-1 font-medium">
                {stats.completed > 0 ? `${Math.round((stats.passed / stats.completed) * 100)}%` : '0%'}
              </span>
            </div>
            <div>
              <span className="text-gray-500">Average score:</span>
              <span className="ml-1 font-medium">{stats.averageScore}%</span>
            </div>
          </div>
        </div>
      )}
      
      <CardContent className="flex-grow flex flex-col pt-6">
        {loading ? (
          <div className="space-y-4 flex-grow">
            {Array.from({ length: 3 }).map((_, i) => (
              <Skeleton key={i} className="h-24 w-full rounded-lg" />
            ))}
          </div>
        ) : exams.length > 0 ? (
          viewMode === 'list' ? (
            // List view
            <div className="overflow-x-auto flex-grow">
              <table className="min-w-full">
                <thead>
                  <tr className="bg-[#F5F5F5]">
                    <th className="py-3 px-4 text-left text-xs font-medium text-gray-600 uppercase tracking-wider rounded-tl-lg">Date</th>
                    <th className="py-3 px-4 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">Score</th>
                    <th className="py-3 px-4 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">Time Spent</th>
                    <th className="py-3 px-4 text-left text-xs font-medium text-gray-600 uppercase tracking-wider">Status</th>
                    <th className="py-3 px-4 text-left text-xs font-medium text-gray-600 uppercase tracking-wider rounded-tr-lg">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#E0E0E0]">
                  {exams.slice(0, 5).map((exam) => (
                    <tr key={exam.id} className="hover:bg-gray-50">
                      <td className="py-3 px-4">
                        <div>
                          <div className="font-medium">{formatDate(exam.startTime)}</div>
                          <div className="text-xs text-gray-500">{getTimeAgo(exam.startTime)}</div>
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        {exam.isCompleted ? (
                          <div className="flex items-center">
                            <span className={`font-medium ${
                              exam.score && exam.score >= 70 
                                ? 'text-green-600' 
                                : 'text-red-600'
                            }`}>
                              {exam.score ? `${exam.score}%` : 'N/A'}
                            </span>
                            <span className="ml-2 text-xs text-gray-600">
                              ({exam.score ? `${Math.round((exam.score / 100) * exam.totalQuestions)}/${exam.totalQuestions}` : 'N/A'})
                            </span>
                          </div>
                        ) : (
                          <span className="text-gray-500">Incomplete</span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-sm">{calculateTimeSpent(exam)}</td>
                      <td className="py-3 px-4">
                        {exam.isCompleted ? (
                          exam.score && exam.score >= 70 ? (
                            <Badge className="bg-green-100 text-green-800 hover:bg-green-200 flex items-center space-x-1">
                              <CheckCircle className="h-3 w-3" />
                              <span>Passed</span>
                            </Badge>
                          ) : (
                            <Badge className="bg-red-100 text-red-800 hover:bg-red-200 flex items-center space-x-1">
                              <AlertCircle className="h-3 w-3" />
                              <span>Failed</span>
                            </Badge>
                          )
                        ) : (
                          <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-200 flex items-center space-x-1">
                            <Clock className="h-3 w-3" />
                            <span>Incomplete</span>
                          </Badge>
                        )}
                      </td>
                      <td className="py-3 px-4">
                        {exam.isCompleted ? (
                          <Link href={`/exam/${exam.id}/results`}>
                            <Button variant="link" className="text-[#0078D7] p-0 h-auto flex items-center">
                              <span>Review</span>
                              <ExternalLink className="h-3 w-3 ml-1" />
                            </Button>
                          </Link>
                        ) : (
                          <Link href={`/exam/${exam.id}`}>
                            <Button variant="link" className="text-[#0078D7] p-0 h-auto">Continue</Button>
                          </Link>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            // Card view
            <div className="grid grid-cols-1 gap-4 flex-grow">
              {exams.slice(0, 5).map((exam) => (
                <div key={exam.id} className="bg-white border rounded-lg shadow-sm overflow-hidden">
                  <div className={`px-4 py-3 flex justify-between items-center border-b ${
                    exam.isCompleted 
                      ? exam.score && exam.score >= 70
                        ? 'bg-green-50 border-green-100'
                        : 'bg-red-50 border-red-100'
                      : 'bg-yellow-50 border-yellow-100'
                  }`}>
                    <div className="flex items-center">
                      {exam.isCompleted ? (
                        exam.score && exam.score >= 70 ? (
                          <CheckCircle className="h-4 w-4 text-green-600 mr-2" />
                        ) : (
                          <AlertCircle className="h-4 w-4 text-red-600 mr-2" />
                        )
                      ) : (
                        <Clock className="h-4 w-4 text-yellow-600 mr-2" />
                      )}
                      <h3 className="font-medium">
                        {exam.isCompleted 
                          ? exam.score && exam.score >= 70
                            ? 'Exam Passed'
                            : 'Exam Failed'
                          : 'Exam In Progress'
                        }
                      </h3>
                    </div>
                    <div>
                      {exam.isCompleted ? (
                        exam.score && exam.score >= 70 ? (
                          <Badge className="bg-green-100 text-green-800 hover:bg-green-200">Passed</Badge>
                        ) : (
                          <Badge className="bg-red-100 text-red-800 hover:bg-red-200">Failed</Badge>
                        )
                      ) : (
                        <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-200">Incomplete</Badge>
                      )}
                    </div>
                  </div>
                  
                  <div className="p-4">
                    <div className="grid grid-cols-2 gap-4 mb-4">
                      <div>
                        <p className="text-xs text-gray-500 uppercase">Date</p>
                        <p className="text-sm font-medium">{formatDate(exam.startTime)}</p>
                        <p className="text-xs text-gray-500">{getTimeAgo(exam.startTime)}</p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-500 uppercase">Time Spent</p>
                        <p className="text-sm font-medium">{calculateTimeSpent(exam)}</p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-500 uppercase">Score</p>
                        <p className={`text-sm font-medium ${
                          exam.isCompleted
                            ? exam.score && exam.score >= 70
                              ? 'text-green-600'
                              : 'text-red-600'
                            : 'text-gray-500'
                        }`}>
                          {exam.isCompleted
                            ? exam.score ? `${exam.score}%` : 'N/A'
                            : 'Incomplete'
                          }
                        </p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-500 uppercase">Questions</p>
                        <p className="text-sm font-medium">
                          {exam.isCompleted && exam.score
                            ? `${Math.round((exam.score / 100) * exam.totalQuestions)}/${exam.totalQuestions} correct`
                            : `${exam.totalQuestions} questions`
                          }
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex justify-end">
                      {exam.isCompleted ? (
                        <Link href={`/exam/${exam.id}/results`}>
                          <Button size="sm" variant="outline" className="text-[#0078D7] border-[#0078D7]">
                            View Results
                          </Button>
                        </Link>
                      ) : (
                        <Link href={`/exam/${exam.id}`}>
                          <Button size="sm" className="bg-[#0078D7]">Continue Exam</Button>
                        </Link>
                      )}
                    </div>
                  </div>
                </div>
              ))}
              
              {exams.length > 5 && (
                <Button variant="link" className="text-[#0078D7] mx-auto mt-2">
                  View All Exams ({exams.length})
                </Button>
              )}
            </div>
          )
        ) : (
          <div className="text-center py-8 flex-grow flex flex-col items-center justify-center">
            <div className="rounded-full bg-gray-100 p-6 mb-4 inline-block">
              <BarChart className="h-8 w-8 text-gray-400" />
            </div>
            <h3 className="text-lg font-medium mb-2">No Exam History</h3>
            <p className="text-gray-500 mb-6 max-w-md">
              You haven't taken any exams yet. Start your first exam to begin tracking your progress and improvement.
            </p>
          </div>
        )}
        
        <div className="mt-auto pt-6">
          <Button 
            onClick={onStartExam}
            className="w-full py-6 bg-[#0078D7] text-base font-medium"
            disabled={startingExam}
          >
            <>
              <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
              </svg>
              Start New Exam
            </>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default ExamHistory;
