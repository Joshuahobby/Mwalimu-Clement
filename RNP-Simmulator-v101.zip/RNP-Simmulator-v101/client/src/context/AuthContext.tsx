import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { 
  loginUser, 
  registerUser as firebaseRegister, 
  logoutUser, 
  getCurrentUser, 
  onAuthStateChange,
  signInWithGoogle as firebaseSignInWithGoogle
} from "@/lib/firebase";
import { apiRequest } from "@/lib/queryClient";
import { toast } from "@/hooks/use-toast";
import type { User as FirebaseUser } from "firebase/auth";

interface User {
  id: number;
  email: string;
  firebaseUid: string;
  fullName?: string;
  phoneNumber?: string;
  role?: string;
}

interface Subscription {
  id: number;
  userId: number;
  packageId: number;
  startDate: string;
  endDate: string;
  isActive: boolean;
  transactionId?: string;
}

// Temporary social auth data for two-step registration process
export interface SocialAuthData {
  email: string;
  fullName?: string;
  uid: string;
  providerId: string;
}

interface AuthContextType {
  user: User | null;
  firebaseUser: FirebaseUser | null;
  subscription: Subscription | null;
  isLoading: boolean;
  isSubmitting: boolean;              // Regular form submission loading state
  isSocialSubmitting: boolean;        // Social login loading state
  pendingSocialAuthData: SocialAuthData | null; // Temporary data during social auth flow
  isAuthenticated: boolean;
  isAdmin: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (userData: RegisterData) => Promise<void>;
  logout: () => Promise<void>;
  socialLogin: () => Promise<SocialAuthData>; // Step 1: Get Google credentials
  completeSocialLogin: (phoneNumber: string) => Promise<void>; // Step 2: Send to backend with phone
  checkAuthStatus: () => Promise<void>;
  resetPendingSocialAuth: () => void; // Clear pending social auth data
}

interface RegisterData {
  email: string;
  password: string;
  confirmPassword: string;
  fullName?: string;
  phoneNumber?: string;
}

interface AuthProviderProps {
  children: ReactNode;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: AuthProviderProps) {
  const [user, setUser] = useState<User | null>(null);
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [subscription, setSubscription] = useState<Subscription | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSocialSubmitting, setIsSocialSubmitting] = useState(false);
  const [pendingSocialAuthData, setPendingSocialAuthData] = useState<SocialAuthData | null>(null);

  // Function to check auth status and get user data
  const fetchUserData = async (fbUser: FirebaseUser | null) => {
    if (fbUser) {
      try {
        // If Firebase user exists, fetch the user data from our backend
        const userData = await apiRequest<User>("GET", "/api/auth/me");
        setUser(userData);
        
        // Fetch active subscription if the user exists
        if (userData) {
          try {
            const subscriptionData = await apiRequest<Subscription>("GET", "/api/subscriptions/active");
            setSubscription(subscriptionData);
          } catch (error) {
            console.error("Error fetching subscription data:", error);
            setSubscription(null);
          }
        }
        
        return userData;
      } catch (error) {
        console.error("Error fetching user data:", error);
        setUser(null);
        setSubscription(null);
      }
    } else {
      setUser(null);
      setSubscription(null);
    }
    return null;
  };

  // Listen to Firebase auth state changes
  useEffect(() => {
    const unsubscribe = onAuthStateChange(async (fbUser) => {
      setFirebaseUser(fbUser);
      await fetchUserData(fbUser);
      setIsLoading(false);
    });

    // Cleanup subscription
    return () => unsubscribe();
  }, []);

  // Function to manually check auth status
  const checkAuthStatus = async () => {
    const fbUser = getCurrentUser();
    setFirebaseUser(fbUser);
    await fetchUserData(fbUser);
  };

  // Login function
  const login = async (email: string, password: string) => {
    try {
      setIsSubmitting(true);
      setIsLoading(true);
      const fbUser = await loginUser(email, password);
      
      // Get user from backend
      await fetchUserData(fbUser);
      
      toast({
        title: "Login successful",
        description: "You have been logged in successfully",
      });
      
      // No need to redirect here as it's handled in the LoginModal component
    } catch (error: any) {
      console.error("Login error:", error);
      toast({
        title: "Login failed",
        description: error.message || "Failed to login. Please try again.",
        variant: "destructive",
      });
      throw error;
    } finally {
      setIsLoading(false);
      setIsSubmitting(false);
    }
  };

  // Register function
  const register = async (userData: RegisterData) => {
    try {
      setIsSubmitting(true);
      setIsLoading(true);
      
      // First create the Firebase user
      const fbUser = await firebaseRegister(userData.email, userData.password);
      
      // Then create the user in our backend
      await apiRequest("POST", "/api/auth/register", {
        email: userData.email,
        password: userData.password,
        confirmPassword: userData.confirmPassword,
        fullName: userData.fullName,
        phoneNumber: userData.phoneNumber,
        firebaseUid: fbUser.uid
      });
      
      // Get the user data
      await fetchUserData(fbUser);
      
      toast({
        title: "Registration successful",
        description: "Your account has been created successfully",
      });
    } catch (error: any) {
      console.error("Registration error:", error);
      
      // Get a more specific error message for Firebase errors
      let errorMessage = "Failed to register. Please try again.";
      
      if (error && typeof error === 'object' && 'code' in error) {
        const firebaseError = error as { code: string; message?: string };
        if (firebaseError.code === 'auth/email-already-in-use') {
          errorMessage = 'This email is already registered. Please try logging in instead.';
        } else {
          errorMessage = firebaseError.message || errorMessage;
        }
      } else if (error instanceof Error) {
        errorMessage = error.message;
      }
      
      toast({
        title: "Registration failed",
        description: errorMessage,
        variant: "destructive",
      });
      throw error;
    } finally {
      setIsLoading(false);
      setIsSubmitting(false);
    }
  };

  // Step 1: Get Google credentials
  const socialLogin = async (): Promise<SocialAuthData> => {
    try {
      setIsSocialSubmitting(true);
      setIsLoading(true);
      
      // Sign in with Google to get Firebase credentials
      const { user: googleUser } = await firebaseSignInWithGoogle();
      
      if (!googleUser || !googleUser.email) {
        throw new Error("Failed to get user email from Google login");
      }
      
      // Check if user already exists
      try {
        // Try a direct login attempt first
        const response = await fetch("/api/auth/social-login", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          credentials: "include",
          body: JSON.stringify({
            fullName: googleUser.displayName || "Google User",
            email: googleUser.email,
            phoneNumber: googleUser.phoneNumber || "", // This will likely fail if no phone number
            providerId: "google.com",
            uid: googleUser.uid
          }),
        });
        
        if (response.ok) {
          // User exists and has phone number, login successful
          await checkAuthStatus();
          toast({
            title: "Login Successful",
            description: "You have been logged in successfully with Google",
          });
          return {} as SocialAuthData; // Empty object as we're already logged in
        }
        
        // If we get here, user needs to add a phone number
        const errorData = await response.json();
        console.log("Social login response:", errorData);
        
        if (errorData.message && errorData.message.includes("phone number")) {
          // Save temporary auth data for the next step
          const socialAuthData: SocialAuthData = {
            email: googleUser.email,
            fullName: googleUser.displayName || undefined,
            uid: googleUser.uid,
            providerId: "google.com"
          };
          
          setPendingSocialAuthData(socialAuthData);
          return socialAuthData;
        }
        
        // For other errors, throw to be caught below
        throw new Error(errorData.message || "Failed to authenticate");
      } catch (error: any) {
        // If it's not our phone number validation error, rethrow
        if (!pendingSocialAuthData) {
          throw error;
        }
        return pendingSocialAuthData;
      }
    } catch (error: any) {
      console.error("Social login error:", error);
      toast({
        title: "Social login failed",
        description: error.message || "Failed to login with Google. Please try again.",
        variant: "destructive",
      });
      throw error;
    } finally {
      setIsLoading(false);
      setIsSocialSubmitting(false);
    }
  };
  
  // Step 2: Complete social login with phone number
  const completeSocialLogin = async (phoneNumber: string): Promise<void> => {
    if (!pendingSocialAuthData) {
      throw new Error("No pending social authentication data. Please try again.");
    }
    
    try {
      setIsSocialSubmitting(true);
      setIsLoading(true);
      
      // Send the Google user data with phone number to our backend
      const response = await fetch("/api/auth/social-login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include",
        body: JSON.stringify({
          fullName: pendingSocialAuthData.fullName || "Google User",
          email: pendingSocialAuthData.email,
          phoneNumber: phoneNumber,
          providerId: pendingSocialAuthData.providerId,
          uid: pendingSocialAuthData.uid
        }),
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to complete registration");
      }
      
      // Refresh user data after successful login
      await checkAuthStatus();
      
      // Clear pending data
      setPendingSocialAuthData(null);
      
      toast({
        title: "Registration Successful",
        description: "Your account has been created successfully",
      });
    } catch (error: any) {
      console.error("Social login completion error:", error);
      toast({
        title: "Registration failed",
        description: error.message || "Failed to complete registration. Please try again.",
        variant: "destructive",
      });
      throw error;
    } finally {
      setIsLoading(false);
      setIsSocialSubmitting(false);
    }
  };
  
  // Reset pending social auth data
  const resetPendingSocialAuth = () => {
    setPendingSocialAuthData(null);
  };

  // Logout function
  const logout = async () => {
    try {
      setIsLoading(true);
      await logoutUser();
      await apiRequest("POST", "/api/auth/logout");
      setUser(null);
      
      toast({
        title: "Logout successful",
        description: "You have been logged out successfully",
      });
    } catch (error: any) {
      console.error("Logout error:", error);
      toast({
        title: "Logout failed",
        description: error.message || "Failed to logout. Please try again.",
        variant: "destructive",
      });
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const value = {
    user,
    firebaseUser,
    subscription,
    isLoading,
    isSubmitting,
    isSocialSubmitting,
    pendingSocialAuthData,
    isAuthenticated: !!user,
    isAdmin: !!user && user.role === 'admin',
    login,
    register,
    logout,
    socialLogin,
    completeSocialLogin,
    resetPendingSocialAuth,
    checkAuthStatus,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

// Export the hook
export function useAuth() {
  const context = useContext(AuthContext);
  
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  
  return context;
}