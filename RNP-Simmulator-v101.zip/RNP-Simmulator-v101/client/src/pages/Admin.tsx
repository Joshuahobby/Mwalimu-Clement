import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/context/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import AdminDashboard from "@/components/admin/AdminDashboard";
import UserManagement from "@/components/admin/UserManagement";
import QuestionManagement from "@/components/admin/QuestionManagement";
import PaymentManagement from "@/components/admin/PaymentManagement";
import ReportsDashboard from "@/components/admin/ReportsDashboard";
import ExamManagement from "@/components/admin/ExamManagement";
import { 
  LayoutDashboard, Users, HelpCircle, CreditCard, BarChart2, 
  Settings, LogOut, Search, FileText, ClipboardList
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

const Admin = () => {
  const { isAuthenticated, isAdmin, user, logout } = useAuth();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("dashboard");

  // Check if user is authenticated and is an admin
  useEffect(() => {
    if (!isAuthenticated) {
      toast({
        title: "Authentication Required",
        description: "Please log in to access the admin panel.",
        variant: "destructive",
      });
      navigate("/");
      return;
    }

    if (!isAdmin) {
      toast({
        title: "Access Denied",
        description: "You don't have permission to access the admin panel.",
        variant: "destructive",
      });
      navigate("/dashboard");
      return;
    }
  }, [isAuthenticated, isAdmin, navigate, toast]);

  if (!isAuthenticated || !isAdmin) {
    return null; // Don't render anything while redirecting
  }

  const handleLogout = async () => {
    await logout();
    navigate("/");
  };

  return (
    <div className="bg-[#F5F5F5] min-h-screen flex">
      {/* Sidebar */}
      <div className="w-64 bg-[#0078D7] text-white min-h-screen">
        <div className="p-4 border-b border-white border-opacity-20">
          <div className="flex items-center space-x-2">
            <div className="w-10 h-10 rounded-full flex items-center justify-center bg-white text-[#0078D7] font-bold">
              MC
            </div>
            <div>
              <h1 className="font-roboto font-bold">MWALIMU Clement</h1>
              <p className="text-xs opacity-80">Admin Panel</p>
            </div>
          </div>
        </div>
        
        <nav className="mt-6">
          <button 
            onClick={() => setActiveTab("dashboard")}
            className={`flex items-center px-4 py-3 w-full text-left ${
              activeTab === "dashboard" ? "bg-white bg-opacity-10" : "hover:bg-white hover:bg-opacity-10"
            }`}
          >
            <LayoutDashboard className="w-5 h-5 mr-3" />
            <span>Dashboard</span>
          </button>
          
          <button 
            onClick={() => setActiveTab("users")}
            className={`flex items-center px-4 py-3 w-full text-left ${
              activeTab === "users" ? "bg-white bg-opacity-10" : "hover:bg-white hover:bg-opacity-10"
            }`}
          >
            <Users className="w-5 h-5 mr-3" />
            <span>Users</span>
          </button>
          
          <button 
            onClick={() => setActiveTab("questions")}
            className={`flex items-center px-4 py-3 w-full text-left ${
              activeTab === "questions" ? "bg-white bg-opacity-10" : "hover:bg-white hover:bg-opacity-10"
            }`}
          >
            <HelpCircle className="w-5 h-5 mr-3" />
            <span>Questions</span>
          </button>
          
          <button 
            onClick={() => setActiveTab("exams")}
            className={`flex items-center px-4 py-3 w-full text-left ${
              activeTab === "exams" ? "bg-white bg-opacity-10" : "hover:bg-white hover:bg-opacity-10"
            }`}
          >
            <ClipboardList className="w-5 h-5 mr-3" />
            <span>Exams</span>
          </button>
          
          <button 
            onClick={() => setActiveTab("payments")}
            className={`flex items-center px-4 py-3 w-full text-left ${
              activeTab === "payments" ? "bg-white bg-opacity-10" : "hover:bg-white hover:bg-opacity-10"
            }`}
          >
            <CreditCard className="w-5 h-5 mr-3" />
            <span>Payments</span>
          </button>
          
          <button 
            onClick={() => setActiveTab("reports")}
            className={`flex items-center px-4 py-3 w-full text-left ${
              activeTab === "reports" ? "bg-white bg-opacity-10" : "hover:bg-white hover:bg-opacity-10"
            }`}
          >
            <BarChart2 className="w-5 h-5 mr-3" />
            <span>Reports</span>
          </button>
          
          <button 
            onClick={() => setActiveTab("settings")}
            className={`flex items-center px-4 py-3 w-full text-left ${
              activeTab === "settings" ? "bg-white bg-opacity-10" : "hover:bg-white hover:bg-opacity-10"
            }`}
          >
            <Settings className="w-5 h-5 mr-3" />
            <span>Settings</span>
          </button>

          <div className="mt-10 px-4">
            <Button
              variant="outline"
              onClick={handleLogout}
              className="flex items-center w-full border-white text-white hover:bg-white hover:bg-opacity-10"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </nav>
      </div>
      
      {/* Main Content */}
      <div className="flex-1 p-8">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-2xl font-roboto font-bold text-[#333333]">
            {activeTab === "dashboard" && "Admin Dashboard"}
            {activeTab === "users" && "User Management"}
            {activeTab === "questions" && "Question Management"}
            {activeTab === "exams" && "Exam Management"}
            {activeTab === "payments" && "Payment Management"}
            {activeTab === "reports" && "Reports & Analytics"}
            {activeTab === "settings" && "System Settings"}
          </h1>
          <div className="flex items-center space-x-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 h-4 w-4" />
              <Input 
                type="text" 
                placeholder="Search..." 
                className="pl-10"
              />
            </div>
            <div className="flex items-center gap-2">
              <div className="text-sm text-right">
                <p className="font-medium">{user?.fullName}</p>
                <p className="text-xs text-gray-500">{user?.role}</p>
              </div>
              <div className="w-8 h-8 rounded-full bg-[#0078D7] text-white flex items-center justify-center text-xs font-bold">
                {user?.fullName ? user.fullName.split(' ').map(name => name[0]).join('') : user?.email?.[0].toUpperCase()}
              </div>
            </div>
          </div>
        </div>
        
        {/* Tab Content */}
        <div>
          {activeTab === "dashboard" && <AdminDashboard />}
          {activeTab === "users" && <UserManagement />}
          {activeTab === "questions" && <QuestionManagement />}
          {activeTab === "exams" && <ExamManagement />}
          {activeTab === "payments" && <PaymentManagement />}
          {activeTab === "reports" && <ReportsDashboard />}
          {activeTab === "settings" && (
            <div className="rounded-lg bg-white p-6 shadow-md">
              <h2 className="text-xl font-bold mb-4">System Settings</h2>
              <p className="text-gray-500">Settings functionality will be implemented in future updates.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Admin;
