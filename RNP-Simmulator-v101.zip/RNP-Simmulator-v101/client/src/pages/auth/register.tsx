import { Helmet } from "react-helmet";
import AuthContainer from "@/components/auth/auth-container";
import RegisterForm from "@/components/auth/register-form";
import FirebaseStatus from "@/components/auth/firebase-status";

export default function Register() {
  return (
    <>
      <Helmet>
        <title>Register | User Authentication</title>
      </Helmet>
      <div className="bg-gray-100 min-h-screen flex flex-col items-center justify-center p-4">
        <AuthContainer
          title="Create your account"
          subtitle="Join our platform to get started"
          altLink={{
            text: "Already have an account?",
            linkText: "Sign in",
            href: "/login"
          }}
        >
          <RegisterForm />
        </AuthContainer>
        <FirebaseStatus />
      </div>
    </>
  );
}
