import { useEffect, useState } from "react";
import { useLocation, useRoute } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";

const PaymentCallback = () => {
  const [, navigate] = useLocation();
  const [, params] = useRoute("/payment/callback");
  const { toast } = useToast();
  const [status, setStatus] = useState<"loading" | "success" | "error" | "retryable-error">("loading");
  const [paymentData, setPaymentData] = useState<any>(null);
  const [errorMessage, setErrorMessage] = useState<string>("");
  const [isRetrying, setIsRetrying] = useState<boolean>(false);

  useEffect(() => {
    const verifyPayment = async () => {
      try {
        // Get the transaction_id and tx_ref from URL params
        const urlParams = new URLSearchParams(window.location.search);
        const transaction_id = urlParams.get("transaction_id");
        const tx_ref = urlParams.get("tx_ref");
        const status = urlParams.get("status");

        if (!transaction_id || !tx_ref) {
          throw new Error("Missing transaction details in the URL");
        }

        // Handle failed payment
        if (status === "cancelled" || status === "failed") {
          toast({
            title: "Payment Cancelled",
            description: "You've cancelled the payment or the payment failed.",
          });
          setStatus("error");
          return;
        }

        // Get package_id from sessionStorage if available
        let package_id = sessionStorage.getItem('fw_payment_package_id');
        
        // If package_id is not in sessionStorage, try to extract from tx_ref
        // Format: tx-timestamp-random-packageId
        if (!package_id && tx_ref && tx_ref.includes('-')) {
          const parts = tx_ref.split('-');
          if (parts.length >= 4) {
            // The package ID should be the last part
            const possiblePackageId = parts[parts.length - 1];
            if (/^\d+$/.test(possiblePackageId)) {
              package_id = possiblePackageId;
              console.log("Extracted package_id from tx_ref:", package_id);
            }
          }
        }
        
        // Log payment details for debugging
        console.log("Payment callback params:", {
          transaction_id,
          tx_ref,
          package_id,
          amount: urlParams.get("amount"),
          currency: urlParams.get("currency") || "RWF"
        });
        
        // Verify the payment with our backend
        const response = await fetch("/api/payments/verify", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          credentials: "include",
          body: JSON.stringify({
            transaction_id,
            tx_ref,
            package_id: package_id ? parseInt(package_id) : undefined,
            amount: urlParams.get("amount"),
            currency: urlParams.get("currency") || "RWF"
          })
        });

        if (!response.ok) {
          throw new Error(`Server returned ${response.status}: ${await response.text()}`);
        }
        
        const data = await response.json();
        console.log("Payment verification response:", data);
        setPaymentData(data);

        if (data.success) {
          setStatus("success");
          toast({
            title: "Payment Successful",
            description: `Your subscription has been activated successfully.`,
          });

          // Invalidate queries to refresh user data
          queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
        } else {
          throw new Error(data.message || "Payment verification failed");
        }
      } catch (error) {
        console.error("Payment verification error:", error);
        
        // Set error message for display
        const errorMsg = error instanceof Error ? error.message : "Unknown error occurred";
        setErrorMessage(errorMsg);
        
        // Determine if error is retryable (network error or server error, not validation error)
        const isNetworkOrServerError = 
          !errorMsg.includes("Missing transaction details") && 
          !errorMsg.includes("cancelled") && 
          !errorMsg.includes("failed") &&
          (errorMsg.includes("fetch") || errorMsg.includes("network") || 
           errorMsg.includes("timeout") || errorMsg.includes("Server returned"));
        
        if (isNetworkOrServerError) {
          setStatus("retryable-error");
        } else {
          setStatus("error");
        }
        
        toast({
          title: "Payment Verification Failed",
          description: errorMsg,
          variant: "destructive",
        });
      }
    };

    verifyPayment();
  }, [toast]);

  const handleGoToDashboard = () => {
    navigate("/dashboard");
  };
  
  const handleRetry = async () => {
    setIsRetrying(true);
    try {
      // Get the transaction_id and tx_ref from URL params
      const urlParams = new URLSearchParams(window.location.search);
      const transaction_id = urlParams.get("transaction_id");
      const tx_ref = urlParams.get("tx_ref");
      let package_id = sessionStorage.getItem('fw_payment_package_id');
      
      // Extract package_id from tx_ref if needed
      if (!package_id && tx_ref && tx_ref.includes('-')) {
        const parts = tx_ref.split('-');
        if (parts.length >= 4) {
          const possiblePackageId = parts[parts.length - 1];
          if (/^\d+$/.test(possiblePackageId)) {
            package_id = possiblePackageId;
          }
        }
      }
      
      if (!transaction_id || !tx_ref) {
        throw new Error("Missing transaction details for retry");
      }
      
      // Set loading state before retry
      setStatus("loading");
      
      // Retry verification
      const response = await fetch("/api/payments/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({
          transaction_id,
          tx_ref,
          package_id: package_id ? parseInt(package_id) : undefined,
          amount: urlParams.get("amount"),
          currency: urlParams.get("currency") || "RWF"
        })
      });
      
      if (!response.ok) {
        throw new Error(`Server returned ${response.status}: ${await response.text()}`);
      }
      
      const data = await response.json();
      setPaymentData(data);
      
      if (data.success) {
        setStatus("success");
        toast({
          title: "Payment Verification Successful",
          description: "We've successfully verified your payment on retry.",
        });
        
        // Invalidate queries to refresh user data
        queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
      } else {
        throw new Error(data.message || "Payment verification failed on retry");
      }
    } catch (error) {
      console.error("Retry payment verification error:", error);
      const errorMsg = error instanceof Error ? error.message : "Unknown error on retry";
      setErrorMessage(errorMsg);
      setStatus("error");
      toast({
        title: "Retry Failed",
        description: errorMsg,
        variant: "destructive",
      });
    } finally {
      setIsRetrying(false);
    }
  };

  const renderContent = () => {
    switch (status) {
      case "loading":
        return (
          <div className="flex flex-col items-center justify-center py-12">
            <Loader2 className="h-12 w-12 animate-spin text-[#0078D7] mb-4" />
            <h2 className="text-xl font-semibold mb-2">Verifying Your Payment</h2>
            <p className="text-gray-600 text-center max-w-md">
              Please wait while we verify your payment with Flutterwave. This may take a moment.
            </p>
          </div>
        );

      case "success":
        return (
          <Card className="max-w-md mx-auto">
            <CardHeader className="text-center bg-gradient-to-r from-[#0078D7] to-[#005ea8] text-white">
              <div className="mx-auto w-12 h-12 bg-white rounded-full flex items-center justify-center mb-4">
                <svg className="w-8 h-8 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <CardTitle className="text-2xl">Payment Successful</CardTitle>
              <CardDescription className="text-white text-opacity-90">
                Your subscription has been activated
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-6">
              {paymentData && paymentData.payment && (
                <div className="space-y-4">
                  <div className="text-center mb-4">
                    <div className="inline-block px-4 py-2 rounded-full bg-green-50 text-green-700 font-medium">
                      Transaction Successful
                    </div>
                  </div>

                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">Transaction ID:</span>
                    <span className="font-medium">{paymentData.payment.transactionId}</span>
                  </div>
                  
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">Reference:</span>
                    <span className="font-medium">{paymentData.payment.transactionRef || 'N/A'}</span>
                  </div>
                  
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">Amount:</span>
                    <span className="font-medium">
                      {paymentData.payment.amount 
                        ? `${paymentData.payment.amount.toLocaleString()} ${paymentData.payment.currency}` 
                        : `Payment processed in ${paymentData.payment.currency || 'RWF'}`}
                    </span>
                  </div>
                  
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">Package:</span>
                    <span className="font-medium">
                      {paymentData.subscription && paymentData.subscription.packageId 
                        ? `Package #${paymentData.subscription.packageId}` 
                        : (paymentData.payment.packageId ? `Package #${paymentData.payment.packageId}` : 'Subscription package')}
                    </span>
                  </div>
                  
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">Payment Method:</span>
                    <span className="font-medium capitalize">{paymentData.payment.paymentMethod || 'Online payment'}</span>
                  </div>
                  
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">Status:</span>
                    <span className="font-medium text-green-600">{paymentData.payment.status || 'Completed'}</span>
                  </div>
                  
                  {paymentData.payment.createdAt && (
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-500">Date:</span>
                      <span className="font-medium">
                        {new Date(paymentData.payment.createdAt).toLocaleDateString("en-US", {
                          year: "numeric",
                          month: "short",
                          day: "numeric",
                          hour: "2-digit",
                          minute: "2-digit"
                        })}
                      </span>
                    </div>
                  )}
                  
                  {paymentData.subscription && (
                    <div className="mt-6 pt-4 border-t border-gray-200">
                      <h3 className="font-medium text-gray-800 mb-2">Subscription Details</h3>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-500">Start Date:</span>
                          <span className="font-medium">
                            {new Date(paymentData.subscription.startDate).toLocaleDateString("en-US", {
                              year: "numeric",
                              month: "short",
                              day: "numeric"
                            })}
                          </span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-500">End Date:</span>
                          <span className="font-medium">
                            {new Date(paymentData.subscription.endDate).toLocaleDateString("en-US", {
                              year: "numeric",
                              month: "short",
                              day: "numeric"
                            })}
                          </span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-500">Status:</span>
                          <span className={`font-medium ${paymentData.subscription.isActive ? 'text-green-600' : 'text-gray-600'}`}>
                            {paymentData.subscription.isActive ? 'Active' : 'Inactive'}
                          </span>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </CardContent>
            <CardFooter>
              <Button onClick={handleGoToDashboard} className="w-full bg-[#0078D7]">
                Go to Dashboard
              </Button>
            </CardFooter>
          </Card>
        );

      case "retryable-error":
        return (
          <Card className="max-w-md mx-auto">
            <CardHeader className="text-center bg-gradient-to-r from-[#E97F00] to-[#D97700] text-white">
              <div className="mx-auto w-12 h-12 bg-white rounded-full flex items-center justify-center mb-4">
                <svg className="w-8 h-8 text-orange-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                </svg>
              </div>
              <CardTitle className="text-2xl">Verification Issue</CardTitle>
              <CardDescription className="text-white text-opacity-90">
                There was a problem verifying your payment
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="space-y-4">
                <p className="text-center text-gray-600">
                  We encountered a connection issue while verifying your payment. If your payment was successful with Flutterwave, please try the verification again.
                </p>
                
                {errorMessage && (
                  <div className="p-3 bg-orange-50 rounded-lg border border-orange-100 text-orange-800 text-sm">
                    <p className="font-medium mb-1">Error message:</p>
                    <p>{errorMessage}</p>
                  </div>
                )}
                
                <div className="mt-4 p-4 bg-amber-50 rounded-lg">
                  <h3 className="font-medium text-amber-800 mb-2">Transaction Details</h3>
                  <div className="space-y-2 text-sm">
                    {(() => {
                      const urlParams = new URLSearchParams(window.location.search);
                      const transaction_id = urlParams.get("transaction_id");
                      const tx_ref = urlParams.get("tx_ref");
                      const status = urlParams.get("status");
                      
                      return (
                        <>
                          {transaction_id && (
                            <div className="flex justify-between">
                              <span className="text-amber-700">Transaction ID:</span>
                              <span className="font-medium">{transaction_id}</span>
                            </div>
                          )}
                          {tx_ref && (
                            <div className="flex justify-between">
                              <span className="text-amber-700">Reference:</span>
                              <span className="font-medium">{tx_ref}</span>
                            </div>
                          )}
                          <div className="pt-2">
                            <p className="text-amber-700">If retry doesn't work, please contact support with these details.</p>
                          </div>
                        </>
                      );
                    })()}
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex flex-col gap-4">
              <Button 
                onClick={handleRetry} 
                disabled={isRetrying} 
                className="w-full bg-amber-500 hover:bg-amber-600 text-white"
              >
                {isRetrying ? (
                  <div className="flex items-center">
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Retrying...
                  </div>
                ) : 'Retry Verification'}
              </Button>
              <Button variant="outline" onClick={handleGoToDashboard} className="w-full">
                Go to Dashboard
              </Button>
            </CardFooter>
          </Card>
        );
        
      case "error":
        return (
          <Card className="max-w-md mx-auto">
            <CardHeader className="text-center bg-gradient-to-r from-[#D70000] to-[#A80000] text-white">
              <div className="mx-auto w-12 h-12 bg-white rounded-full flex items-center justify-center mb-4">
                <svg className="w-8 h-8 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </div>
              <CardTitle className="text-2xl">Payment Failed</CardTitle>
              <CardDescription className="text-white text-opacity-90">
                We couldn't verify your payment
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="space-y-4">
                <p className="text-center text-gray-600">
                  There was an issue verifying your payment. If you believe this is in error and your payment was processed, please contact customer support with your transaction details.
                </p>
                
                {/* Error message if available */}
                {errorMessage && (
                  <div className="p-3 bg-red-50 rounded-lg border border-red-100 text-red-800 text-sm">
                    <p className="font-medium mb-1">Error message:</p>
                    <p>{errorMessage}</p>
                  </div>
                )}
                
                {/* Transaction details if available from URL */}
                <div className="mt-4 p-4 bg-red-50 rounded-lg">
                  <h3 className="font-medium text-red-800 mb-2">Error Details</h3>
                  <div className="space-y-2 text-sm">
                    {(() => {
                      const urlParams = new URLSearchParams(window.location.search);
                      const transaction_id = urlParams.get("transaction_id");
                      const tx_ref = urlParams.get("tx_ref");
                      const status = urlParams.get("status");
                      
                      return (
                        <>
                          <div className="flex justify-between">
                            <span className="text-red-700">Transaction Status:</span>
                            <span className="font-medium">{status || 'Unknown'}</span>
                          </div>
                          {transaction_id && (
                            <div className="flex justify-between">
                              <span className="text-red-700">Transaction ID:</span>
                              <span className="font-medium">{transaction_id}</span>
                            </div>
                          )}
                          {tx_ref && (
                            <div className="flex justify-between">
                              <span className="text-red-700">Reference:</span>
                              <span className="font-medium">{tx_ref}</span>
                            </div>
                          )}
                          <div className="pt-2 text-red-700">
                            <p>Please include these details when contacting support.</p>
                          </div>
                        </>
                      );
                    })()}
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex flex-col gap-4">
              <Button onClick={handleGoToDashboard} className="w-full bg-[#0078D7]">
                Go to Dashboard
              </Button>
              <Button variant="outline" onClick={() => navigate("/")} className="w-full">
                Return to Home
              </Button>
            </CardFooter>
          </Card>
        );
    }
  };

  return (
    <div className="min-h-screen bg-[#F5F5F7] py-12">
      <div className="container max-w-4xl mx-auto px-4">
        <h1 className="text-3xl font-bold text-center mb-8">Payment Verification</h1>
        {renderContent()}
      </div>
    </div>
  );
};

export default PaymentCallback;