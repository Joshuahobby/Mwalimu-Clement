import { useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/context/AuthContext";
import ExamPage from "@/components/exam/ExamPage";
import { useToast } from "@/hooks/use-toast";

interface ExamProps {
  params: {
    examId: string;
  };
}

const Exam = ({ params }: ExamProps) => {
  const { isAuthenticated, subscription } = useAuth();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const examId = parseInt(params.examId);

  // Check if user is authenticated and has an active subscription
  useEffect(() => {
    if (!isAuthenticated) {
      toast({
        title: "Authentication Required",
        description: "Please log in to access this exam.",
        variant: "destructive",
      });
      navigate("/");
      return;
    }

    if (!subscription || !subscription.isActive) {
      toast({
        title: "No Active Subscription",
        description: "You need an active package to access exams.",
        variant: "destructive",
      });
      navigate("/dashboard");
      return;
    }

    if (isNaN(examId) || examId <= 0) {
      toast({
        title: "Invalid Exam",
        description: "The exam ID is invalid.",
        variant: "destructive",
      });
      navigate("/dashboard");
      return;
    }
  }, [isAuthenticated, subscription, examId, navigate, toast]);

  if (!isAuthenticated || !subscription || !subscription.isActive || isNaN(examId) || examId <= 0) {
    return null; // Don't render anything while redirecting
  }

  return (
    <div className="bg-[#F5F5F5] min-h-screen py-8">
      <ExamPage examId={examId} />
    </div>
  );
};

export default Exam;
