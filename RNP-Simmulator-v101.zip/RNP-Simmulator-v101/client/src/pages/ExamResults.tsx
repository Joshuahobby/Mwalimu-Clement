import { useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/context/AuthContext";
import ExamReview from "@/components/exam/ExamReview";
import { useToast } from "@/hooks/use-toast";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";

interface ExamResultsProps {
  params: {
    examId: string;
  };
}

const ExamResults = ({ params }: ExamResultsProps) => {
  const { isAuthenticated } = useAuth();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const examId = parseInt(params.examId);

  // Check if user is authenticated
  useEffect(() => {
    if (!isAuthenticated) {
      toast({
        title: "Authentication Required",
        description: "Please log in to access exam results.",
        variant: "destructive",
      });
      navigate("/");
      return;
    }

    if (isNaN(examId) || examId <= 0) {
      toast({
        title: "Invalid Exam",
        description: "The exam ID is invalid.",
        variant: "destructive",
      });
      navigate("/dashboard");
      return;
    }
  }, [isAuthenticated, examId, navigate, toast]);

  if (!isAuthenticated || isNaN(examId) || examId <= 0) {
    return null; // Don't render anything while redirecting
  }

  return (
    <div className="min-h-screen flex flex-col bg-[#F5F5F5]">
      <Navbar />
      <div className="flex-grow container mx-auto py-8">
        <ExamReview examId={examId} />
      </div>
      <Footer />
    </div>
  );
};

export default ExamResults;
