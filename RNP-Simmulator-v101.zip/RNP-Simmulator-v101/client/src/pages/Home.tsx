import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import HeroSection from "@/components/home/HeroSection";
import PackagesSection from "@/components/home/PackagesSection";
import FeaturesSection from "@/components/home/FeaturesSection";
import StatisticsSection from "@/components/home/StatisticsSection";

const Home = () => {
  return (
    <div>
      <Navbar />
      <HeroSection />
      <PackagesSection />
      <FeaturesSection />
      <StatisticsSection />
      <Footer />
    </div>
  );
};

export default Home;
