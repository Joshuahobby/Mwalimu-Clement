import { useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/context/AuthContext";
import ExamConfigForm from "@/components/exam/ExamConfigForm";
import { useToast } from "@/hooks/use-toast";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";

const ExamConfig = () => {
  const { isAuthenticated, subscription } = useAuth();
  const [, navigate] = useLocation();
  const { toast } = useToast();

  // Check if user is authenticated and has active subscription
  useEffect(() => {
    if (!isAuthenticated) {
      toast({
        title: "Authentication Required",
        description: "Please log in to configure an exam.",
        variant: "destructive",
      });
      navigate("/");
      return;
    }

    if (!subscription || !subscription.isActive) {
      toast({
        title: "Subscription Required",
        description: "You need an active subscription to take exams.",
        variant: "destructive",
      });
      navigate("/dashboard");
      return;
    }
  }, [isAuthenticated, subscription, navigate, toast]);

  if (!isAuthenticated || !subscription?.isActive) {
    return null; // Don't render anything while redirecting
  }

  return (
    <div className="min-h-screen flex flex-col bg-[#F5F5F5]">
      <Navbar />
      <div className="flex-grow container mx-auto py-8">
        <div className="max-w-4xl mx-auto">
          <div className="mb-6">
            <h1 className="text-2xl font-bold text-gray-800 mb-2">Start New Exam</h1>
            <p className="text-gray-600">
              Review the exam rules before beginning. Each exam consists of 20 questions and has a 20-minute time limit.
            </p>
          </div>
          <ExamConfigForm />
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default ExamConfig;