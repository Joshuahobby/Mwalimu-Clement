import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Register from "@/pages/auth/register";
import Login from "@/pages/auth/login";
import Dashboard from "@/pages/Dashboard";
import Admin from "@/pages/Admin";
import Home from "@/pages/Home";
import Exam from "@/pages/Exam";
import ExamResults from "@/pages/ExamResults";
import ExamConfig from "@/pages/ExamConfig";
import PaymentCallback from "@/pages/payment/callback";
import { Helmet } from "react-helmet";
import { AuthProvider } from "./context/AuthContext";

function Router() {
  return (
    <Switch>
      <Route path="/register" component={Register} />
      <Route path="/login" component={Login} />
      <Route path="/dashboard" component={Dashboard} />
      <Route path="/admin" component={Admin} />
      <Route path="/exams/config" component={ExamConfig} />
      <Route path="/exams/start" component={ExamConfig} />
      <Route path="/exam/:examId" component={Exam} />
      <Route path="/exam/:examId/results" component={ExamResults} />
      <Route path="/payment/callback" component={PaymentCallback} />
      <Route path="/" component={Home} />
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Helmet>
          <title>Authentication App</title>
          <meta name="description" content="User authentication application" />
          <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet" />
        </Helmet>
        <Router />
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
