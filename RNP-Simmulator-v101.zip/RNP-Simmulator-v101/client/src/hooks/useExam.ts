import { useState, useEffect } from 'react';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { useLocation } from 'wouter';

interface Question {
  id: number;
  text: string;
  category: string;
  imageUrl?: string;
  answers: Answer[];
}

interface Answer {
  id: number;
  text: string;
  isCorrect?: boolean;
}

interface ExamQuestion {
  id: number;
  examId: number;
  questionId: number;
  selectedAnswerId?: number;
  isCorrect?: boolean;
  question: Question;
  answers: Answer[];
}

interface Exam {
  id: number;
  userId: number;
  startTime: string;
  endTime?: string;
  isCompleted: boolean;
  score?: number;
  totalQuestions: number;
}

interface ExamData {
  exam: Exam;
  questions: ExamQuestion[];
  timeRemaining: number;
}

export function useExam(examId: number) {
  const [examData, setExamData] = useState<ExamData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [timeRemaining, setTimeRemaining] = useState<number>(0);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const { toast } = useToast();
  const [, navigate] = useLocation();

  // Function to fetch exam data
  const fetchExamData = async () => {
    try {
      setLoading(true);
      const response = await fetch(`/api/exams/${examId}`, {
        credentials: 'include',
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to fetch exam');
      }

      const data = await response.json();
      setExamData(data);
      setTimeRemaining(data.timeRemaining);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      toast({
        title: 'Error',
        description: err instanceof Error ? err.message : 'Failed to load exam data',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  // Function to submit an answer
  const submitAnswer = async (questionId: number, answerId: number) => {
    try {
      if (!examData || examData.exam.isCompleted) return;

      // Submit answer to the server using fetch to avoid response.json() issues
      const response = await fetch(`/api/exams/${examId}/answer`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          questionId,
          answerId,
        }),
        credentials: 'include'
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.message || 'Failed to submit answer');
      }

      // Update local state to reflect the answer
      setExamData(prev => {
        if (!prev) return null;

        const updatedQuestions = prev.questions.map(q => {
          if (q.questionId === questionId) {
            return { ...q, selectedAnswerId: answerId };
          }
          return q;
        });

        return { ...prev, questions: updatedQuestions };
      });
    } catch (err) {
      toast({
        title: 'Error',
        description: err instanceof Error ? err.message : 'Failed to submit answer',
        variant: 'destructive',
      });
    }
  };

  // Function to complete the exam
  const completeExam = async () => {
    try {
      if (!examData || examData.exam.isCompleted) return;

      const response = await fetch(`/api/exams/${examId}/complete`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({}),
        credentials: 'include'
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.message || 'Failed to complete exam');
      }

      toast({
        title: 'Exam Completed',
        description: `Your score: ${data.score}%`,
      });

      // Navigate to results page
      navigate(`/exam/${examId}/results`);
    } catch (err) {
      toast({
        title: 'Error',
        description: err instanceof Error ? err.message : 'Failed to complete exam',
        variant: 'destructive',
      });
    }
  };

  // Navigate to the next question
  const nextQuestion = () => {
    if (!examData) return;
    if (currentQuestionIndex < examData.questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
    }
  };

  // Navigate to the previous question
  const previousQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(prev => prev - 1);
    }
  };

  // Navigate to a specific question
  const goToQuestion = (index: number) => {
    if (!examData) return;
    if (index >= 0 && index < examData.questions.length) {
      setCurrentQuestionIndex(index);
    }
  };

  // Calculate the number of answered questions
  const answeredQuestionsCount = examData?.questions.filter(q => q.selectedAnswerId !== undefined && q.selectedAnswerId !== null).length || 0;

  // Get the current question
  const currentQuestion = examData?.questions[currentQuestionIndex] || null;

  // Timer effect
  useEffect(() => {
    if (!examData || examData.exam.isCompleted || timeRemaining <= 0) return;

    const timer = setInterval(() => {
      setTimeRemaining(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          // Auto-complete the exam if time runs out
          completeExam();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [examData, timeRemaining]);

  // Initial fetch
  useEffect(() => {
    fetchExamData();
  }, [examId]);

  // Format the time remaining as mm:ss
  const formatTimeRemaining = () => {
    const minutes = Math.floor(timeRemaining / 60);
    const seconds = timeRemaining % 60;
    return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };

  return {
    examData,
    loading,
    error,
    currentQuestion,
    currentQuestionIndex,
    timeRemaining: formatTimeRemaining(),
    answeredQuestionsCount,
    submitAnswer,
    completeExam,
    nextQuestion,
    previousQuestion,
    goToQuestion,
    refreshExam: fetchExamData,
  };
}
